# EasyFlow Project Structure

- `backend/` — API, processing modules, and application logic.
- `frontend/` — desktop application interface and frontend assets.
- `config/` — feature and application configuration.
- `tests/` — automated tests.
- `docs/` — development notes, release notes, QA notes, and documentation.
- `desktop_launcher.py` — native Windows desktop launcher.
- `build_windows_exe.py` / `BUILD_WINDOWS_EXE.bat` — Windows executable build entry points.
- `EasyFlow_Installer.iss` — Inno Setup installer definition.
- `requirements.txt` — Python dependencies.

Keep the root-level build and launcher files in place when uploading to GitHub; the build scripts expect these paths.
