# EasyFlow Fast Data Pipeline — Phase 1

## What changed

- Added `/api/ui/session/analyze`: uploads CSV/TSV/XLSX once, saves the source to disk, scans it row-by-row, and returns only headers, a 10-row preview, row count, and per-column blank counts.
- Added `/api/ui/session/process/{session_id}`: runs supported cleaning operations against the retained disk-backed source and creates a downloadable output archive without sending the full dataset back to the browser.
- Migrated the Blank Removal screen to the server-side session flow. The browser now receives metadata only; it does not hold the full row matrix for this workflow.
- Existing Chunk processing and the newer Duplicate Removal workflow already use server-side processing endpoints and remain unchanged.
- Added a regression test proving the session analysis response does not contain a full `matrix`, and that blank removal exports the expected records.

## Important scope note

The legacy `/api/ui/read` and `/api/ui/export` endpoints remain in place for older screens that still depend on browser-resident row arrays (including some Sales/Domain, Job Title, Info Finder, and transfer workflows). They were deliberately not removed because doing so would break those existing workflows. Those screens still need to be migrated to server-side sessions before EasyFlow can claim that every feature handles multi-million-row files without browser memory pressure.

## Session lifecycle

- Session source files are retained on disk for the configured job TTL (default 24 hours).
- Expired sessions are removed during subsequent session creation or processing requests.
- Cleaned exports are delivered as ZIP archives containing the selected output format and a processing summary.

## Verification

- Python compilation: passed.
- Full existing test suite plus new session regression test: 48 passed, 1 skipped, 4 subtests passed.
- JavaScript syntax check: 42 script blocks checked successfully.
