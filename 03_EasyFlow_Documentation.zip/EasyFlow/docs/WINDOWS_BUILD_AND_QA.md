# EasyFlow Windows 10/11 x64 desktop release workflow

## Build machine prerequisites (developer only)
- Windows 10/11 x64
- Python 3.11 x64
- Inno Setup 6
- Internet access during build to install Python build dependencies and fetch Microsoft's WebView2 Evergreen Bootstrapper

## Build
1. Extract the project folder on the Windows build machine.
2. Configure `update_config.json` with the publisher's HTTPS update manifest URL (leave blank to disable remote checks until hosting is ready).
3. Run `BUILD_WINDOWS_EXE.bat`.
4. Run `BUILD_INSTALLER_WINDOWS.bat`.
5. The single installer is written to `installer_output\EasyFlow_Setup.exe`.

The end user's PC does not need Python, pip, FastAPI, or project source code. The
installer checks for the WebView2 Runtime and silently installs Microsoft's
Evergreen bootstrapper when it is missing. EasyFlow itself runs its local API
on a randomly selected loopback port and displays the existing UI in a native
pywebview window. It does not expose the API to the LAN.

## Windows acceptance tests (must be performed on real Windows x64)
1. Install on a clean Windows 10 x64 VM without Python and without WebView2.
2. Confirm setup installs WebView2, creates Start Menu and optional desktop shortcuts, and launches EasyFlow.
3. Confirm dashboard and each existing feature open; upload, process, and download CSV/XLSX test files.
4. Repeat on Windows 11 x64 with WebView2 already installed; confirm no redundant runtime install.
5. Test 100K, 500K, 1M and 5M row files with representative columns. Record elapsed time, peak working set, and disk usage.
6. Test cancel, restart, uninstall, and reinstall. Confirm user-generated exports are not accidentally removed.
7. Publish a test update manifest with a higher version and a deliberately wrong hash; confirm wrong-hash installers are rejected. Then test a correct hash and confirm the update prompt and silent setup work.
8. Test on a non-admin Windows account. The installer targets LocalAppData and does not request elevation.
9. Sign the final installer with Authenticode before public distribution and verify the signature on a separate PC.

## Verification status
A Windows executable and installer cannot be generated or validated from a Linux
host because PyInstaller does not cross-compile Windows executables and Inno
Setup is a Windows build tool. Run the two BAT files on Windows and complete the
acceptance checklist above before calling the release Windows-tested.
