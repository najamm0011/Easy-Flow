# EasyFlow final Windows 10/11 x64 desktop release

## Release configuration
- Automatic updates are removed. This is a final, fixed release.
- The installed app is a native desktop window, not a browser tab.
- `EasyFlow_Setup.exe` contains the PyInstaller application bundle and installs it.
- Python, FastAPI, Uvicorn, and the other Python packages are bundled; users do not install them separately.
- Microsoft Edge WebView2 Runtime is checked during setup and installed silently from Microsoft's official Evergreen Bootstrapper if missing. Internet access is needed during installation only when WebView2 is absent.

## Build machine prerequisites (developer only)
- Windows 10/11 x64
- Python 3.11 x64
- Inno Setup 6
- Internet access during build to install build dependencies and download Microsoft's WebView2 bootstrapper

## Build
1. Extract the project folder on the Windows build machine.
2. Run `BUILD_WINDOWS_EXE.bat`.
3. Run `BUILD_INSTALLER_WINDOWS.bat`.
4. The desktop executable is `dist\EasyFlow\EasyFlow.exe`.
5. The installer is `installer_output\EasyFlow_Setup.exe`.

The installer targets the current user's LocalAppData and does not request
administrator access. The app runs its local API on a randomly selected
loopback-only port and displays the UI in a native pywebview window.

## Windows acceptance tests (must be performed on real Windows x64)
1. Install on a clean Windows 10 x64 VM without Python and without WebView2.
2. Confirm setup installs WebView2, creates Start Menu and optional desktop shortcuts, and launches EasyFlow.
3. Confirm dashboard and each existing feature open; upload, process, and download CSV/XLSX test files.
4. Repeat on Windows 11 x64 with WebView2 already installed; confirm no redundant runtime install.
5. Test 100K, 500K, 1M and 5M row files with representative columns. Record elapsed time, peak working set, and disk usage.
6. Test cancel, restart, uninstall, and reinstall. Confirm user-generated exports are not accidentally removed.
7. Test on a non-admin Windows account.
8. Sign the final installer with Authenticode before public distribution and verify the signature on a separate PC.

## Verification status
A Windows executable and installer cannot be generated or validated from a
Linux host because PyInstaller does not cross-compile Windows executables and
Inno Setup is a Windows build tool. Run the two BAT files on Windows and complete
the acceptance checklist above before calling the release Windows-tested.
