EasyFlow — FINAL NATIVE WINDOWS DESKTOP RELEASE
================================================

Target: Windows 10/11 x64
UI: Native desktop window using pywebview + the existing FastAPI backend
Distribution: One installer executable, EasyFlow_Setup.exe
Updates: DISABLED — this is the final release; no updater or update service is included.

The installer bundles the application, Python runtime, and Python dependencies
using PyInstaller. End users do not need Python, pip, FastAPI, or developer
tools. It checks for Microsoft Edge WebView2 Runtime and silently runs the
official Microsoft Evergreen Bootstrapper if it is missing. Internet access is
required on the target PC only if WebView2 is not already installed.

BUILD THE INSTALLER WITHOUT BAT FILES:
Use the GitHub Actions workflow described in BUILD_WITH_GITHUB_ACTIONS.md. It runs the build on a Windows 2022 x64 runner and publishes EasyFlow_Setup.exe as a downloadable workflow artifact. No BAT file needs to be opened.

The native app starts its backend on a randomly selected 127.0.0.1 port and
opens the existing dashboard in a native pywebview window. It does not expose
the local service to the LAN. Existing application routes and feature modules
are preserved in the bundle.

VERIFICATION IN THIS ENVIRONMENT:
- Python compile check and automated project tests are run separately.
- Windows EXE: not built here (this environment is Linux).
- Inno Setup installer: not compiled here (requires Windows + Inno Setup).
- WebView2 installation and native window: not tested on Windows.
- Clean-machine and large-file Windows acceptance tests: pending.

See BUILD_WITH_GITHUB_ACTIONS.md for the cloud build workflow and WINDOWS_BUILD_AND_QA.md for Windows acceptance testing.
