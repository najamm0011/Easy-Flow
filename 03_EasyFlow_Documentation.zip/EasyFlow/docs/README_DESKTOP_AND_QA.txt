EasyFlow — NATIVE WINDOWS DESKTOP DISTRIBUTION
==============================================

Target: Windows 10/11 x64
UI: Native desktop window using pywebview + the existing FastAPI backend
Distribution: One Inno Setup installer, EasyFlow_Setup.exe

The installer includes the Python runtime and application dependencies through
PyInstaller's onedir bundle. It checks for Microsoft Edge WebView2 Runtime and
runs Microsoft's Evergreen Bootstrapper silently if it is not present. A first
install without WebView2 therefore needs internet access to fetch the runtime.
The end user's PC does not need Python, pip, FastAPI, or developer tools.

BUILD ON WINDOWS 10/11 x64 ONLY:
1. Install Python 3.11 x64 and Inno Setup 6.
2. Configure update_config.json with the publisher's HTTPS update manifest URL
   when release hosting is ready. A blank URL safely disables remote updates.
3. Run BUILD_WINDOWS_EXE.bat.
4. Run BUILD_INSTALLER_WINDOWS.bat.
5. Installer output: installer_output\EasyFlow_Setup.exe

The native app starts its backend on a randomly selected 127.0.0.1 port and
opens the existing dashboard in a native pywebview window. It does not expose
the local service to the LAN. Existing application routes and feature modules
are preserved in the bundle.

AUTOMATIC UPDATES:
An HTTPS manifest checker is included. To activate it, host a JSON manifest and
installer as described in AUTO_UPDATES_SETUP.md, then set manifest_url in
update_config.json before building. Updates are prompted, downloaded over
HTTPS, and SHA-256 verified before the setup is launched. Do not distribute
public builds until the update feed is configured and tested.

VERIFICATION IN THIS ENVIRONMENT:
- Python compile check: passed.
- Automated project tests: 48 passed, 1 skipped, 4 subtests passed.
- Windows EXE: NOT built here (this environment is Linux).
- Inno Setup installer: NOT compiled here (requires Windows + Inno Setup).
- WebView2 installation and native window: NOT tested on Windows.
- Clean-machine and 5M-row Windows acceptance tests: pending.

See WINDOWS_BUILD_AND_QA.md for the full Windows build and acceptance workflow.
