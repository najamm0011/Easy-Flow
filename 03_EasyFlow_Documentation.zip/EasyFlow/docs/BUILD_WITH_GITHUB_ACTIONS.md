# Build the one-file Windows installer without running BAT files

This project includes a Windows cloud-build workflow at:

`.github/workflows/build-windows-installer.yml`

It builds on a Microsoft-hosted Windows 2022 x64 runner. It installs the build-only tools on that runner, bundles the Python runtime and app dependencies with PyInstaller, downloads Microsoft's WebView2 Evergreen Bootstrapper for the installer prerequisite, compiles `EasyFlow_Setup.exe` with Inno Setup, and uploads the installer plus a SHA-256 checksum.

## How to get the installer

1. Put this project in a GitHub repository (private is fine).
2. Open the repository's **Actions** tab.
3. Select **Build EasyFlow Windows Installer**.
4. Select **Run workflow** and confirm.
5. Wait for the job to finish successfully.
6. Open the completed workflow run and download the **EasyFlow-Windows-x64-Installer** artifact.
7. Extract the artifact. It contains `EasyFlow_Setup.exe` and `SHA256SUMS.txt`.

No `.bat` file is needed. The build tools are installed only on the temporary cloud runner; end users do not need Python or developer tools.

## What the installer does

- Installs EasyFlow for the current Windows user.
- Creates Start Menu and optional desktop shortcuts.
- Installs the Microsoft WebView2 Runtime if it is missing. This prerequisite step needs internet access if WebView2 is not already present.
- Launches the desktop application after installation if the user leaves that option selected.
- Does not configure or run an automatic updater.

## Important verification boundary

A successful workflow run proves that the Windows executable and installer compiled and that the expected files were produced. It does not, by itself, prove full functional compatibility on every Windows PC. Test the installer on a clean Windows 10/11 x64 machine before distributing it widely. Code-sign the installer and application before public distribution to improve Windows SmartScreen reputation.
