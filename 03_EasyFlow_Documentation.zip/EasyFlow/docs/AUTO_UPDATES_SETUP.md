# EasyFlow automatic updates

The desktop build includes an HTTPS-only update checker and SHA-256 verification.
For safety, update checks remain dormant until the publisher supplies a trusted
manifest URL in `update_config.json`.

Host a JSON file such as `stable.json` over HTTPS:

```json
{
  "version": "1.0.1",
  "installer_url": "https://downloads.example.com/EasyFlow_Setup.exe",
  "sha256": "64-character-lowercase-sha256-of-the-installer"
}
```

Then set `manifest_url` in `update_config.json` to that HTTPS URL before building
and distributing EasyFlow. Each release must increment the app version in
`easyflow_updater.py` and `EasyFlow_Installer.iss`, build a fresh installer, host
the installer, and update the manifest hash. The app checks at startup, prompts
before installing, verifies the installer hash, and runs the setup silently.

Do not use an HTTP URL. Keep the manifest and installer on a publisher-controlled
HTTPS origin. Sign the installer with an Authenticode code-signing certificate
before public distribution; unsigned installers may trigger Windows SmartScreen.
