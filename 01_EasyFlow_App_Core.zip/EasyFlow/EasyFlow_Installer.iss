#define MyAppName "EasyFlow"
#define MyAppVersion "1.0.0"
#define MyPublisher "EasyFlow"
[Setup]
AppId={{C3A72D1E-1137-4EA9-B314-5C6F48D332AC}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyPublisher}
DefaultDirName={localappdata}\Programs\EasyFlow
DefaultGroupName=EasyFlow
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
OutputDir=installer_output
OutputBaseFilename=EasyFlow_Setup
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\EasyFlow.exe
SetupLogging=yes
CloseApplications=yes
RestartApplications=no
[Files]
Source: "dist\EasyFlow\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "installer_assets\MicrosoftEdgeWebView2Setup.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall
[Icons]
Name: "{autoprograms}\EasyFlow"; Filename: "{app}\EasyFlow.exe"
Name: "{autodesktop}\EasyFlow"; Filename: "{app}\EasyFlow.exe"; Tasks: desktopicon
[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"
[Run]
Filename: "{tmp}\MicrosoftEdgeWebView2Setup.exe"; Parameters: "/silent /install"; StatusMsg: "Installing Microsoft Edge WebView2 Runtime..."; Flags: waituntilterminated; Check: not IsWebView2Installed
Filename: "{app}\EasyFlow.exe"; Description: "Launch EasyFlow"; Flags: nowait postinstall skipifsilent
[Code]
function HasWebView2In(BasePath: String): Boolean;
var
  FindRec: TFindRec;
  SearchPath: String;
begin
  Result := False;
  SearchPath := AddBackslash(BasePath) + '*';
  if FindFirst(SearchPath, FindRec) then begin
    try
      repeat
        if ((FindRec.Attributes and FILE_ATTRIBUTE_DIRECTORY) <> 0) and
           (FindRec.Name <> '.') and (FindRec.Name <> '..') then begin
          if FileExists(AddBackslash(BasePath) + FindRec.Name + '\msedgewebview2.exe') then begin
            Result := True;
            Exit;
          end;
        end;
      until not FindNext(FindRec);
    finally
      FindClose(FindRec);
    end;
  end;
end;

function IsWebView2Installed: Boolean;
begin
  Result := HasWebView2In(ExpandConstant('{localappdata}\Microsoft\EdgeWebView\Application')) or
            HasWebView2In(ExpandConstant('{pf}\Microsoft\EdgeWebView\Application')) or
            HasWebView2In(ExpandConstant('{pf32}\Microsoft\EdgeWebView\Application'));
end;
