"""Build EasyFlow's native Windows 10/11 x64 application directory.
Run this script on Windows x64; PyInstaller is not a cross-compiler.
"""
import importlib.util
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if platform.system() != "Windows" or platform.machine().lower() not in ("amd64", "x86_64"):
    raise SystemExit("Build required on Windows 10/11 x64; PyInstaller cannot cross-compile Windows executables.")

args = [
    sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--onedir",
    "--windowed", "--name", "EasyFlow",
    "--add-data", "frontend;frontend",
    "--add-data", "update_config.json;.",
    "--collect-all", "openpyxl",
    "--collect-all", "webview",
    "--hidden-import", "webview.platforms.edgechromium",
    "--hidden-import", "webview.platforms.mshtml",
    "--hidden-import", "backend.modules.processing",
    "--hidden-import", "backend.modules.overview",
    "--hidden-import", "easyflow_updater",
]
for optional in ("polars", "duckdb"):
    if importlib.util.find_spec(optional):
        args.extend(["--collect-all", optional])
args.append("desktop_launcher.py")
raise SystemExit(subprocess.call(args, cwd=ROOT))
