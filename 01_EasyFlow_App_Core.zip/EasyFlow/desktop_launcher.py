"""EasyFlow native Windows desktop launcher.

Runs the existing FastAPI application on loopback and hosts its UI in a
pywebview window. The web server is never exposed to the LAN by default.
"""
from __future__ import annotations

import os
import socket
import sys
import threading
import time

import uvicorn

from backend.main import app

APP_NAME = "EasyFlow"


def _free_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def ready(host: str, port: int, timeout: float = 30.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.35):
                return True
        except OSError:
            time.sleep(0.15)
    return False


def _ensure_stdio() -> None:
    """Provide safe streams for PyInstaller --windowed builds.

    In a windowed executable, Python may set stdout/stderr to None. Uvicorn's
    default logging formatter calls stdout.isatty(), which then crashes.
    Redirect missing streams to the null device before configuring Uvicorn.
    """
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w", encoding="utf-8")


def main() -> int:
    if sys.platform != "win32":
        raise SystemExit("The native EasyFlow desktop build is intended for Windows 10/11 64-bit.")

    _ensure_stdio()

    host = "127.0.0.1"
    port = _free_loopback_port()
    server = uvicorn.Server(
        uvicorn.Config(
            app,
            host=host,
            port=port,
            log_level="warning",
            access_log=False,
            log_config=None,
        )
    )
    server_thread = threading.Thread(target=server.run, name="EasyFlow-API", daemon=True)
    server_thread.start()

    if not ready(host, port):
        server.should_exit = True
        raise RuntimeError("EasyFlow could not start its local service. Check the application log.")

    import webview  # Imported only in the Windows GUI process.

    window = webview.create_window(
        APP_NAME,
        f"http://{host}:{port}/dashboard",
        width=1440,
        height=920,
        min_size=(1000, 680),
        background_color="#f7f8fa",
    )

    try:
        webview.start(debug=False)
    finally:
        server.should_exit = True
        server_thread.join(timeout=5)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
