"""EasyFlow native Windows desktop launcher.

Runs the existing FastAPI application on loopback and hosts its UI in a
pywebview window. The web server is never exposed to the LAN by default.
"""
from __future__ import annotations

import os
import socket
import sys
import threading
import time
from pathlib import Path

import uvicorn

from backend.main import app

APP_NAME = "EasyFlow"


def _free_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def ready(host: str, port: int, timeout: float = 30.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.35):
                return True
        except OSError:
            time.sleep(0.15)
    return False


def main() -> int:
    if sys.platform != "win32":
        raise SystemExit("The native EasyFlow desktop build is intended for Windows 10/11 64-bit.")

    host = "127.0.0.1"
    port = _free_loopback_port()
    server = uvicorn.Server(
        uvicorn.Config(app, host=host, port=port, log_level="warning", access_log=False)
    )
    server_thread = threading.Thread(target=server.run, name="EasyFlow-API", daemon=True)
    server_thread.start()

    if not ready(host, port):
        server.should_exit = True
        raise RuntimeError("EasyFlow could not start its local service. Check the application log.")

    import webview  # Imported only in the Windows GUI process.

    window = webview.create_window(
        APP_NAME,
        f"http://{host}:{port}/dashboard",
        width=1440,
        height=920,
        min_size=(1000, 680),
        background_color="#f7f8fa",
    )

    def check_updates() -> None:
        # Updates are inactive until the publisher configures a trusted HTTPS manifest URL.
        try:
            from easyflow_updater import load_config, fetch_update, download_verified_update, launch_installer
            config = load_config()
            if not config.get("check_on_startup", True) or not config.get("manifest_url"):
                return
            update = fetch_update(config)
            if not update:
                return
            # Wait until the native window has loaded before displaying the confirmation.
            window.events.loaded.wait(25)
            import json
            message = json.dumps(
                f"EasyFlow {update['version']} is available. Download and install it now?"
            )
            accepted = window.evaluate_js(f"window.confirm({message})")
            if accepted:
                installer = download_verified_update(update)
                launch_installer(installer)
                server.should_exit = True
                window.destroy()
        except Exception:
            # A failed update check must never prevent users from opening EasyFlow.
            return

    threading.Thread(target=check_updates, name="EasyFlow-Update-Check", daemon=True).start()

    try:
        webview.start(debug=False)
    finally:
        server.should_exit = True
        server_thread.join(timeout=5)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
