"""Secure, opt-in-by-feed automatic update helper for EasyFlow.

The update feed must be hosted by the publisher over HTTPS. The manifest must
contain: {"version":"1.0.1", "installer_url":"https://.../EasyFlow_Setup.exe",
"sha256":"<64 hex chars>"}. Downloads are hash-verified before execution.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import tempfile
import urllib.request
from pathlib import Path

from packaging.version import InvalidVersion, Version

APP_VERSION = "1.0.0"
ROOT = Path(getattr(__import__("sys"), "_MEIPASS", Path(__file__).resolve().parent))


def load_config() -> dict:
    path = ROOT / "update_config.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"manifest_url": "", "check_on_startup": False}


def fetch_update(config: dict) -> dict | None:
    url = str(config.get("manifest_url", "")).strip()
    if not url.startswith("https://"):
        return None
    request = urllib.request.Request(url, headers={"User-Agent": "EasyFlow-Updater/1"})
    with urllib.request.urlopen(request, timeout=8) as response:
        manifest = json.loads(response.read(256 * 1024).decode("utf-8"))
    try:
        latest = Version(str(manifest["version"]))
        current = Version(APP_VERSION)
    except (KeyError, InvalidVersion):
        return None
    installer_url = str(manifest.get("installer_url", ""))
    digest = str(manifest.get("sha256", "")).lower()
    if latest <= current or not installer_url.startswith("https://") or not re.fullmatch(r"[a-f0-9]{64}", digest):
        return None
    return {"version": str(latest), "installer_url": installer_url, "sha256": digest}


def download_verified_update(update: dict) -> Path:
    fd, filename = tempfile.mkstemp(prefix="EasyFlow_Update_", suffix=".exe")
    os.close(fd)
    target = Path(filename)
    digest = hashlib.sha256()
    request = urllib.request.Request(update["installer_url"], headers={"User-Agent": "EasyFlow-Updater/1"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response, target.open("wb") as output:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                digest.update(block)
                output.write(block)
        if digest.hexdigest() != update["sha256"]:
            raise ValueError("The downloaded installer failed its SHA-256 integrity check.")
        return target
    except Exception:
        target.unlink(missing_ok=True)
        raise


def launch_installer(installer: Path) -> None:
    subprocess.Popen([str(installer), "/SILENT", "/SUPPRESSMSGBOXES", "/NORESTART"], close_fds=True)
