from io import BytesIO
import zipfile

from fastapi.testclient import TestClient

from backend.main import app


def test_large_file_session_analyze_and_blank_export_stays_server_side():
    client = TestClient(app)
    source = (
        b"email,name\n"
        b"a@example.com,A\n"
        b",B\n"
        b"b@example.com,C\n"
    )
    analyzed = client.post(
        "/api/ui/session/analyze",
        files={"file": ("sample.csv", source, "text/csv")},
    )
    assert analyzed.status_code == 200
    info = analyzed.json()
    assert info["rows"] == 3
    assert info["headers"] == ["email", "name"]
    assert info["blank_by_column"] == [1, 0]
    assert len(info["preview"]) == 3
    assert "matrix" not in info  # No full dataset payload.

    processed = client.post(
        f"/api/ui/session/process/{info['session_id']}",
        data={"mode": "blanks", "config": '{"columns":[0]}', "fmt": "csv"},
    )
    assert processed.status_code == 200
    stats = processed.json()["stats"]
    assert stats["input_rows"] == 3
    assert stats["removed_rows"] == 1
    assert stats["output_rows"] == 2

    downloaded = client.get(processed.json()["download_url"])
    assert downloaded.status_code == 200
    with zipfile.ZipFile(BytesIO(downloaded.content)) as archive:
        assert "cleaned.csv" in archive.namelist()
        cleaned = archive.read("cleaned.csv").decode("utf-8-sig")
    assert "a@example.com,A" in cleaned
    assert "b@example.com,C" in cleaned
    assert ",B" not in cleaned
