@echo off
setlocal
cd /d "%~dp0"
if not "%PROCESSOR_ARCHITECTURE%"=="AMD64" if not "%PROCESSOR_ARCHITEW6432%"=="AMD64" (
  echo Please build on Windows 10/11 64-bit.
  exit /b 1
)
where py >nul 2>nul
if %errorlevel%==0 (set "PYCMD=py -3.11") else (set "PYCMD=python")
%PYCMD% -m pip install --upgrade pip
if errorlevel 1 goto fail
%PYCMD% -m pip install -r requirements.txt pyinstaller pywebview packaging
if errorlevel 1 goto fail
if not exist installer_assets mkdir installer_assets
if not exist "installer_assets\MicrosoftEdgeWebView2Setup.exe" (
  echo Downloading official Microsoft WebView2 Evergreen Bootstrapper...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile 'installer_assets\MicrosoftEdgeWebView2Setup.exe'"
  if errorlevel 1 goto fail
)
%PYCMD% build_windows_exe.py
if errorlevel 1 goto fail
echo Native desktop app: dist\EasyFlow\EasyFlow.exe
echo Next run BUILD_INSTALLER_WINDOWS.bat to create the single setup EXE.
exit /b 0
:fail
echo Windows packaging failed. Review the error above.
exit /b 1
