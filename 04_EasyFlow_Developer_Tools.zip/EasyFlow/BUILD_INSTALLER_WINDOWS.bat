@echo off
setlocal
cd /d "%~dp0"
if not exist "dist\EasyFlow\EasyFlow.exe" (
  echo Native application missing; building it first...
  call BUILD_WINDOWS_EXE.bat
  if errorlevel 1 exit /b 1
)
if not exist "installer_assets\MicrosoftEdgeWebView2Setup.exe" (
  echo WebView2 bootstrapper missing. Run BUILD_WINDOWS_EXE.bat first.
  exit /b 1
)
where ISCC.exe >nul 2>nul
if errorlevel 1 (
  if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" (
    "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "EasyFlow_Installer.iss"
  ) else (
    echo Inno Setup 6 is required to create EasyFlow_Setup.exe.
    echo Install Inno Setup 6 and run this file again.
    exit /b 1
  )
) else (
  ISCC.exe "EasyFlow_Installer.iss"
)
if errorlevel 1 exit /b 1
echo Installer created: installer_output\EasyFlow_Setup.exe
