@echo off
cd /d "%~dp0"
echo WARNING: This stress test generates a multi-hundred-MB input and large ZIPs.
echo Ensure sufficient disk space and time. Press Ctrl+C to cancel.
pause
python BENCHMARK_PIPELINE.py --rows 5000000
pause
