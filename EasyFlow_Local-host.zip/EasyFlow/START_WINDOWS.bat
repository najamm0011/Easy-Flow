@echo off
setlocal
cd /d "%~dp0"
if not defined NS_HOST set "NS_HOST=127.0.0.1"
if not defined NS_PORT set "NS_PORT=8000"
where py >nul 2>nul
if %errorlevel%==0 (set "PYCMD=py -3") else (set "PYCMD=python")
%PYCMD% -c "import fastapi,uvicorn" >nul 2>nul
if errorlevel 1 (
  echo Missing dependencies. Run INSTALL_WINDOWS.bat once.
  pause
  exit /b 1
)
echo EasyFlow running at http://%NS_HOST%:%NS_PORT%/dashboard
echo To share on a LAN, set NS_HOST=0.0.0.0 and configure firewall access.
if "%NS_HOST%"=="0.0.0.0" (
  start "" "http://127.0.0.1:%NS_PORT%/dashboard"
) else (
  start "" "http://%NS_HOST%:%NS_PORT%/dashboard"
)
%PYCMD% -m uvicorn backend.main:app --host %NS_HOST% --port %NS_PORT%
pause
