@echo off
cd /d "%~dp0"
echo EasyFlow - 100,000 rows (profiling OFF)
python BENCHMARK_OVERVIEW.py --rows 100000
pause
