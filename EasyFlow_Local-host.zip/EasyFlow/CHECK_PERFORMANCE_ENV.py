"""Report optional engines and platform resources without requiring installs."""
import importlib.util, os, platform, sys
print('Python:',sys.version.split()[0], '| Platform:',platform.system(),platform.machine())
print('CPU logical cores:',os.cpu_count())
for name in ('polars','duckdb','psutil'):
    print(name+':','available' if importlib.util.find_spec(name) else 'not installed (optional)')
if importlib.util.find_spec('psutil'):
    import psutil
    print('Available RAM GB:',round(psutil.virtual_memory().available/(1024**3),2))
print('Polars CSV threshold MB: 1 to',os.getenv('NS_POLARS_MAX_MB','64'))
print('SQLite in-memory input threshold MB:',os.getenv('NS_DEDUPE_MEMORY_INPUT_MB','160'))
print('ZIP compression level:',os.getenv('NS_ZIP_LEVEL','1'))
