PHASE 17 - UI/FORMAT WORKFLOW PREVIEW

New File Merge and Enrich Data Cleaning cards added as first and second tools, matching the Blank Removal card layout. Their import and workflow screens are UI previews only; processing/export not implemented.
Dashboard card numbers replaced with icons. File Summary and Data Preview numeric prefixes removed. XLSX is the default for detected format dropdowns. File pickers show CSV, TSV, XLSX, XLS, XLSM, XLSB, ODS, ZIP, but backend only processes CSV, TSV and XLSX at present. Other formats and ZIP import are NOT yet supported. ZIP downloads remain available where the existing backend generates them.

Do not use unsupported inputs until format readers and secure ZIP import are implemented.
