@echo off
setlocal
cd /d "%~dp0"
echo === REGRESSION + API END-TO-END ===
python -m unittest discover -s tests -q
if errorlevel 1 goto fail
echo === 100K CLEANING BENCHMARK ===
python BENCHMARK_CLEANING.py --rows 100000
if errorlevel 1 goto fail
echo === 1M PIPELINE + ZIP CRC ===
python BENCHMARK_PIPELINE.py --rows 1000000
if errorlevel 1 goto fail
echo === 5M PIPELINE + ZIP CRC (can take significant disk and time) ===
python BENCHMARK_PIPELINE.py --rows 5000000
if errorlevel 1 goto fail
echo === BROWSER QA ===
python QA_BROWSER.py
if errorlevel 1 goto fail
echo ALL QA CHECKS PASSED
pause
exit /b 0
:fail
echo QA FAILED. Copy the error and share it for diagnosis.
pause
exit /b 1
