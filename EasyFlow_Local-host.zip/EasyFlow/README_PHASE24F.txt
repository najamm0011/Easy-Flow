PHASE 24F — Unified File Overview Benchmark

Root cause of incomparable benchmark figures: the former BENCHMARK_OVERVIEW.py enabled tracemalloc during the timed operation, while BENCHMARK_PROFILE.py did not. tracemalloc can substantially slow per-row Python allocations; therefore timings cannot be compared directly.

Both benchmark entry points now invoke the SAME benchmark function, with Python allocation profiling OFF by default.

On Windows:
1. Run RUN_TESTS_WINDOWS.bat
2. Run BENCHMARK_PROFILE_WINDOWS.bat for 500,000 rows.
3. For 1,000,000 rows, open terminal in the project folder and run:
   python BENCHMARK_OVERVIEW.py --rows 1000000
4. To explicitly measure Python allocations (slower; not comparable with normal runs):
   python BENCHMARK_OVERVIEW.py --rows 100000 --profile-python

The benchmark excludes synthetic CSV generation from its timed section. RSS at end (if psutil installed) is NOT peak memory. Actual cleaning modules have NOT been optimized in this phase. Existing backend/frontend feature behavior is unchanged.
