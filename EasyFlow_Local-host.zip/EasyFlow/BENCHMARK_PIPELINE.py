import argparse,csv,tempfile,time,zipfile
from pathlib import Path
from backend.modules.processing import process
p=argparse.ArgumentParser();p.add_argument('--rows',type=int,default=100000);args=p.parse_args()
if not 1<=args.rows<=5000000:p.error('rows must be 1..5000000')
with tempfile.TemporaryDirectory(prefix='ns_pipeline_') as tmp:
    folder=Path(tmp);source=folder/'input.csv';t=time.perf_counter()
    with source.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['Email','ID','Job Title','Company'])
        for i in range(args.rows):w.writerow([' ' if i%13==0 else f'person{i}@example.com',f'{i:09d}','CEO' if i%3==0 else 'Director',f'Company {i%1000}'])
    print(f'Rows: {args.rows:,}; Input MB: {source.stat().st_size/1048576:.2f}; Generation: {time.perf_counter()-t:.3f}s',flush=True)
    for mode,config in [('blanks',{'columns':['Email']}),('duplicates',{'columns':['Email']})]:
        t=time.perf_counter();archive,stats=process(source,'.csv',folder/mode,mode,config);elapsed=time.perf_counter()-t
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            assert 'processing_summary.json' in z.namelist()
        assert stats['input_rows']==args.rows
        assert stats['output_rows']+stats['removed_rows']==args.rows
        print(f'{mode}: {elapsed:.3f}s, {args.rows/elapsed:,.0f} rows/s, out={stats["output_rows"]:,}, removed={stats["removed_rows"]:,}, ZIP MB={archive.stat().st_size/1048576:.2f}, CRC=OK',flush=True)
