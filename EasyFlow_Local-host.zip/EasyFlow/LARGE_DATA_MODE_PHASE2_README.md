# EasyFlow — Large Data Mode Phase 2 (incremental release)

This release extends Phase 1 without changing the approved frontend or data-cleaning semantics.

## Implemented
- Common cleaning engine defaults to SQLite disk-backed exact-match deduplication for all sizes (`NS_DEDUPE_ENGINE=auto`). Explicit `NS_DEDUPE_ENGINE=set` remains available for legacy diagnostics only.
- SQLite cache limited to approximately 8 MiB per connection; temporary SQLite operations use disk storage.
- Deduplication transactions commit every 10,000 fresh rows, avoiding an unbounded write transaction.
- Dedicated single/master duplicate endpoint receives the same bounded-cache, disk-temp and periodic-commit settings.
- Existing CSV/TSV streaming readers, XLSX read-only readers and write-only XLSX exporters retained.
- Existing Merge CSV streaming, Chunks sequential ZIP generation, Blank Removal and Sales Navigator streaming paths retained.
- Cross-batch deduplication and whitespace blank removal regression tests added.

## Not yet complete
- All feature endpoints have not been refactored into a single background job manager.
- Job cancellation, restart recovery, active-job-aware cleanup and safe output retention require additional work.
- Job Title Splitter with extremely many distinct groups may require bounded open-file handles.
- Large XLSX files are limited by Excel sheet capacity and read/write speed.
- No 1M/5M-row 8 GB RAM benchmarks have been run. Performance and memory targets are not yet verified.
- Existing `EASYFLOW_ALLOW_IN_MEMORY` / legacy diagnostic settings should not be enabled for production low-memory mode.

## Test
Run `python -m pytest -q tests` from the EasyFlow project folder.
