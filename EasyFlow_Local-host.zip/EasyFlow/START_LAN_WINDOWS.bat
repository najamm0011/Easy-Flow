@echo off
echo WARNING: LAN mode exposes uploaded files and processing endpoints to
echo other devices on your network. Only use on trusted private networks.
pause
set "NS_HOST=0.0.0.0"
call "%~dp0START_WINDOWS.bat"
