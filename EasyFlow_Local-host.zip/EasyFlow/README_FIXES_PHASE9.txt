EasyFlow - Targeted fixes after user testing

FIXED / TESTED
- Percentage Chunks: frontend now sends a valid size for percentage mode; backend does not incorrectly validate the Simple Chunks size in percentage mode. Tested 20/30/50 percentages with correct output ZIP row counts and headers.
- Apollo Raw Cleaning: mapped known fields now use standardized output headers instead of only generating First Name/Last Name; unknown selected headers retain their original names.
- Apollo Link Swapper: mapping dropdown labels now include up to 3 sample values for easier selection.
- Apollo raw/link upload metadata no longer repeats the uploaded filename; file summary elsewhere may show the name.

NOT FIXED YET
- Apollo 60MB browser freeze: existing original dashboard still reads full input into browser memory. Use the backend Processing Console for larger Apollo files for now. A complete streaming Apollo UI integration is required before declaring this fixed.
- Large-file stress tests, all modules end-to-end Windows tests, and full dashboard-to-backend integration remain pending.

Start via INSTALL_WINDOWS.bat then START_WINDOWS.bat. Dashboard: http://127.0.0.1:8000/dashboard
