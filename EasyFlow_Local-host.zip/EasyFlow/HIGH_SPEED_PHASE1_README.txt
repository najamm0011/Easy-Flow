EasyFlow — High-Speed Phase 1: measured baseline
This phase introduces a reproducible, read-only CSV cleaning benchmark.
Run from project root: python PERFORMANCE_AUDIT.py --rows 100000
It generates temporary data, benchmarks the EXISTING backend's Blank Removal
and Duplicate Removal end-to-end (read + clean + export + ZIP), checks row
counts, and prints JSON metrics. Temporary data is removed automatically.
The existing UI, processing, navigation and file transfer logic is unchanged.
The benchmark does NOT cover browser uploads, Excel parsing, domain filtering,
LAN transfers, peak RAM, 1M+ rows, or speed improvements yet.
Next phase: measure upload/parse/transfer/export stages; then optimize bottlenecks
with streaming and selective parallelism, checking exact-match semantics.
