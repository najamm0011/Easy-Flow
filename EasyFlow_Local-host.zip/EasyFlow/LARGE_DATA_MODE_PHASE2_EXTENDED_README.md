# EasyFlow Large Data Mode — Extended Phase 2

## Delivered in this build
- Bounded, process-local background JobManager for disk-backed cleaning operations.
- Opt-in API: POST /api/large-data/cleaning/start (multipart: file, mode, config JSON, fmt, optional master), GET /api/large-data/jobs/{id}, POST /api/large-data/jobs/{id}/cancel, GET /api/large-data/jobs/{id}/download.
- Cancellation checks every 1024 input rows for the managed cleaning engine; cancellation is cooperative, not instantaneous.
- Progress rows_scanned; job state persisted atomically in state.json; restart marks unfinished jobs interrupted, completed outputs retained.
- Expiry cleanup of managed completed/failed/interrupted jobs after 24h via JobManager.cleanup() (not a periodic background scheduler).
- Per-job directories; disk-space preflight; bounded thread pool; intermediate input and output files cleaned on completion.
- Existing routes/UI retained unchanged; new managed API is opt-in and NOT yet wired into every frontend feature.

## Verified here
- 53 tests passed, 1 skipped, 4 subtests passed (local Linux environment).
- Synthetic CSV benchmark: 1M blanks, 5M blanks, 1M duplicates. Details in benchmark JSON files.
- Benchmark timings exclude input generation and initial upload. RSS is peak process usage, not isolated per-job memory.

## Still outstanding before production sign-off
- Integrate all frontend feature buttons with managed APIs, including Merge and Chunks.
- Cooperative cancellation throughout every engine, including percentage chunks, merge, Excel writer finalization and online research.
- Recover/retry semantics for interrupted jobs and timed cleanup scheduler; multi-process worker coordination.
- Real 8 GB Windows office PC tests, 5M duplicate benchmark, XLSX/ZIP stress, disk-full and browser download failure simulations.
- More comprehensive full-file validation, error isolation and performance profiling.

Do not claim that this build is production-ready or that all features are fully optimized.
