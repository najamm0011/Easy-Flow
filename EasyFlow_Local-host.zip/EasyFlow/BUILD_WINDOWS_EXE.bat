@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PYCMD=py -3") else (set "PYCMD=python")
%PYCMD% -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto fail
%PYCMD% build_windows_exe.py
if errorlevel 1 goto fail
echo Portable Windows app: dist/EasyFlow/EasyFlow.exe
pause
exit /b 0
:fail
echo Windows packaging failed. Share this output.
pause
exit /b 1
