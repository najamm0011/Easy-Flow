@echo off
cd /d "%~dp0"
echo === REGRESSION TESTS ===
python -m unittest discover -s tests -p "test_*.py" -q
if errorlevel 1 goto fail
echo === ALL CLEANING BENCHMARKS ===
python BENCHMARK_CLEANING.py --rows 100000
if errorlevel 1 goto fail
echo === ENGINE COMPARISON ===
python BENCHMARK_ENGINES.py --rows 100000
if errorlevel 1 goto fail
echo ALL CHECKS COMPLETE
pause
exit /b 0
:fail
echo FAILED - copy output to ChatGPT
pause
exit /b 1
