Phase 24I — Optional engine comparison (experimental).
1. Run RUN_TESTS_WINDOWS.bat.
2. To compare all engines, run: python -m pip install polars duckdb
3. Double-click BENCHMARK_ENGINES_WINDOWS.bat.
4. Send benchmark results.
The existing EasyFlow cleaning engine and UI remain unchanged.
Benchmarks compare 100K CSV rows, duplicates by Email and blank Company Website.
Timing includes reading, processing, CSV writing, not input generation or ZIP.
This does not measure Apollo, Master Compare, Excel, browser, or RAM peak.
Optional packages are not required for the normal app to run.
