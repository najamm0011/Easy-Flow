EasyFlow — CONSOLIDATED CANDIDATE (NOT CERTIFIED PRODUCTION FINAL)
==========================================================
This package preserves the existing UI and processing modules and adds an adaptive
deduplication engine for duplicate removal and master comparison:
- For conservative input sizes, Python set of exact normalized JSON keys.
- For larger inputs, SQLite with disk-backed fallback.
- Override via NS_DEDUPE_ENGINE=auto|set|sqlite (auto default).
- NS_DEDUPE_SET_MAX_MB=64 default; optional psutil available RAM check.
- Existing NS_DEDUPE_MEMORY_INPUT_MB controls SQLite memory threshold.
- Existing Polars Blank Removal fast path is preserved.
- Full 21-test suite (20 passed, 1 skipped when Polars absent in build environment).
- Added set vs SQLite equality tests for single and master deduplication.
- RUN_FINAL_VALIDATION_WINDOWS.bat: all tests, 100K modules, engine comparison,
  environment diagnostics, 1M end-to-end pipeline and ZIP CRC.
- RUN_OPTIONAL_5M_STRESS_WINDOWS.bat: optional 5M synthetic row pipeline stress.
- START_WINDOWS.bat launches existing application.

Observed 1M-row synthetic pipeline on build environment (NOT user's machine):
  Duplicate Removal: 7.243 sec; 923,077 output; 76,923 removed; ZIP CRC OK.
  Blank Removal: 3.565 sec; 923,076 output; 76,924 removed; ZIP CRC OK.
These are not universal speed guarantees. Input generation excluded.
No performance claims for browser UI or 5M until tested on deployment systems.

KNOWN PRODUCT LIMITATIONS / UNFINISHED WORK
- Browser upload/download responsiveness, peak RAM, crash/recovery and 5M run
  across target hardware have not been comprehensively verified.
- XLSX has Excel row/sheet limitations and can be substantially slower than CSV.
- Info Finder UI is not a working online enrichment integration.
- No installer / signed Windows desktop application is included.
- This is a consolidated development candidate, not a fully validated final
  production release. Do not treat unverified features as completed.
