EasyFlow — DESKTOP PACKAGING + QA BUILD
========================================
INFO FINDER: not integrated, as requested. Existing placeholder UI is unchanged.

To make portable Windows EXE (one-time on a Windows development computer):
1. Extract ZIP, run BUILD_WINDOWS_EXE.bat (internet needed for installing build dependencies).
2. Copy the entire dist\EasyFlow folder to another Windows computer.
3. Run EasyFlow.exe inside that folder. The app starts locally and opens the browser.
   End users do NOT need Python installed. Internet is not required for offline cleaning.
4. This is a portable app, NOT an MSI/setup installer or signed executable.
   Windows build cannot be compiled or tested on this Linux build environment.
5. Run RUN_FINAL_VALIDATION_WINDOWS.bat to execute regression and 1M pipeline checks.
6. Run RUN_OPTIONAL_5M_STRESS_WINDOWS.bat for 5M-row stress (requires free disk/RAM).

Local app defaults to 127.0.0.1:8000. To enable LAN, explicitly set
NS_ALLOW_LAN=1 and NS_HOST=0.0.0.0. WARNING: LAN mode lacks auth/TLS.

QA status: automated tests, backend HTTP TestClient, ZIP CRC, 100K/1M benchmark
available. Actual Windows EXE, browser automation, cross-machine 5M stress,
peak memory and signed installer are NOT verified/completed here.
