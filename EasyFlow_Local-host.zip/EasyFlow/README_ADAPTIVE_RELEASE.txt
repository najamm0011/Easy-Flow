EasyFlow — Adaptive Performance Release

This is a consolidated stability/performance release for diverse hardware, NOT a single-PC configuration.

Included:
- Previous Apollo column mapping and URL caching improvements.
- RAM-backed SQLite for smaller dedupe/master comparisons; larger inputs use disk.
- Combined master+fresh size is considered when selecting SQLite RAM vs disk.
- If optional psutil is available, available system memory also limits RAM-backed SQLite.
- Optional Polars CSV blank-removal fast path is capped to 64 MB input by default; larger files stream via Python.
- Configurable environment variables: NS_POLARS_BLANKS (0 to disable), NS_POLARS_MAX_MB (default 64), NS_DEDUPE_MEMORY_INPUT_MB (default 160), NS_ZIP_LEVEL (default 1).
- One-click RUN_COMPLETE_PERFORMANCE_WINDOWS.bat tests + benchmarks + system diagnostics.
- BENCHMARK_1M_WINDOWS.bat for optional 1M record workload.
- No dashboard/UI features removed or changed.

Not yet verified: browser end-to-end responsiveness, 5M-row production workloads, memory peaks, XLSX large-file throughput, diverse machines. Polars path has in-memory limits and may not always beat streaming when ZIP export dominates.
