@echo off
cd /d "%~dp0"
python -m unittest discover -s tests -p "test_*.py" -v
if errorlevel 1 (
 echo.
 echo TESTS FAILED - please share this output.
) else (
 echo.
 echo TESTS PASSED.
)
pause
