@echo off
cd /d "%~dp0"
python BENCHMARK_CLEANING.py --rows 100000 --modes apollo_raw
pause
