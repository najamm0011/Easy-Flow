EasyFlow Phase 6 — Apollo Raw Cleaning & Link Swapper

CHANGES
- Apollo Raw Cleaning: after column selection, Name Separation asks ONLY for Full Name column.
- Generates First Name and Last Name from Full Name, retaining other selected original columns (excluding the source Full Name and existing first/last fields to avoid duplicate name columns).
- Displays 5-row processed preview before Continue to Link Swapper.
- Link Swapper: five mapping dropdowns: Company Name, Company Website, Company LinkedIn, Personal LinkedIn, Facebook.
- Routes URLs within the SAME row by type, including LinkedIn URLs found in Facebook and Facebook URLs found in other fields.
- Missing target columns are created automatically; conflicting different values are not overwritten and affected rows are flagged for review and left unchanged.
- Displays five-row corrected preview and counts of corrected/review rows.
- Original glassmorphism UI, all other tools and Phase 5 functions retained.

TESTS
- All inline JavaScript blocks passed Node syntax validation.
- Targeted JavaScript tests passed: Full Name splitting, Facebook/LinkedIn routing, conflict handling.
- Windows browser end-to-end tests and large-file Apollo exports are NOT yet validated.
- Apollo exports still use browser-side CSV/Excel generation and may hit memory constraints for large files; future backend migration remains needed.

RUN
1. Extract this ZIP to a NEW folder.
2. Stop any previously running EasyFlow server.
3. Run START_WINDOWS.bat (INSTALL_WINDOWS.bat if dependencies missing).
4. Open Apollo Data Cleaning > Raw Cleaning and test with a small sample file.
