EasyFlow - INTEGRATED OFFLINE REPAIR CANDIDATE

Run START_WINDOWS.bat from the extracted EasyFlow folder. Open http://127.0.0.1:8000/dashboard (not frontend/index.html directly).

Preserved original dashboard. Added local backend-powered CSV/TSV/XLSX reader for existing tool import screens; local Python-generated CSV/TSV/XLSX/ZIP outputs for Duplicate Removal, Master Comparison, Blank Removal, Sales Navigator Domains, Job Title Splitter, Apollo, Link Swapper and Chunks. Merge retains its existing backend endpoints.

Verification in this environment: 37 pytest tests passed, 1 skipped; 4 subtests passed. API smoke tests passed for merge, duplicates, blanks, sales domains, and output downloads. All inline JavaScript blocks passed node --check. Windows EXE launch and actual browser-click workflows have NOT been verified. No claim of production readiness or large-file UI performance. In-browser row analysis still loads datasets into browser memory; use caution with very large datasets.

No UI redesign was intended. Keep your original source ZIP as backup.
