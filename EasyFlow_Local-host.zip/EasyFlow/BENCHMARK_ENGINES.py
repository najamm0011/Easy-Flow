"""Phase24I optional engines: read + transform + CSV export, no ZIP."""
import argparse,csv,importlib.util,tempfile,time
from pathlib import Path

def generate(p,n):
    with p.open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['Email','Company Website','Full Name'])
        for i in range(n):
            k=i%20000
            w.writerow([f'p{k}@example.com','' if i%13==0 else f'company{k%1000}.com',f'First{k} Last{k}'])

def standard(src,dst,mode):
    with src.open(newline='',encoding='utf8') as f, dst.open('w',newline='',encoding='utf8') as g:
        reader=csv.DictReader(f);writer=csv.DictWriter(g,fieldnames=reader.fieldnames);writer.writeheader();seen=set()
        for row in reader:
            if mode=='duplicates':
                if row['Email'] in seen:continue
                seen.add(row['Email'])
            elif not row['Company Website'].strip():continue
            writer.writerow(row)

def polars(src,dst,mode):
    import polars as pl
    df=pl.read_csv(src,infer_schema_length=0)
    if mode=='duplicates':df=df.unique(subset=['Email'],keep='first',maintain_order=True)
    else:df=df.filter(pl.col('Company Website').str.strip_chars()!='')
    df.write_csv(dst)

def duckdb(src,dst,mode):
    import duckdb
    con=duckdb.connect(':memory:')
    try:
        path=str(src).replace("'","''");out=str(dst).replace("'","''")
        source=f"read_csv('{path}', all_varchar=true, header=true)"
        if mode=='duplicates':
            query=f'''SELECT "Email", "Company Website", "Full Name" FROM (SELECT *, row_number() OVER (PARTITION BY "Email" ORDER BY seq) rn FROM (SELECT *, row_number() OVER () seq FROM {source})) WHERE rn=1 ORDER BY seq'''
        else:query=f'''SELECT * FROM {source} WHERE length(trim("Company Website"))>0'''
        con.execute(f"COPY ({query}) TO '{out}' (HEADER, DELIMITER ',')")
    finally:con.close()

def validate(p,mode,n):
    count=0;seen=set()
    with p.open(newline='',encoding='utf8') as f:
        r=csv.DictReader(f)
        if r.fieldnames!=['Email','Company Website','Full Name']:raise AssertionError('Headers changed')
        for row in r:
            count+=1
            if mode=='duplicates':
                if row['Email'] in seen:raise AssertionError('Duplicate remains')
                seen.add(row['Email'])
            elif not row['Company Website'].strip():raise AssertionError('Blank remains')
    expected=min(n,20000) if mode=='duplicates' else n-sum(i%13==0 for i in range(n))
    if count!=expected:raise AssertionError(f'Expected {expected}, got {count}')
    return count

def main(n):
    with tempfile.TemporaryDirectory(prefix='ns_engines_') as td:
        base=Path(td);src=base/'source.csv';generate(src,n)
        print(f'Phase24I | rows={n} | CSV MB={src.stat().st_size/1048576:.2f}')
        print('Timings include CSV read + transform + CSV export, exclude generation and ZIP')
        for mode in ('duplicates','blanks'):
            for name,fn in [('stdlib',standard),('polars',polars),('duckdb',duckdb)]:
                if name!='stdlib' and importlib.util.find_spec(name) is None:
                    print(f'{mode}/{name}: NOT INSTALLED (optional)');continue
                dst=base/f'{mode}_{name}.csv'
                try:
                    start=time.perf_counter();fn(src,dst,mode);sec=time.perf_counter()-start
                    count=validate(dst,mode,n)
                    print(f'{mode}/{name}: Seconds={sec:.3f} Rows/sec={n/sec:.0f} Output={count} VALIDATED')
                except Exception as e:
                    print(f'{mode}/{name}: ERROR {type(e).__name__}: {e}')
                    if name=='stdlib':raise
        print('No application processing engine was changed.')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rows',type=int,default=100000);a=p.parse_args()
    if not 1<=a.rows<=2000000:p.error('rows must be 1..2,000,000')
    main(a.rows)
