EasyFlow — Integrated Performance Build
Included:
- Apollo column mapping compiled once per file; cached URL classification.
- Duplicate removal and master comparison use RAM-backed SQLite for input files <=160 MB (configurable via NS_DEDUPE_MEMORY_INPUT_MB); larger files use disk-backed SQLite.
- Blank removal uses optional Polars fast path on CSV >=1 MB; automatically falls back to streaming Python when Polars is unavailable or cannot parse the input.
- CSV Polars path reads columns as strings to preserve text identifiers, headers, and blanks.
- ZIP compression defaults to fast level 1; override NS_ZIP_LEVEL=6 for smaller archives.
- No dashboard changes, all existing modes retained.
- RUN_FULL_SPEED_TEST_WINDOWS.bat runs regression tests and performance benchmarks.
Optional: python -m pip install polars duckdb
Notes:
- Fast paths depend on file shape and installed dependencies; not guaranteed faster for every file.
- Benchmark 100K and 1M on your own PC; 5M and browser UI not yet validated.
- Polars is in-memory: on very large CSV files, use NS_POLARS_BLANKS=0 to force streaming.
- This is not a claim that every module has reached maximum possible performance.
