PHASE 13 - Apollo and Sales Navigator mapping update

Apollo raw input aliases:
zp_sEcm8 -> Full Name
zp_FEm_X -> Job Title
text-body-sm-regular -> Company Name
zp_sEcm8 href 5 -> Personal LinkedIn
zp_sEcm8 href 6 -> Company Website
zp_sEcm8 href 7 -> Company LinkedIn
zp_sEcm8 href 8 -> Facebook

Sales Navigator raw aliases:
first_name -> First Name
last_name -> Last Name
job_title -> Job Title
company_name -> Company Name
company_domain -> Company Website
city -> Location
email_first -> Email

Sales Navigator Raw Cleaning maps First Name and Last Name directly. No Full Name split step.
Apollo Raw Cleaning splits Full Name and preserves the other selected mapped columns, sorted by established priority.
Link Swapper selection dropdowns display up to five values per column.

IMPORTANT: This is a testing build. The dashboard's browser-side file reader may hang with large uploads; 60MB+ support has not been validated. Ambiguous/duplicate source headers still need manual verification. Original values are preserved. Test with small files first.
