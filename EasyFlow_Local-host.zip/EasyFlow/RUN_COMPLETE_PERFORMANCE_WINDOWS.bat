@echo off
cd /d "%~dp0"
echo === COMPLETE REGRESSION SUITE ===
python -m unittest discover -s tests -p "test_*.py" -q
if errorlevel 1 goto fail
echo === 100K CLEANING BENCHMARK ===
python BENCHMARK_CLEANING.py --rows 100000
if errorlevel 1 goto fail
echo === ENGINE COMPARISON ===
python BENCHMARK_ENGINES.py --rows 100000
if errorlevel 1 goto fail
echo === SYSTEM CAPABILITIES ===
python CHECK_PERFORMANCE_ENV.py
echo ALL CHECKS COMPLETED
pause
exit /b 0
:fail
echo A TEST FAILED. Copy the output to ChatGPT.
pause
exit /b 1
