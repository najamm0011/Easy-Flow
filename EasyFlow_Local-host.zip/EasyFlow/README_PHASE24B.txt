PHASE 24B - PROCESSING REGRESSION TESTS

Added tests/test_processing_regression.py with 7 unittest cases:
- single-file duplicate removal: keep first and preserve full rows and headers
- master comparison: fresh-only removal and master file unchanged
- blank removal: whitespace-only blanks and full-row removal
- Sales Navigator domain filtering: preserve complete source rows
- XLSX import and XLSX output ZIP
- simple and percentage chunks: headers and row counts
- zero-match output: header-only CSV

RUN_TESTS_WINDOWS.bat now runs the tests and displays success/failure.
Python command: python -m unittest discover -s tests -p "test_*.py" -v
Verified in this environment: 11 tests passed.

IMPORTANT: These tests cover small representative inputs only. Existing test_chunks.py,
test_cleaning_engine.py, and test_foundation.py use pytest-style functions,
so unittest discovery does not execute them. They can be run with pytest.
No processing, UI, or feature-visibility logic was modified in Phase 24B.
Windows GUI and large-file stress tests remain pending.
