EasyFlow — ALL-IN-ONE DESKTOP PACKAGING & QA CANDIDATE
=========================================================
INFO FINDER: excluded from delivery scope. Existing placeholder UI is not connected
and does not make enrichment requests.

Use on Windows:
1. Extract the ZIP into a writable folder.
2. INSTALL_WINDOWS.bat for local Python dependencies.
3. RUN_ALL_QA_WINDOWS.bat for regression, 100K, 1M, 5M and Chromium browser QA.
   Browser QA requires: python -m pip install playwright
                        python -m playwright install chromium
4. BUILD_WINDOWS_EXE.bat for a portable Windows folder containing EasyFlow.exe.
5. BUILD_INSTALLER_WINDOWS.bat for an installer (requires Inno Setup 6).
6. For development without packaging, START_LOCAL_WINDOWS.bat.

QA coverage: backend regression tests, API upload/processing/download/delete for
single dedupe, master dedupe, blanks, chunks, dashboard and health, ZIP CRC and
row count checks at 100K/1M/5M, optional real Chromium browser smoke test.

Limitations:
- Cannot cross-compile Windows EXE on Linux; EXE and installer must be generated
  and validated on a Windows computer. No prebuilt EXE in this ZIP.
- Cross-hardware compatibility requires actual tests on target machines.
- Browser QA requires optional Playwright + Chromium installation and internet
  during setup; the app itself can run offline after packaging.
- 5M stress test is intensive and needs ample free storage.
- No code signing certificate included. Installer is unsigned.
- This is a release candidate until Windows EXE, installer, browser, 5M and
  target-hardware acceptance tests pass.
