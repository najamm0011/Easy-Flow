@echo off
cd /d "%~dp0"
echo EasyFlow - 500,000 rows (profiling OFF, comparable benchmark)
python BENCHMARK_OVERVIEW.py --rows 500000
pause
