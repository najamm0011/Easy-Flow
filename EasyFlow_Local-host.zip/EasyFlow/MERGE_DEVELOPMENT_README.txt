EasyFlow - MERGE FUNCTIONAL DEVELOPMENT

This is the original glassmorphism UI with Append Merge backend integration.

RUN ON WINDOWS:
1. Extract ZIP.
2. Open EasyFlow folder.
3. Run START_WINDOWS.bat (install dependencies with INSTALL_WINDOWS.bat if necessary).
4. Open http://127.0.0.1:8000/dashboard if browser does not open automatically.
5. Open Merge, add 2 or more files, wait for row counts, click Process Merge and Download Merged File.

For a new portable executable run BUILD_WINDOWS_EXE.bat on Windows.
Do not open frontend/index.html directly: the Merge backend requires the local server.

Merge rules: CSV/TSV/XLSX; 2+ files; identical headers and order required; first header once; all data rows preserved; no deduplication; CSV/XLSX output; automatic CSV for Excel >1,048,575 data rows. File Preview only shows filenames and row counts. Input files are not modified.

Verified: 5 API tests (counts, merge, header validation, one-file validation, XLSX) and JS syntax checks. Windows EXE and actual browser click testing are not verified in this environment.
