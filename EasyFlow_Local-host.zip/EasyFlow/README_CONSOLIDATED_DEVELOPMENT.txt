EasyFlow - CONSOLIDATED BACKEND DEVELOPMENT BUILD
===================================================
Run INSTALL_WINDOWS.bat once, then START_WINDOWS.bat.
Original Phase 7 dashboard is preserved at /dashboard.

NEW DISK-BACKED PROCESSING API
POST /api/cleaning/process (multipart/form-data):
  file = CSV, TSV or XLSX
  mode = duplicates | master_compare | blanks | sales_domains |
         job_titles | sales_raw | apollo_raw | link_swapper
  config = JSON object specifying columns/mapping/selections
  fmt = csv | tsv | xlsx
  master = optional second file (master_compare)
Returns a download_url. GET that URL for a disk-generated ZIP64 archive.

Examples of config:
 duplicates: {"columns":["Email"]}
 master_compare: {"columns":["Email"],"master_columns":["Email"]}
 blanks: {"columns":["Company Website","Company LinkedIn"]}
 sales_domains: {"email_column":"Email","selected_domains":["gmail.com","__blank__"]}
 job_titles: {"job_column":"Job Title","selected_categories":["Owners & Founders"],"selected_titles":["Engineer"]}
 sales_raw: {"mapping":{"full_name":"Name","company_name":"Organization","job_title":"Title"}}
 apollo_raw: {"mapping":{"full_name":"Full Name","company_website":"Company Website","company_linkedin":"Company LinkedIn","personal_linkedin":"Personal LinkedIn","facebook":"Facebook"}}

IMPORTANT LIMITATIONS / UNFINISHED WORK
- Original dashboard's browser-side export buttons have NOT all been rewired to this API.
- Existing browser-side imports still load entire files in JS in several modules.
- Full offline vendor JS bundling and Info Finder integration are NOT complete.
- Browser Back to Dashboard does not guarantee cancellation of all backend cleaning jobs.
- Very large XLSX input/output, multi-sheet handling and 5GB stress tests are NOT validated.
- This is NOT the finished ready-to-use final release; it is an integrated engine development build.

Run engine tests: from project root, python -m pytest tests/test_cleaning_engine.py
(or set PYTHONPATH=. and run python tests/test_cleaning_engine.py)

BROWSER-BASED DEVELOPMENT CONSOLE
Visit http://127.0.0.1:8000/processing-console for a separate interface to
run the new backend modes. This is NOT yet integrated into the original
studio screens. The original dashboard remains at /dashboard.
