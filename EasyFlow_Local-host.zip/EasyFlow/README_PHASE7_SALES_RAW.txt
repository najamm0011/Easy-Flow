EasyFlow — Phase 7: Sales Navigator Raw Cleaning

Updated from Phase 6 project, preserving existing dashboard and other tools.

Changes:
- Sales Navigator > Raw Cleaning > Map Fields now has Full Name mapping only; separate First Name and Last Name dropdowns removed.
- Selecting Full Name is required before processing.
- On Process Data & Preview Names, splits Full Name at the first whitespace-delimited word: first word -> First Name; remainder -> Last Name.
- Mapped source columns are renamed to standard output headers.
- First Name and Last Name are always included; other mapped columns are included even if values happen to be blank.
- Displays a five-row processed preview using actual transformed output rows before export or transfer.
- Output and transfer actions remain as in the previous version.

Testing:
- HTML inline JavaScript passed Node syntax check.
- Windows browser end-to-end testing still required.
- Existing browser-based exports and memory limits remain; this release does not change the large-file engine.

Run: START_WINDOWS.bat (run INSTALL_WINDOWS.bat first if dependencies are not installed).
