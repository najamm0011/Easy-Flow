@echo off
cd /d "%~dp0"
python BENCHMARK_ENGINES.py --rows 100000
pause
