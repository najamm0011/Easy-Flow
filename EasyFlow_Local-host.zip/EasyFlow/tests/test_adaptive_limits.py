import csv, os, tempfile, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
from backend.modules.processing import process

class AdaptiveLimitTests(unittest.TestCase):
    def test_streaming_fallback_when_polars_cap_zero(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d); source=folder/'data.csv'
            with source.open('w',encoding='utf-8-sig',newline='') as stream:
                w=csv.writer(stream);w.writerow(['Email','ID'])
                for i in range(35000):w.writerow([' ' if i%11==0 else 'x@example.com',f'{i:08d}'])
            with patch.dict(os.environ,{'NS_POLARS_MAX_MB':'0'}):
                archive,stats=process(source,'.csv',folder/'output','blanks',{'columns':['Email']})
            self.assertEqual(stats['input_rows'],35000)
            self.assertEqual(stats['removed_rows'],3182)
            with zipfile.ZipFile(archive) as z:
                csv_name=next(n for n in z.namelist() if n.endswith('.csv'))
                self.assertEqual(len(z.read(csv_name).decode('utf-8-sig').splitlines()),stats['output_rows']+1)

    def test_master_compare_same_columns_preserves_fresh(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d);master=folder/'master.csv';fresh=folder/'fresh.csv'
            master.write_text('Email,Company\na@x.com,A\n',encoding='utf-8')
            fresh.write_text('Email,Company\na@x.com,New\nb@x.com,B\n',encoding='utf-8')
            with patch.dict(os.environ,{'NS_DEDUPE_MEMORY_INPUT_MB':'0'}):
                archive,stats=process(fresh,'.csv',folder/'out','master_compare',{'columns':['Email'],'master_path':str(master)})
            self.assertEqual((stats['output_rows'],stats['removed_rows']),(1,1))
            self.assertEqual(master.read_text(encoding='utf-8'),'Email,Company\na@x.com,A\n')
