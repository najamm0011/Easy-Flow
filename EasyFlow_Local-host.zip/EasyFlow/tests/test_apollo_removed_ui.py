from pathlib import Path

def test_apollo_not_in_dashboard():
    html=(Path(__file__).resolve().parents[1]/"frontend"/"index.html").read_text(encoding="utf-8")
    assert "id=\"apolloWork\"" not in html
    assert "apollo-panel" not in html.split("<script",1)[0].split("<div",1)[-1] or "openTool(\'apollo\'" not in html
    assert "openTool(\'apollo\'" not in html
