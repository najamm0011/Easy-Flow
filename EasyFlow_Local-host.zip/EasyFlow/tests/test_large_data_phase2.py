import csv
import os
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch
from backend.modules.processing import process


def test_large_data_default_sqlite_cross_batch_duplicates():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        src = root / 'data.csv'
        with src.open('w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['ID', 'Payload'])
            for i in range(22005):
                writer.writerow([str(i % 10001), 'row' + str(i)])
        with patch.dict(os.environ, {'NS_DEDUPE_ENGINE': 'auto', 'EASYFLOW_ALLOW_IN_MEMORY': '0'}):
            archive, stats = process(src, '.csv', root / 'result', 'duplicates', {'columns': ['ID']})
        assert stats['dedupe_engine'] == 'sqlite'
        assert stats['input_rows'] == 22005
        assert stats['output_rows'] == 10001
        assert stats['removed_rows'] == 12004
        with zipfile.ZipFile(archive) as z:
            with z.open('cleaned.csv') as stream:
                assert len(stream.readlines()) == 10002


def test_streaming_blank_removal_whitespace():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        src = root / 'data.csv'
        src.write_text('Name,Value\na,1\nb,  \nc,3\n', encoding='utf-8')
        archive, stats = process(src, '.csv', root / 'result', 'blanks', {'columns': ['Value']})
        assert stats['removed_rows'] == 1
        assert stats['output_rows'] == 2
        assert archive.exists()
