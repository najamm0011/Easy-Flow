from pathlib import Path


def test_workspace_reset_does_not_destroy_permanent_results_controls():
    html = (Path(__file__).resolve().parents[1] / 'frontend' / 'index.html').read_text(encoding='utf-8')
    assert "w.querySelectorAll('.data-overview,.results,.ns-apollo-preview,.ns-sales-preview')" not in html
    assert "w.querySelectorAll('.results').forEach(el=>{el.classList.remove('hidden')" in html
    for handler in ('salesRawDownload()', 'downloadJobZip()', 'downloadSales()'):
        assert handler in html
