import csv,io
from fastapi.testclient import TestClient
from backend.main import app

def csv_file(name, rows):
    buf=io.StringIO();csv.writer(buf).writerows(rows)
    return (name,buf.getvalue().encode('utf-8'),'text/csv')

def files():
    return [('files',csv_file('one.csv',[['Name','Email'],['A','a@x'],['B','b@x']])),('files',csv_file('two.csv',[['Name','Email'],['C','c@x']]))]

def test_merge_analyze_counts():
    r=TestClient(app).post('/api/merge/analyze',files=files());assert r.status_code==200
    assert r.json()['total_rows']==3
    assert [x['rows'] for x in r.json()['files']]==[2,1]

def test_merge_process_single_header_and_order():
    client=TestClient(app)
    r=client.post('/api/merge/process',files=files(),data={'fmt':'csv'});assert r.status_code==200
    content=client.get(r.json()['download_url']).content.decode('utf-8-sig')
    assert list(csv.reader(io.StringIO(content)))==[['Name','Email'],['A','a@x'],['B','b@x'],['C','c@x']]

def test_merge_accepts_different_headers():
    wrong=[('files',csv_file('one.csv',[['A'],['1']])),('files',csv_file('two.csv',[['B'],['2']]))]
    client=TestClient(app)
    analyzed=client.post('/api/merge/analyze',files=wrong)
    assert analyzed.status_code==200
    assert analyzed.json()['header']==['A']
    response=client.post('/api/merge/process',files=wrong)
    assert response.status_code==200
    merged=client.get(response.json()['download_url']).content.decode('utf-8-sig')
    assert list(csv.reader(io.StringIO(merged)))==[['A'],['1'],['2']]

def test_merge_rejects_one_file():
    assert TestClient(app).post('/api/merge/process',files=files()[:1]).status_code==400

def test_merge_xlsx():
    client=TestClient(app)
    r=client.post('/api/merge/process',files=files(),data={'fmt':'xlsx'});assert r.status_code==200
    from openpyxl import load_workbook
    workbook=load_workbook(io.BytesIO(client.get(r.json()['download_url']).content),read_only=True)
    assert list(workbook.active.values)==[('Name','Email'),('A','a@x'),('B','b@x'),('C','c@x')]
    workbook.close()


def test_merge_different_header_order_and_width_keeps_all_cells():
    inputs=[('files',csv_file('first.csv',[['Name','Email'],['Ali','ali@example.com']])),
            ('files',csv_file('second.csv',[['Email','Name','Extra'],['s@example.com','Sara','X']]))]
    client=TestClient(app)
    response=client.post('/api/merge/process',files=inputs,data={'fmt':'csv'})
    assert response.status_code==200, response.text
    rows=list(csv.reader(io.StringIO(client.get(response.json()['download_url']).content.decode('utf-8-sig'))))
    assert rows==[['Name','Email'],['Ali','ali@example.com'],['s@example.com','Sara','X']]
