from fastapi.testclient import TestClient
from backend.main import app
import json, zipfile, io

def test_merge_then_chunks_and_percentage():
    c=TestClient(app)
    refs=[]
    for name,body in [('one.csv',b'Email,Name\na@x.com,A\nb@y.com,B\n'),('two.csv',b'Email,Name\nc@z.com,C\n')]:
        r=c.post('/api/fast/upload',files={'file':(name,body,'text/csv')})
        assert r.status_code==200,r.text
        refs.append(r.json()['file_ref'])
    merged=c.post('/api/fast/merge',data={'file_refs':json.dumps(refs),'fmt':'csv'})
    assert merged.status_code==200,merged.text
    m=merged.json()
    assert m['rows']==3
    assert c.get(m['download_url']).status_code==200
    for mode,groups in [('simple',[]),('percentage',[{'percentage':20,'size':1},{'percentage':30,'size':1},{'percentage':50,'size':1}])]:
        r=c.post('/api/fast/chunks',data={'file_ref':m['file_ref'],'mode':mode,'size':2,'fmt':'csv','groups':json.dumps(groups)})
        assert r.status_code==200,r.text
        data=r.json()
        assert data['rows']==3
        assert len(data['outputs'])==(1 if mode=='simple' else 3)
        for o in data['outputs']:
            download=c.get(o['url'])
            assert download.status_code==200,download.text
            with zipfile.ZipFile(io.BytesIO(download.content)) as z:
                assert z.testzip() is None
