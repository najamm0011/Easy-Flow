import io, csv, json, unittest
from fastapi.testclient import TestClient
from backend.main import app

class ReleaseApiTests(unittest.TestCase):
    def test_dashboard_health_and_output_cleanup(self):
        with TestClient(app) as client:
            self.assertEqual(client.get('/dashboard').status_code,200)
            self.assertEqual(client.get('/api/health').status_code,200)
            data='Email,Name\na@example.com,First\na@example.com,Second\nb@example.com,Third\n'
            result=client.post('/api/cleaning/process',
                files={'file':('sample.csv',data.encode(),'text/csv')},
                data={'mode':'duplicates','config':json.dumps({'columns':['Email']}),'fmt':'csv'})
            self.assertEqual(result.status_code,200,result.text)
            info=result.json()
            self.assertEqual(info['stats']['output_rows'],2)
            self.assertEqual(client.get(info['download_url']).status_code,200)
            self.assertEqual(client.delete('/api/jobs/'+info['job_id']).status_code,200)
            self.assertEqual(client.get(info['download_url']).status_code,404)
