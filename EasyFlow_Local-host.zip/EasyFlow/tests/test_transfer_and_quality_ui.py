from pathlib import Path

def test_no_optional_quality_analysis_ui():
    html=(Path(__file__).resolve().parents[1]/'frontend'/'index.html').read_text()
    assert 'Analyze detailed data quality (optional)' not in html
    assert 'ns-universal-overview-disabled' in html

def test_duplicate_transfer_preserves_controls_and_server_processing():
    html=(Path(__file__).resolve().parents[1]/'frontend'/'index.html').read_text()
    assert "$('singleSettings').classList.remove('hidden')" in html
    assert "$('singleResults').classList.remove('hidden')" in html
    assert 'runSingle=nsRunSingleServer' in html
    assert "form.append('mode','duplicates')" in html
