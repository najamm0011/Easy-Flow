import unittest
from pathlib import Path
from backend.core.config import ROOT

class UiContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    def test_existing_ui_hooks(self):
        for token in ('id="chunkWork"', 'id="nsFinderPage"', 'id="workspace"', 'id="nsNewStudioOverlay"'):
            with self.subTest(token=token):
                self.assertIn(token, self.html)
    def test_icon_asset_path(self):
        self.assertTrue((ROOT / "frontend" / "assets" / "feature-chevron.png").is_file())
        self.assertIn('/assets/assets/feature-chevron.png', self.html)

if __name__ == "__main__":
    unittest.main()
