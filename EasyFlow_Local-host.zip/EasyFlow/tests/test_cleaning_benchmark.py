import unittest
from BENCHMARK_CLEANING import run
class CleaningBenchmarkSmokeTests(unittest.TestCase):
    def test_all_processing_modes_and_zip_integrity(self):
        run(1000)
