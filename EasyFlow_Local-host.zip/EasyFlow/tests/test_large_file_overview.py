"""Disk-backed overview regression tests (synthetic, modest-sized)."""
import csv
import tempfile
import threading
import unittest
from pathlib import Path
from backend.modules.overview import analyze

class OverviewStreamingTests(unittest.TestCase):
    def test_streamed_csv_counts_and_preview_bound(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'input.csv'
            with path.open('w',newline='',encoding='utf-8') as f:
                writer=csv.writer(f);writer.writerow(['Name','Email','Region'])
                for i in range(12000):
                    writer.writerow([f'Person {i%3000}',f'p{i%3000}@example.com',' ' if i%7==0 else 'West'])
            updates=[]
            result=analyze(path,'.csv',updates.append)
            self.assertEqual(result['rows'],12000)
            self.assertEqual(result['duplicate_rows'],12000-len({(i%3000, i%7==0) for i in range(12000)}))
            self.assertLessEqual(len(result['preview']),50)
            self.assertEqual(result['blank_rows'],sum(i%7==0 for i in range(12000)))
            self.assertEqual(result['unique_by_column'][0],3000)
            self.assertTrue(any(x['rows_scanned']>=2000 for x in updates))

    def test_cancelled_before_processing(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'input.csv';path.write_text('Name\nAlice\n',encoding='utf-8')
            event=threading.Event();event.set()
            with self.assertRaises(InterruptedError):analyze(path,'.csv',lambda x:None,event)
