import csv, tempfile, zipfile
from pathlib import Path
from backend.modules.chunks import build

def test_simple_and_percentage():
 with tempfile.TemporaryDirectory() as d:
  p=Path(d);src=p/'in.csv'
  with src.open('w',newline='') as f:
   w=csv.writer(f);w.writerow(['Name','Title']);w.writerows([[f'Person {i}','CEO'] for i in range(10)])
  outs,n=build(src,'.csv','csv','simple',4,[],p,'test')
  assert n==10 and len(outs)==1 and outs[0]['parts']==3
  with zipfile.ZipFile(outs[0]['path']) as z:
   assert len(z.namelist())==3
   assert all(z.read(x).decode('utf-8-sig').startswith('Name,Title') for x in z.namelist())
  outs,n=build(src,'.csv','csv','percentage',5,[{'percentage':20,'size':5},{'percentage':30,'size':5},{'percentage':50,'size':5}],p,'percent')
  assert n==10 and [x['rows'] for x in outs]==[2,3,5]
