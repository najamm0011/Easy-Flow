import unittest
from pathlib import Path
from unittest.mock import patch
from backend.core.config import ROOT
from desktop_launcher import ready
class DesktopReleaseTests(unittest.TestCase):
    def test_frontend_bundle_path(self):
        self.assertTrue((ROOT/'frontend'/'index.html').is_file())
    def test_launcher_imports(self):
        from backend.main import app
        self.assertTrue(app)
    def test_ready_closed_port(self):
        self.assertFalse(ready('127.0.0.1',0,timeout=0))
