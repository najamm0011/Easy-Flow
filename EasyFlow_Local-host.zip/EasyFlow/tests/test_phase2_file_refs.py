import io
import zipfile
from fastapi.testclient import TestClient
from backend.main import app

def test_upload_once_and_chain_without_reupload():
    client=TestClient(app)
    raw=b'Email,Name\na@company.com,A\na@company.com,B\nb@work.com,C\n'
    upload=client.post('/api/fast/upload',files={'file':('sample.csv',raw,'text/csv')})
    assert upload.status_code==200
    ref=upload.json()['file_ref']
    dedup=client.post('/api/fast/process',data={
        'file_ref':ref,'mode':'duplicates','config':'{"columns":["Email"]}','fmt':'csv'})
    assert dedup.status_code==200,dedup.text
    d=dedup.json()
    assert d['stats']['output_rows']==2
    assert d['file_ref']
    assert client.get(d['download_url']).status_code==200
    blank=client.post('/api/fast/process',data={
        'file_ref':d['file_ref'],'mode':'blanks','config':'{"columns":["Name"]}','fmt':'csv'})
    assert blank.status_code==200,blank.text
    assert blank.json()['stats']['input_rows']==2
    assert blank.json()['file_ref']
    assert client.get('/api/fast/files/'+blank.json()['file_ref']).status_code==200

def test_reference_preview_download_and_restore():
    client=TestClient(app)
    raw=b'Email,Name\na@gmail.com,A\nb@company.com,B\nc@company.com,C\n'
    up=client.post('/api/fast/upload',files={'file':('contacts.csv',raw,'text/csv')})
    assert up.status_code==200,up.text
    ref=up.json()['file_ref']
    preview=client.get('/api/fast/preview/'+ref).json()
    assert preview['filename']=='contacts.csv'
    assert len(preview['rows'])==3
    result=client.post('/api/fast/process',data={
        'file_ref':ref,'mode':'blanks','config':'{"columns":["Name"]}','fmt':'csv'})
    assert result.status_code==200,result.text
    out=result.json()
    assert out['file_ref']
    assert client.get('/api/fast/download/'+out['file_ref']).status_code==200
    assert client.get('/api/fast/files/'+ref).status_code==200
    assert client.get('/api/fast/files/'+out['file_ref']).status_code==200

def test_reference_merge_then_chunks():
    import json
    client=TestClient(app)
    refs=[]
    for name,data in [('one.csv',b'Email,Name\na@b.com,A\n'),('two.csv',b'Email,Name\nb@b.com,B\n')]:
        r=client.post('/api/fast/upload',files={'file':(name,data,'text/csv')})
        assert r.status_code==200,r.text
        refs.append(r.json()['file_ref'])
    merged=client.post('/api/fast/merge',data={'file_refs':json.dumps(refs),'fmt':'csv'})
    assert merged.status_code==200,merged.text
    assert merged.json()['rows']==2
    ref=merged.json()['file_ref']
    chunks=client.post('/api/fast/chunks',data={'file_ref':ref,'mode':'simple','size':'1','fmt':'csv'})
    assert chunks.status_code==200,chunks.text
    assert chunks.json()['rows']==2
    assert len(chunks.json()['outputs'])==1
    assert client.get(chunks.json()['outputs'][0]['url']).status_code==200
