import csv,time,zipfile
from pathlib import Path
from backend.core.job_manager import JobManager

def test_managed_job_completes_and_recovers(tmp_path):
    root=tmp_path/'jobs';manager=JobManager(root,workers=1)
    source=tmp_path/'input.csv'
    with source.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['ID','Value'])
        for i in range(10050):w.writerow([i%100,'x'])
    job=manager.submit(source,'.csv','duplicates',{'columns':['ID']})
    for _ in range(200):
        state=manager.status(job)
        if state['status'] in ('completed','failed'):break
        time.sleep(.05)
    assert state['status']=='completed',state
    with zipfile.ZipFile(manager.output(job)) as z:
        assert len(z.read('cleaned.csv').decode('utf-8-sig').splitlines())==101
    restored=JobManager(root,workers=1)
    assert restored.status(job)['status']=='completed'

def test_recover_interrupted_job(tmp_path):
    root=tmp_path/'jobs';folder=root/'abcd';folder.mkdir(parents=True)
    (folder/'state.json').write_text('{"id":"abcd","status":"running","updated_at":0}')
    manager=JobManager(root,workers=1,ttl=10**12)
    assert manager.status('abcd')['status']=='interrupted'
