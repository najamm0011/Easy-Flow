import os
import time
from pathlib import Path
from backend.core import large_data as ld


def test_resource_report_and_disk_check():
    info = ld.resources()
    assert info['mode'] == 'large_data'
    assert info['cpu_count'] >= 1
    assert info['disk_free_bytes'] > 0
    assert ld.check_storage()['mode'] == 'large_data'


def test_cleanup_preserves_active_and_recent(tmp_path, monkeypatch):
    monkeypatch.setattr(ld, 'TEMP', tmp_path / 'Temp')
    monkeypatch.setattr(ld, 'OUTPUTS', tmp_path / 'Outputs')
    monkeypatch.setattr(ld, 'RETENTION_SECONDS', 3600)
    for name in ('old', 'active', 'recent'):
        p = ld.TEMP / name
        p.mkdir(parents=True)
        (p / 'content').write_text('test')
    past = time.time() - 7200
    os.utime(ld.TEMP / 'old', (past, past))
    os.utime(ld.TEMP / 'active', (past, past))
    removed = ld.sweep_expired(active_paths=[ld.TEMP / 'active' / 'content'])
    assert len(removed) == 1
    assert not (ld.TEMP / 'old').exists()
    assert (ld.TEMP / 'active').exists()
    assert (ld.TEMP / 'recent').exists()
