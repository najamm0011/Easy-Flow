import csv, os, tempfile, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
from backend.modules.processing import process

class AdaptiveDedupeEquivalence(unittest.TestCase):
    def test_single_and_master_modes(self):
        with tempfile.TemporaryDirectory() as temp:
            base=Path(temp); source=base/'fresh.csv'; master=base/'master.csv'
            with source.open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f); w.writerow(['Email','Code','Extra'])
                w.writerows([['ALICE@TEST.COM','01','first'],[' alice@test.com ','01','duplicate'],['bob@test.com','02','keep'],['','03','blank'],['','03','repeat']])
            with master.open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f);w.writerow(['Email','Code','Extra']);w.writerow(['BOB@TEST.COM','02','master'])
            for mode,cfg in [('duplicates',{'columns':['Email','Code']}),('master_compare',{'columns':['Email','Code'],'master_columns':['Email','Code'],'master_path':str(master)})]:
                outputs=[]
                for engine in ['set','sqlite']:
                    with patch.dict(os.environ,{'NS_DEDUPE_ENGINE':engine}):
                        archive,stats=process(source,'.csv',base/(mode+'_'+engine),mode,cfg)
                    self.assertEqual(stats['dedupe_engine'],engine)
                    with zipfile.ZipFile(archive) as z:
                        csvfile=next(x for x in z.namelist() if x.endswith('.csv'))
                        outputs.append(z.read(csvfile))
                self.assertEqual(outputs[0],outputs[1])
