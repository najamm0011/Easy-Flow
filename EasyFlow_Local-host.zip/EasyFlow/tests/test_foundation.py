from fastapi.testclient import TestClient
from backend.main import app

def test_routes():
    c=TestClient(app)
    assert c.get('/api/health').json()['status']=='ok'
    assert c.get('/dashboard').status_code==200
    assert 'EasyFlow' in c.get('/dashboard').text
