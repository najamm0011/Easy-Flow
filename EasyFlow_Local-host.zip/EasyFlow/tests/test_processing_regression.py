"""Phase 24B: disk-backed import/process/export regression checks."""
import csv
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from openpyxl import Workbook
from backend.modules.chunks import build
from backend.modules.processing import process

class ProcessingRegressionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.p=Path(self.temp.name)
        self.headers=['First Name','Last Name','Company Name','Email','Company Website','Job Title']
        self.rows=[
            ['Ali','Khan','Acme','ali@acme.com','acme.com','CEO'],
            ['Ali','Khan','Acme','ali@acme.com','acme.com','CEO'],
            ['Sara','Iqbal','Beta','sara@gmail.com',' ','Director'],
            ['Omar','Ali','Acme','omar@acme.com','acme.com','Engineer'],
            ['Nida','Noor','Gamma','','gamma.com','Founder'],
        ]
        self.csv=self.p/'input.csv'
        with self.csv.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f);w.writerow(self.headers);w.writerows(self.rows)
        self.xlsx=self.p/'input.xlsx';wb=Workbook();ws=wb.active;ws.append(self.headers)
        for row in self.rows:ws.append(row)
        wb.save(self.xlsx)

    def extracted(self,archive):
        with zipfile.ZipFile(archive) as z:
            self.assertIsNone(z.testzip())
            datafiles=[n for n in z.namelist() if n.endswith('.csv')]
            self.assertTrue(datafiles)
            return [list(csv.reader(z.read(n).decode('utf-8-sig').splitlines())) for n in datafiles],json.loads(z.read('processing_summary.json'))

    def test_duplicates_keep_first_preserve_header_and_complete_row(self):
        a,_=process(self.csv,'.csv',self.p/'dedupe','duplicates',{'columns':['First Name','Last Name','Company Name','Email']})
        files,stats=self.extracted(a)
        self.assertEqual(stats['input_rows'],5);self.assertEqual(stats['removed_rows'],1)
        self.assertEqual(files[0][0],self.headers)
        self.assertEqual(files[0][1:], [self.rows[0],self.rows[2],self.rows[3],self.rows[4]])

    def test_master_comparison_only_removes_fresh_matches(self):
        master=self.p/'master.csv'
        with master.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f);w.writerow(self.headers);w.writerow(self.rows[0])
        before=master.read_bytes()
        a,_=process(self.csv,'.csv',self.p/'master_out','master_compare',{'master_path':str(master),'columns':['Email'],'master_columns':['Email']})
        files,stats=self.extracted(a)
        self.assertEqual(master.read_bytes(),before)
        self.assertEqual(stats['removed_rows'],2)
        self.assertEqual(files[0][1:],[self.rows[2],self.rows[3],self.rows[4]])

    def test_blank_removal_whitespace_and_full_rows(self):
        a,_=process(self.csv,'.csv',self.p/'blanks','blanks',{'columns':['Company Website','Email']})
        files,stats=self.extracted(a)
        self.assertEqual(stats['removed_rows'],2)
        self.assertEqual(files[0][1:],[self.rows[0],self.rows[1],self.rows[3]])

    def test_domain_filter_preserves_original_columns(self):
        a,_=process(self.csv,'.csv',self.p/'domains','sales_domains',{'email_column':'Email','selected_domains':['gmail.com']})
        files,stats=self.extracted(a)
        self.assertEqual(stats['output_rows'],1)
        self.assertEqual(files[0],[self.headers,self.rows[2]])

    def test_xlsx_import_and_export(self):
        a,stats=process(self.xlsx,'.xlsx',self.p/'xlsx_out','duplicates',{'columns':['Email']},fmt='xlsx')
        self.assertEqual(stats['output_rows'],4)
        with zipfile.ZipFile(a) as z:
            self.assertIsNone(z.testzip());self.assertTrue(any(n.endswith('.xlsx') for n in z.namelist()))

    def test_chunk_headers_and_counts(self):
        outputs,n=build(self.csv,'.csv','csv','simple',2,[],self.p/'chunks','dataset')
        self.assertEqual(n,5)
        with zipfile.ZipFile(outputs[0]['path']) as z:
            self.assertEqual(len(z.namelist()),3)
            for name in z.namelist():
                lines=list(csv.reader(z.read(name).decode('utf-8-sig').splitlines()))
                self.assertEqual(lines[0],self.headers)
                self.assertLessEqual(len(lines)-1,2)
        outs,n=build(self.csv,'.csv','csv','percentage',2,[{'percentage':20,'size':2},{'percentage':30,'size':2},{'percentage':50,'size':2}],self.p/'percent','dataset')
        self.assertEqual(n,5);self.assertEqual([o['rows'] for o in outs],[1,1,3])

    def test_zero_result_export_has_header_only(self):
        a,stats=process(self.csv,'.csv',self.p/'empty','sales_domains',{'email_column':'Email','selected_domains':['no-such-domain.invalid']})
        files,_=self.extracted(a)
        self.assertEqual(stats['output_rows'],0)
        self.assertEqual(files[0],[self.headers])

if __name__=='__main__':unittest.main()
