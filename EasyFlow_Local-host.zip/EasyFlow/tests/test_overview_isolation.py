import csv, tempfile, threading, unittest
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from backend.modules.overview import analyze

class OverviewIsolationTests(unittest.TestCase):
    def test_repeated_analysis_has_no_leftover_db(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'data.csv'
            p.write_text('Name,Email\nA,a@example.com\nA,a@example.com\n',encoding='utf-8')
            for _ in range(2):
                result=analyze(p,'.csv',lambda x:None)
                self.assertEqual(result['duplicate_rows'],1)
                self.assertFalse((Path(d)/'overview_keys.sqlite').exists())

    def test_parallel_analysis_isolated(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'data.csv'
            p.write_text('Name\nA\nA\nB\n',encoding='utf-8')
            with ThreadPoolExecutor(max_workers=2) as pool:
                results=list(pool.map(lambda _: analyze(p,'.csv',lambda x:None),range(2)))
            self.assertEqual([x['duplicate_rows'] for x in results],[1,1])

    def test_cancellation_cleans_up(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'data.csv';p.write_text('Name\nA\n',encoding='utf-8')
            cancel=threading.Event();cancel.set()
            with self.assertRaises(InterruptedError):analyze(p,'.csv',lambda x:None,cancel)
            self.assertFalse((Path(d)/'overview_keys.sqlite').exists())
