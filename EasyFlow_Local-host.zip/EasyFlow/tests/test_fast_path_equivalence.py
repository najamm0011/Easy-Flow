import csv, importlib.util, os, tempfile, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
from backend.modules.processing import process

class FastPathEquivalence(unittest.TestCase):
    @unittest.skipUnless(importlib.util.find_spec('polars'), 'polars optional')
    def test_polars_blanks_matches_streaming(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);src=base/'input.csv'
            with src.open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f);w.writerow(['Email','ID','Notes'])
                for i in range(50000):
                    w.writerow([(' ' if i%7==0 else f'a{i}@test.com'),f'{i:08d}','hello'])
            self.assertGreater(src.stat().st_size,1024*1024)
            cfg={'columns':['Email']}
            with patch.dict(os.environ,{'NS_POLARS_BLANKS':'0'}):
                a,sa=process(src,'.csv',base/'slow','blanks',cfg)
            with patch.dict(os.environ,{'NS_POLARS_BLANKS':'1','NS_POLARS_MAX_MB':'64'}):
                b,sb=process(src,'.csv',base/'fast','blanks',cfg)
            # Timings vary by engine and run; compare deterministic outcomes only.
            for field in ('input_rows','output_rows','removed_rows','conflicts'):
                self.assertEqual(sa[field],sb[field],field)
            def readzip(path):
                with zipfile.ZipFile(path) as z:
                    name=next(n for n in z.namelist() if n.endswith('.csv'))
                    return z.read(name).decode('utf-8-sig').splitlines()
            self.assertEqual(readzip(a),readzip(b))
