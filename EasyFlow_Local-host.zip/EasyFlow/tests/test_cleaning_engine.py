import csv, tempfile, zipfile, json
from pathlib import Path
from backend.modules.processing import process,link_type,split_name

def test_modes():
    with tempfile.TemporaryDirectory() as t:
        p=Path(t);source=p/'input.csv'
        with source.open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['Full Name','Job Title','Email','Company Website','Company LinkedIn','Personal LinkedIn','Facebook'])
            w.writerows([
                ['John Smith','Owner','john@abc.com','abc.com','','','linkedin.com/in/john'],
                ['Jane Doe','Founder','jane@gmail.com','facebook.com/abc','','','linkedin.com/company/abc'],
                ['John Smith','Owner','john@abc.com','abc.com','','','linkedin.com/in/john'],
                ['Other','Engineer','bad','','','','']])
        cases=[('duplicates',{'columns':['Full Name','Email']},3),('blanks',{'columns':['Company Website']},3),('sales_domains',{'email_column':'Email','selected_domains':['gmail.com']},1),('job_titles',{'job_column':'Job Title','selected_categories':['Owners & Founders']},3),('sales_raw',{'mapping':{'full_name':'Full Name','job_title':'Job Title'}},4),('apollo_raw',{'mapping':{'full_name':'Full Name','company_website':'Company Website','company_linkedin':'Company LinkedIn','personal_linkedin':'Personal LinkedIn','facebook':'Facebook'}},4)]
        for i,(mode,config,expected) in enumerate(cases):
            archive,stats=process(source,'.csv',p/('out'+str(i)),mode,config)
            assert stats['output_rows']==expected,(mode,stats)
            with zipfile.ZipFile(archive) as z:
                assert z.testzip() is None
                assert 'processing_summary.json' in z.namelist()
        assert link_type('linkedin.com/in/john')=='personal_linkedin'
        assert link_type('facebook.com/company')=='facebook'
        assert split_name('John Michael Smith')==('John','Michael Smith')

if __name__=='__main__':test_modes();print('cleaning engine tests passed')
