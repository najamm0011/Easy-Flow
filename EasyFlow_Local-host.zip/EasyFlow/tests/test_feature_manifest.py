import unittest
from backend.core.features import feature_manifest, public_features

class FeatureManifestTests(unittest.TestCase):
    def test_expected_features(self):
        features = public_features()
        self.assertEqual(features["info_finder"]["status"], "ui_only")
        for name in ("file_merge", "enrich_data", "individual_research"):
            self.assertEqual(features[name], {"status": "planned", "dashboard": False})
        for name in ("chunks", "duplicates", "blanks", "job_titles", "sales_navigator"):
            self.assertEqual(features[name]["status"], "active")
    def test_apollo_disabled(self):
        self.assertEqual(public_features()["apollo"], {"status": "disabled", "dashboard": False})
    def test_manifest_schema(self):
        self.assertEqual(feature_manifest()["schema_version"], 1)

if __name__ == "__main__":
    unittest.main()
