import io, json, csv, zipfile, unittest
from fastapi.testclient import TestClient
from backend.main import app

class FullApiWorkflows(unittest.TestCase):
    def setUp(self):
        self.client=TestClient(app)
        self.data=b'Email,Name,Title\na@example.com,A,CEO\na@example.com,B,CEO\n,NoEmail,CTO\nb@example.com,C,CTO\n'
    def tearDown(self):self.client.close()
    def clean(self,mode,config,master=None):
        files={'file':('sample.csv',self.data,'text/csv')}
        if master is not None:files['master']=('master.csv',master,'text/csv')
        r=self.client.post('/api/cleaning/process',files=files,data={'mode':mode,'config':json.dumps(config),'fmt':'csv'})
        self.assertEqual(r.status_code,200,r.text)
        info=r.json()
        download=self.client.get(info['download_url'])
        self.assertEqual(download.status_code,200)
        with zipfile.ZipFile(io.BytesIO(download.content)) as z:
            self.assertIsNone(z.testzip())
            csvfiles=[n for n in z.namelist() if n.endswith('.csv')]
            self.assertTrue(csvfiles)
            records=[]
            for n in csvfiles:
                records.extend(list(csv.DictReader(io.StringIO(z.read(n).decode('utf-8-sig')))))
        self.assertEqual(self.client.delete('/api/jobs/'+info['job_id']).status_code,200)
        self.assertEqual(self.client.get(info['download_url']).status_code,404)
        return info['stats'],records
    def test_duplicates_end_to_end(self):
        stats,rows=self.clean('duplicates',{'columns':['Email']})
        self.assertEqual((stats['input_rows'],stats['output_rows'],stats['removed_rows']),(4,3,1))
        self.assertEqual([r['Name'] for r in rows],['A','NoEmail','C'])
    def test_blanks_end_to_end(self):
        stats,rows=self.clean('blanks',{'columns':['Email']})
        self.assertEqual((stats['input_rows'],stats['output_rows'],stats['removed_rows']),(4,3,1))
    def test_master_comparison_end_to_end(self):
        stats,rows=self.clean('master_compare',{'columns':['Email'],'master_columns':['Email']},b'Email,Name,Title\na@example.com,Old,CEO\n')
        self.assertEqual(stats['output_rows'],2)
    def test_chunks_api_end_to_end(self):
        r=self.client.post('/api/chunks/process',files={'file':('data.csv',self.data,'text/csv')},data={'mode':'simple','size':'2','fmt':'csv','groups':'[]'})
        self.assertEqual(r.status_code,200,r.text)
        obj=r.json();self.assertEqual(obj['rows'],4)
        for output in obj['outputs']:
            download=self.client.get(output['url']);self.assertEqual(download.status_code,200)
            with zipfile.ZipFile(io.BytesIO(download.content)) as z:self.assertIsNone(z.testzip())
        self.assertEqual(self.client.delete('/api/jobs/'+obj['job_id']).status_code,200)
    def test_dashboard_and_static_files(self):
        self.assertEqual(self.client.get('/dashboard').status_code,200)
        self.assertEqual(self.client.get('/processing-console').status_code,200)
        self.assertEqual(self.client.get('/api/health').status_code,200)
        self.assertEqual(self.client.get('/api/features').status_code,200)
