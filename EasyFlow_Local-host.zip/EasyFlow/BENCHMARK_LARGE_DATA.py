"""Explicit 1M / 5M streaming benchmark; never run automatically at startup.
Usage: python BENCHMARK_LARGE_DATA.py --rows 1000000 --mode blanks
Requires sufficient disk space; reports actual measured memory and runtime.
"""
import argparse,csv,json,os,resource,sys,tempfile,time,zipfile
from pathlib import Path
from backend.modules.processing import process

def run(rows,mode):
    with tempfile.TemporaryDirectory(prefix='easyflow_bench_') as tmp:
        src=Path(tmp)/'input.csv'
        with src.open('w',newline='',encoding='utf-8') as f:
            w=csv.writer(f);w.writerow(['Company','ID','Email'])
            for i in range(rows):w.writerow(['Company'+str(i%100003),str(i%100003),' ' if i%37==0 else 'user@example.com'])
        started=time.perf_counter()
        config={'columns':['ID']} if mode=='duplicates' else {'columns':['Email']}
        archive,stats=process(src,'.csv',Path(tmp)/'output',mode,config,'csv')
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            assert 'cleaned.csv' in z.namelist()
        elapsed=time.perf_counter()-started
        peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return {'rows':rows,'mode':mode,'seconds':round(elapsed,3),'rows_per_second':round(rows/elapsed),
                'peak_rss_reported':peak,'peak_rss_unit':'KiB on Linux, bytes on macOS',
                'input_bytes':src.stat().st_size,'stats':stats}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rows',type=int,default=1000000);p.add_argument('--mode',choices=['blanks','duplicates'],default='blanks');a=p.parse_args()
    print(json.dumps(run(a.rows,a.mode),indent=2))
