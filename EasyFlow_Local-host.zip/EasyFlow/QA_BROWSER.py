"""Browser-level smoke test. Requires: python -m pip install playwright; python -m playwright install chromium"""
import threading, time, socket
import uvicorn
from backend.main import app

def main():
    try:from playwright.sync_api import sync_playwright
    except ImportError:raise SystemExit('Install optional browser QA: python -m pip install playwright && python -m playwright install chromium')
    sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
    config=uvicorn.Config(app,host='127.0.0.1',port=port,log_level='error')
    server=uvicorn.Server(config)
    thread=threading.Thread(target=server.run,daemon=True);thread.start()
    for _ in range(100):
        if server.started:break
        time.sleep(.05)
    if not server.started:raise RuntimeError('Browser QA server failed to start')
    try:
        with sync_playwright() as pw:
            browser=pw.chromium.launch(headless=True)
            page=browser.new_page()
            errors=[]
            page.on('pageerror',lambda error:errors.append(str(error)))
            response=page.goto(f'http://127.0.0.1:{port}/dashboard',wait_until='domcontentloaded')
            assert response.status==200
            assert 'EasyFlow' in page.title() or 'EasyFlow' in page.content()
            page.goto(f'http://127.0.0.1:{port}/processing-console',wait_until='domcontentloaded')
            assert page.locator('body').count()==1
            assert not errors, f'Browser JS errors: {errors}'
            browser.close()
            print('BROWSER QA PASSED: dashboard, processing console, JS console')
    finally:
        server.should_exit=True
        thread.join(timeout=10)
if __name__=='__main__':main()
