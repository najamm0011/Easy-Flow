@echo off
cd /d "%~dp0"
python BENCHMARK_CLEANING.py --rows 100000
if errorlevel 1 (echo BENCHMARK FAILED) else (echo BENCHMARK COMPLETE)
pause
