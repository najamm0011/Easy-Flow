EasyFlow — RELEASE READINESS CANDIDATE
=========================================
Start: INSTALL_WINDOWS.bat once; START_LOCAL_WINDOWS.bat thereafter.
Existing START_WINDOWS.bat supports NS_HOST / NS_PORT environment overrides.
START_LAN_WINDOWS.bat binds 0.0.0.0 (trusted private LAN ONLY).
This build is NOT a signed installable desktop app and is NOT production-certified.

New safeguards:
- Output jobs are tracked and expire after 24h by default (NS_JOB_TTL_HOURS).
  Expired outputs are deleted when another chunk/cleaning request or download arrives.
  Server restarts may leave old temporary folders; OS cleanup still required.
- DELETE /api/jobs/{job} deletes an output job and its temp files.
- Basic anti-framing and content-type response headers.
- Corrected Polars regression test compares output, not timing.
- Existing cleaning, dashboard, overview, and export logic retained.

SECURITY: This is a localhost-first development application. LAN mode does NOT
include authentication, TLS, user isolation, quotas or file upload limits.
Do not expose to the public internet, untrusted networks, or use with sensitive
third-party data in multi-user mode.

NOT COMPLETED:
- Info Finder is a UI placeholder without a configured data source or API.
  It cannot be delivered as working enrichment without provider requirements.
- Signed Windows installer / fully offline bundled Python runtime not provided.
- Browser automation, cross-device QA, 5M stress on multiple machines, crash
  recovery and resource-peak validation not complete.
- End-user acceptance testing still required.

RUN_FINAL_VALIDATION_WINDOWS.bat runs existing backend tests and benchmarks.
RUN_OPTIONAL_5M_STRESS_WINDOWS.bat is optional and resource-intensive.
