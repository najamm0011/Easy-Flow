EasyFlow — Phase 24A: safe feature registry + baseline regression tests

Added config/features.json and backend/core/features.py, with GET /api/features.
This registry describes statuses; it does NOT dynamically enable/disable dashboard cards or backend routes yet.
Existing UI and processing logic have deliberately not been changed.
Info Finder stays visible/UI-only. File Merge, Enrich and Individual Research are marked planned/hidden in the registry.
Their previous code/UI remnants have NOT been deleted, for future reactivation.
Added stdlib unittest feature/UI contract tests and RUN_TESTS_WINDOWS.bat.
Full processing regression tests, real Windows/browser tests and large-file performance testing are still pending.
To run tests: install requirements and (if necessary) httpx, then run RUN_TESTS_WINDOWS.bat.
