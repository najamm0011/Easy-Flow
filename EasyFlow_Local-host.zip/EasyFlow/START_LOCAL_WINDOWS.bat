@echo off
set "NS_HOST=127.0.0.1"
call "%~dp0START_WINDOWS.bat"
