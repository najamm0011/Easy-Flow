EasyFlow — High-Speed Phase 2 (incremental backend foundation)
==============================================================
New backend APIs:
 POST /api/fast/upload multipart file: stores one original upload, returns file_ref.
 POST /api/fast/process form: file_ref, mode, config JSON, fmt, optional master_ref.
     Returns downloadable ZIP job and next-stage file_ref when a single output
     CSV/TSV/XLSX exists inside the result.
 GET /api/fast/files/{file_ref}: metadata.
 DELETE /api/fast/files/{file_ref}: unregisters the reference.

Verified: Upload -> Duplicate Removal -> Blank Removal, with a single original upload.
Each stage's download URL remains available.

IMPORTANT LIMITATIONS:
- This is a backend foundation, NOT full UI wiring. Existing frontend upload and
  transfer flows still use their previous routes and need separate integration.
- Intermediate output is extracted from the cleaning ZIP; this saves network
  re-upload but not every disk read/write. A future phase should eliminate this.
- No parallel CPU processing has been enabled; profiling must establish whether
  it helps. No guaranteed speedup is claimed.
- File refs are local in-memory registry IDs and expire on server restart.
- Reference-based APIs should be protected with authentication/authorization
  before exposure to untrusted LAN users.
- XLSX maximum row count and physical disk/RAM limits still apply.
