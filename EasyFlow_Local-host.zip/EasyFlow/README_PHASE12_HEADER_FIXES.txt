PHASE 12 - Header normalization testing build

Sales Navigator > Domain Cleaning:
- Existing First Name and Last Name columns remain separate. No name splitting is performed in domain cleaning.
- Known column names are normalized to standard headers automatically; for unclear headers, high-confidence email/URL pattern recognition is used.
- Unknown/ambiguous fields remain marked as Unidentified Column N or keep their source header, to avoid incorrect classification.
- Domain priority categories and existing selection/export workflow are preserved.

Apollo > Raw Cleaning:
- Known column headers normalized on upload; high-confidence email/URL patterns also recognized.
- When Full Name is mapped, First Name and Last Name are generated and all other selected columns are retained in the processed output, with standardized headers when detected.
- Processed five-row preview remains available.

NOTE: This is a browser-side header normalization fix, NOT the promised full backend migration. Large file/browser-hang issue remains open. Full semantic detection of unknown Job Title, Company Name, and personal names from arbitrary values cannot be guaranteed; please verify unidentified columns and output.
