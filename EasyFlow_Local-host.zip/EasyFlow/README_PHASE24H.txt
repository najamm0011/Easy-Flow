Phase 24H — Apollo raw mapping optimization.
- Header name lookup compiled once per imported file rather than for each row.
- Retains mapped_row original API for other callers and unchanged output headers/ZIP.
- BENCHMARK_APOLLO_WINDOWS.bat tests Apollo only at 100,000 rows.
- Real-world Apollo file performance, browser responsiveness and memory remain unverified.
