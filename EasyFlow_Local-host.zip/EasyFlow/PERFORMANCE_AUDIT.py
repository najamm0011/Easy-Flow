"""Read-only baseline benchmark for EasyFlow core CSV cleaning paths.
Run: python PERFORMANCE_AUDIT.py --rows 100000
Results are local hardware-specific; no claims of universal speedup.
"""
import argparse,csv,json,tempfile,time,sys,platform
from pathlib import Path
from backend.modules.processing import process

def main(rows):
    with tempfile.TemporaryDirectory(prefix='ns_speed_audit_') as d:
        root=Path(d); source=root/'input.csv'
        t=time.perf_counter()
        with source.open('w',newline='',encoding='utf-8') as f:
            w=csv.writer(f);w.writerow(['Email','Company Website','Job Title'])
            for i in range(rows):w.writerow([f'person{i%max(1,rows//3)}@company.com','' if i%11==0 else 'company.com','CEO' if i%2 else 'Director'])
        generation=time.perf_counter()-t
        output={'platform':platform.platform(),'python':sys.version.split()[0],'rows':rows,'input_mb':round(source.stat().st_size/1048576,3),'generation_seconds':round(generation,4),'benchmarks':{}}
        for mode,config in [('blanks',{'columns':['Company Website']}),('duplicates',{'columns':['Email']})]:
            out=root/mode;start=time.perf_counter()
            archive,stats=process(source,'.csv',out,mode,config,'csv')
            elapsed=time.perf_counter()-start
            expected=rows-(rows+10)//11 if mode=='blanks' else max(1,rows//3)
            assert stats['input_rows']==rows,(mode,stats)
            assert stats['output_rows']==expected,(mode,stats,expected)
            assert archive.is_file()
            output['benchmarks'][mode]={'elapsed_seconds':round(elapsed,4),'rows_per_second':round(rows/elapsed),'input_rows':rows,'output_rows':stats['output_rows'],'archive_mb':round(archive.stat().st_size/1048576,3),'validated':True}
        print(json.dumps(output,indent=2))
        return output
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--rows',type=int,default=100000);args=parser.parse_args()
    if not 1<=args.rows<=2000000:parser.error('rows must be 1..2,000,000')
    main(args.rows)
