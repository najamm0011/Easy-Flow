Phase 24E — File Overview batched SQLite inserts.
- Retains the same analyze() result keys, progress and cancellation interface.
- Uses SQLite executemany batches (2000 rows) rather than per-cell INSERT calls.
- Maintains disk-backed distinct values and exact full-row duplicate fingerprints.
- BENCHMARK_PROFILE_WINDOWS.bat runs 500,000 synthetic rows from the correct directory.
- Optional psutil gives process RSS after the run; not peak RAM.
- No dashboard/UI, other processing modules, or Info Finder engine changes.
- Benchmark results must be measured on your Windows computer; speedup is not guaranteed.
