@echo off
cd /d "%~dp0"
echo === COMPLETE REGRESSION SUITE ===
python -m unittest discover -s tests -q
if errorlevel 1 goto fail
echo === 100K FULL CLEANING MODULE BENCHMARK ===
python BENCHMARK_CLEANING.py --rows 100000
if errorlevel 1 goto fail
echo === ENGINE COMPARISON ===
python BENCHMARK_ENGINES.py
if errorlevel 1 goto fail
echo === SYSTEM CAPABILITIES ===
python CHECK_PERFORMANCE_ENV.py
if errorlevel 1 goto fail
echo === 1M PIPELINE AND ZIP CRC CHECK ===
python BENCHMARK_PIPELINE.py --rows 1000000
if errorlevel 1 goto fail
echo ALL AUTOMATED CHECKS COMPLETED
pause
exit /b 0
:fail
echo VALIDATION FAILED - SHARE THIS OUTPUT
pause
exit /b 1
