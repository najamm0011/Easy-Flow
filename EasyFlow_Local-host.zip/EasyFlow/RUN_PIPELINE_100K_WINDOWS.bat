@echo off
cd /d "%~dp0"
python BENCHMARK_PIPELINE.py --rows 100000
pause
