Phase 24D: Focused overview robustness + performance measurement.
- Overview SQLite database now uses a unique temporary folder per analysis; cleanup on success, failure and cancellation; concurrent analyses do not share DB state.
- SQLite journal/sync disabled only for disposable overview scratch DB (not persistent user data).
- BENCHMARK_WINDOWS.bat added; BENCHMARK_OVERVIEW.py now reports rows/sec, input size and peak Python allocation (NOT total RAM).
- Added isolation, repeated-analysis, cancellation regression tests.
- Dashboard, other processing algorithms and feature registry unchanged.
- This phase does NOT yet implement streaming for every module, or complete cancellation/progress across every operation.
Run tests: RUN_TESTS_WINDOWS.bat
Run baseline: BENCHMARK_WINDOWS.bat
Larger runs: python BENCHMARK_OVERVIEW.py --rows 500000 (then 1000000 if safe).
