"""Compatibility entry point. Uses the same unified benchmark without tracemalloc by default."""
from BENCHMARK_OVERVIEW import main

if __name__ == '__main__':
    main()
