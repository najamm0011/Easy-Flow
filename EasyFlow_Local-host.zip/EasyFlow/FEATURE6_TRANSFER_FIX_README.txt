Feature 6 Filter Emails -> Duplicate/Blank Removal transfer fix
- Transfer processed Filter Emails output automatically as a CSV File object.
- Duplicate uses its existing backend uploader, animated upload bar, 10-row preview and data quality popup.
- Blank uses its existing upload animation and cleaning logic; added the agreed 10-row preview and column quality popup.
- Back to Filter Emails remains visible and retains filtered processing and download.
- Revisiting the same processed source retains each downstream result and its download link.
- Global File Summary filename injection no longer duplicates the local filename label.
- Full browser end-to-end tests not performed; run both paths on localhost.
