EasyFlow — Next Performance Build
Focus: general-purpose hardware-agnostic stability and scalable large-file testing.
- Preserves existing modules, UI, and prior optimization.
- Caps optional Polars in-memory Blank Removal fast path to 64MB input by default; set NS_POLARS_MAX_MB to change it, or NS_POLARS_BLANKS=0 to disable. Larger inputs stream.
- SQLite RAM dedupe threshold considers combined master+fresh input bytes (default 160MB, NS_DEDUPE_MEMORY_INPUT_MB to configure). Larger inputs use disk-backed SQLite.
- Added test_fast_path_equivalence: validates Polars blank filter against streaming output if Polars is installed.
- RUN_FULL_SPEED_TEST_WINDOWS.bat: full existing test and 100K benchmarks.
- BENCHMARK_1M_WINDOWS.bat: 1M row full cleaning benchmark (may take time/disk space).
- Benchmarks include process and ZIP export, exclude input generation and browser.
- Full browser, RAM-peak and 5M validation still pending. No specific PC targeted.

FIX: Fast-path equivalence test now generates 50,000 records, exceeding its 1MB activation threshold. No production processing code changed.
