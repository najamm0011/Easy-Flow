"""Unified synthetic File Overview benchmark. Time excludes dataset generation.

Examples:
 python BENCHMARK_OVERVIEW.py --rows 500000
 python BENCHMARK_OVERVIEW.py --rows 500000 --profile-python
"""
import argparse
import csv
import os
import tempfile
import time
from pathlib import Path
from backend.modules.overview import analyze


def main(argv=None):
    p = argparse.ArgumentParser(description='Unified File Overview benchmark')
    p.add_argument('--rows', type=int, default=100000)
    p.add_argument('--profile-python', action='store_true', help='Enable tracemalloc (adds substantial runtime overhead)')
    args = p.parse_args(argv)
    if not 1 <= args.rows <= 2_000_000:
        p.error('Rows must be between 1 and 2,000,000')
    with tempfile.TemporaryDirectory(prefix='ns_benchmark_') as folder:
        path = Path(folder) / 'synthetic.csv'
        with path.open('w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(['Name', 'Email', 'Company'])
            for i in range(args.rows):
                writer.writerow([f'Person {i%20000}', f'p{i%20000}@example.com', f'Company {i%1000}'])
        if args.profile_python:
            import tracemalloc
            tracemalloc.start()
        start = time.perf_counter()
        result = analyze(path, '.csv', lambda _: None)
        seconds = time.perf_counter() - start
        print('Benchmark: File Overview (unified)')
        print('Python allocation profiling:', 'ON (slow)' if args.profile_python else 'OFF (comparable speed)')
        print('Rows:', result['rows'])
        print('Duplicates:', result['duplicate_rows'])
        print('Input MB:', round(path.stat().st_size / 1024**2, 2))
        print('Seconds:', round(seconds, 2))
        print('Rows/second:', round(result['rows'] / seconds))
        if args.profile_python:
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            print('Peak Python allocations MB:', round(peak / 1024**2, 2))
            print('Note: Python allocations exclude SQLite/native memory; not total RAM.')
        try:
            import psutil
            print('Process RSS MB (end, not peak):', round(psutil.Process(os.getpid()).memory_info().rss / 1024**2, 2))
        except ImportError:
            print('Process RSS: unavailable (optional psutil not installed)')
    return result


if __name__ == '__main__':
    main()
