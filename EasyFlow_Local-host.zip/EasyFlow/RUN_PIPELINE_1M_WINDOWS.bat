@echo off
cd /d "%~dp0"
python BENCHMARK_PIPELINE.py --rows 1000000
pause
