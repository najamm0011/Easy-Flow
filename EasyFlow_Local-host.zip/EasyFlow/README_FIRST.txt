EasyFlow Phase 2 - Chunks Studio backend

1. Run INSTALL_WINDOWS.bat once (internet required for Python dependencies).
2. Run START_WINDOWS.bat, open http://127.0.0.1:8000/dashboard
3. Open Chunks Studio, upload CSV/TSV/XLSX, choose Simple or Percentage, generate ZIP and download.
4. Other studios are still using the original HTML/browser logic; not yet backend-integrated.
5. Large-file streaming is implemented server-side, but 5GB processing is not yet stress-tested.
6. Generated ZIPs live in the OS temp folder until cleared/restarted; do not use for sensitive files on shared PCs without cleanup.
7. Excel is limited to 1,048,576 rows per worksheet; choose CSV for larger chunks.
8. Percent mode produces one ZIP per group.

PHASE 2 FIX: Chunk upload now calls /api/chunks/analyze and displays row count, column count and original headers. For large files analysis may take time.

PHASE 3: Universal overview automatically appears for every file-upload input.
CSV/TSV/XLSX: upload progress + backend scanning status + first 10 rows, columns, blank counts, full-row duplicate counts.
Upload percent measures bytes transmitted; row analysis shows a scanned-record count (not a fake percent).
For very large files, existing studio processing is not yet fully disk-streamed.

PHASE 4: All file inputs now share one universal overview: File Summary -> Column-wise Data Quality (Filled, Blank, Unique) -> Data Preview (10/25/50). Legacy upload bars are hidden; the sole upload bar disappears when analysis completes. Unique values exclude blanks. Processing is disk-backed and may take time for large files.
