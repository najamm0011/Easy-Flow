@echo off
cd /d "%~dp0"
echo EasyFlow 1 Million Rows Cleaning Benchmark
python BENCHMARK_CLEANING.py --rows 1000000
pause
