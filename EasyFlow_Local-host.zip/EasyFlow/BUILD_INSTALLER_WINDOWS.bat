@echo off
setlocal
cd /d "%~dp0"
if not exist "dist\EasyFlow\EasyFlow.exe" (
  echo Portable EXE missing; building it first...
  call BUILD_WINDOWS_EXE.bat
  if errorlevel 1 goto fail
)
where ISCC.exe >nul 2>nul
if errorlevel 1 (
  if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" (
    "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "EasyFlow_Installer.iss"
    goto done
  )
  echo Inno Setup 6 is required for installer generation.
  echo Install it and rerun this script. Portable EXE is already available.
  pause
  exit /b 1
)
ISCC.exe "EasyFlow_Installer.iss"
:done
if errorlevel 1 goto fail
echo Installer generated in installer_output folder.
pause
exit /b 0
:fail
echo Packaging failed; copy the output for troubleshooting.
pause
exit /b 1
