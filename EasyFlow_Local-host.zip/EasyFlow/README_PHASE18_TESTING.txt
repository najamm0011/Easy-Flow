EasyFlow Phase 18 — integration repair testing build
Changes: numeric dashboard headings; original master/fresh column sample values;
Excel reader for Chunks/Duplicate upload where XLSX browser library loads;
correct XLSX serialization for Single/Master Duplicate exports;
XLSX default on duplicate exports; new module universal overview hook;
upload drop-zone text stays generic.
IMPORTANT: File Merge and Enrich are interface-only; all-module format/ZIP support
and reliable 60MB+ browser uploads are NOT complete. The XLSX/JSZip libraries
are still fetched from public CDNs and therefore require internet.
Test original modules one at a time; do not deploy to team as production.
