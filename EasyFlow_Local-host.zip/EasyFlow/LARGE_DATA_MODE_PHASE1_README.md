# EasyFlow Large Data Mode — Phase 1

This release begins the **Large Data Mode only** implementation. It is not a
claim of full multi-million-row validation.

Implemented:
- backend/core/large_data.py: available RAM (if psutil installed), CPU, disk
  resource reporting, conservative storage preflight, managed per-job Temp
  folders, 24-hour expiry sweep that protects active folders.
- Existing processing routes now allocate their workspaces in the managed
  EasyFlow/Temp directory rather than unrelated system-temp locations.
- GET /api/system/resources provides resource details.
- Deduplication uses disk-backed SQLite by default. The optional in-memory
  Polars blank-cleaning fast path is disabled by default; it can be explicitly
  enabled with EASYFLOW_ALLOW_IN_MEMORY=1.
- On server startup, old managed Temp/Outputs folders are swept, while recent
  folders remain untouched.

Configuration:
- EASYFLOW_WORK_ROOT: optional location for managed Temp/Outputs/Logs.
- EASYFLOW_RETENTION_HOURS: default 24 (minimum 1 hour).
- Install psutil for RAM visibility; CPU/disk checks work without it.

Not yet implemented / limitations:
- Existing output files still reside inside their processing workspaces until
  expiry. The new Outputs directory is reserved for a future migration.
- No cross-request persistent job registry or robust cancel/restart yet.
- No streaming multipart upload preflight based on known upload size yet.
- Large-data optimizations are not yet complete for all feature paths.
- No 1M/5M row 8GB RAM benchmark has been run for this build.
- Existing download/feature behavior is intended to remain unchanged.
