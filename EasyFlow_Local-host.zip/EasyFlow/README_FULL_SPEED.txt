EasyFlow — Full Speed Combined Build (first integrated optimization pass)
- All original modules and frontend included; no removal of features.
- Apollo mapping header indices cached per file (Phase24H).
- Link URL classification cached (LRU) to avoid repeated urlparse on common values.
- SQLite dedupe/master comparison uses a single transaction and memory journal to reduce HDD I/O.
- ZIP compression defaults to level 1 for faster CPU-limited exports; NS_ZIP_LEVEL=6 restores higher compression.
- Existing stdlib engine retained for duplicate and blank removal; Polars/DuckDB comparison benchmark included, but no unverified wholesale switch.
- One-click RUN_FULL_SPEED_TEST_WINDOWS.bat runs tests, four cleaning benchmarks and engine comparison.
- Caution: this is NOT yet a verified maximum-speed build; 1M/5M RAM, browser responsiveness and XLSX remain to be measured.
- Optional dependencies Polars/DuckDB are only needed for comparison benchmark, not core app.
