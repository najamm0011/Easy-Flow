import json, shutil, tempfile, uuid, os, time, threading
from pathlib import Path
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from backend.core.config import ROOT
from backend.core.large_data import workspace, resources, sweep_expired, check_storage
from backend.modules.chunks import build, safe_name, FORMATS, iter_records

app=FastAPI(title='EasyFlow',version='1.0.0-rc')
app.mount('/assets',StaticFiles(directory=str(ROOT/'frontend')),name='assets')
JOBS={}
JOB_TIMES={}
PROCESS_TIMES={}
JOB_LOCK=threading.RLock()
JOB_TTL_SECONDS=max(300,int(os.environ.get('NS_JOB_TTL_HOURS','24'))*3600)

def cleanup_expired_jobs():
    """Remove expired temporary output directories, avoiding indefinite disk growth."""
    now=time.time()
    expired=[]
    with JOB_LOCK:
        for registry, timestamps in ((JOBS,JOB_TIMES),(PROCESS_JOBS,PROCESS_TIMES),(MERGE_JOBS,MERGE_TIMES)):
            for job, created in list(timestamps.items()):
                if now-created>JOB_TTL_SECONDS:
                    paths=registry.pop(job, None)
                    timestamps.pop(job,None)
                    if paths:
                        expired.extend(paths if isinstance(paths,list) else [paths])
    for path in expired:
        path=Path(path)
        if path.exists():
            shutil.rmtree(path.parent.parent if path.parent.name=='outputs' else path.parent,ignore_errors=True)

@app.middleware('http')
async def security_headers(request,call_next):
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['X-Frame-Options']='DENY'
    return response
@app.get('/',include_in_schema=False)
def home():return RedirectResponse('/dashboard')
@app.get('/dashboard',include_in_schema=False)
def dashboard():return FileResponse(ROOT/'frontend'/'index.html',media_type='text/html')
@app.get('/api/system/resources')
def system_resources():
    return resources()

@app.get('/api/health')
def health():return {'status':'ok','app':'EasyFlow','version':'1.0.0-rc'}
from backend.core.features import public_features

@app.get('/api/features')
def features():
    return {'features': public_features()}

@app.get('/api/modules')
def modules():return {'status':'chunks_ready','modules':['chunks','duplicates','blanks','job_titles','sales_navigator','info_finder']}

@app.post('/api/chunks/analyze')
def chunks_analyze(file:UploadFile=File(...)):
    suffix=Path(file.filename or '').suffix.lower()
    if suffix not in FORMATS:raise HTTPException(400,'Supported input: CSV, TSV, XLSX')
    work=workspace(prefix='ns_analyze_')
    try:
        src=work/('upload'+suffix)
        with src.open('wb') as output:shutil.copyfileobj(file.file,output,length=1024*1024)
        iterator=iter_records(src,suffix)
        try:header=next(iterator)
        except StopIteration:raise HTTPException(400,'File is empty')
        count=sum(1 for _ in iterator)
        return {'filename':file.filename,'rows':count,'columns':len(header),'headers':[str(v) for v in header]}
    except (UnicodeError,ValueError) as exc:raise HTTPException(400,str(exc))
    finally:
        file.file.close()
        shutil.rmtree(work,ignore_errors=True)

@app.post('/api/chunks/process')
def chunks_process(file:UploadFile=File(...),mode:str=Form('simple'),size:int=Form(0),fmt:str=Form('csv'),groups:str=Form('[]')):
    suffix=Path(file.filename or '').suffix.lower()
    if suffix not in FORMATS:raise HTTPException(400,'Supported input: CSV, TSV, XLSX')
    work=workspace(prefix='ns_chunks_')
    try:
        src=work/('upload'+suffix)
        with src.open('wb') as f:shutil.copyfileobj(file.file,f,length=1024*1024)
        try:parsed=json.loads(groups)
        except json.JSONDecodeError:raise ValueError('Invalid group configuration')
        results,rows=build(src,suffix,fmt,mode,size,parsed,work,safe_name(Path(file.filename).stem))
        cleanup_expired_jobs()
        job=uuid.uuid4().hex
        with JOB_LOCK:
            JOBS[job]=[Path(r['path']) for r in results]
            JOB_TIMES[job]=time.time()
        return {'job_id':job,'rows':rows,'outputs':[{'filename':r['filename'],'parts':r['parts'],'rows':r['rows'],'url':'/api/chunks/download/'+job+'/'+str(i)} for i,r in enumerate(results)]}
    except (ValueError,KeyError,TypeError) as e:
        shutil.rmtree(work,ignore_errors=True);raise HTTPException(400,str(e))
    except Exception:
        shutil.rmtree(work,ignore_errors=True);raise
    finally:file.file.close()
@app.get('/api/chunks/download/{job}/{index}')
def chunks_download(job:str,index:int):
    cleanup_expired_jobs()
    with JOB_LOCK:work=JOBS.get(job)
    if not work:raise HTTPException(404,'Output not found or server restarted')
    archives=work
    if index<0 or index>=len(archives):raise HTTPException(404,'File not found')
    return FileResponse(archives[index],filename=archives[index].name,media_type='application/zip')


# Universal file overview: upload is streamed to disk; analysis runs independently.
from threading import Thread, Lock, Event
from backend.modules.overview import analyze as analyze_overview
OVERVIEW_JOBS={}
OVERVIEW_LOCK=Lock()
OVERVIEW_CANCEL={}

def update_overview(job, **fields):
    with OVERVIEW_LOCK:
        if job in OVERVIEW_JOBS: OVERVIEW_JOBS[job].update(fields)

def overview_worker(job, source, suffix, folder, original_name):
    try:
        update_overview(job,phase='analyzing',message='Reading columns and scanning rows')
        result=analyze_overview(source,suffix,lambda d:update_overview(job,**d),OVERVIEW_CANCEL[job])
        if OVERVIEW_CANCEL[job].is_set():raise InterruptedError('Analysis cancelled')
        result['filename']=original_name
        update_overview(job,phase='ready',message='Analysis complete',result=result)
    except InterruptedError:
        update_overview(job,phase='cancelled',message='Analysis cancelled')
    except Exception as exc:
        update_overview(job,phase='error',message=str(exc))
    finally:
        shutil.rmtree(folder,ignore_errors=True)
        with OVERVIEW_LOCK:OVERVIEW_CANCEL.pop(job,None)

@app.post('/api/overview/start')
def overview_start(file:UploadFile=File(...)):
    suffix=Path(file.filename or '').suffix.lower()
    if suffix not in FORMATS:raise HTTPException(400,'Overview supports CSV, TSV and XLSX')
    folder=workspace(prefix='ns_overview_')
    source=folder/('upload'+suffix)
    try:
        with source.open('wb') as out:shutil.copyfileobj(file.file,out,length=1024*1024)
    except Exception:
        shutil.rmtree(folder,ignore_errors=True);raise
    finally:file.file.close()
    job=uuid.uuid4().hex
    with OVERVIEW_LOCK:
        OVERVIEW_JOBS[job]={'phase':'queued','message':'Upload complete; analysis queued','rows_scanned':0}
        OVERVIEW_CANCEL[job]=Event()
    Thread(target=overview_worker,args=(job,source,suffix,folder,file.filename),daemon=True).start()
    return {'job_id':job}

@app.get('/api/overview/status/{job}')
def overview_status(job:str):
    with OVERVIEW_LOCK:
        state=OVERVIEW_JOBS.get(job)
        if not state:raise HTTPException(404,'Analysis job not found')
        return dict(state)

@app.post('/api/overview/cancel/{job}')
def overview_cancel(job:str):
    with OVERVIEW_LOCK:
        event=OVERVIEW_CANCEL.get(job)
        if event is not None:
            event.set()
            OVERVIEW_JOBS[job].update(phase='cancelling',message='Cancelling analysis')
            return {'status':'cancelling'}
        state=OVERVIEW_JOBS.get(job)
        if state is None:raise HTTPException(404,'Analysis job not found')
        return {'status':state['phase']}

# Consolidated disk-backed cleaning API (Phase 8).
from backend.modules.processing import process as process_cleaning
PROCESS_JOBS={}
@app.post('/api/cleaning/process')
def cleaning_process(file:UploadFile=File(...),mode:str=Form(...),config:str=Form('{}'),fmt:str=Form('csv'),master:UploadFile|None=File(None)):
    suffix=Path(file.filename or '').suffix.lower()
    if suffix not in FORMATS:raise HTTPException(400,'Supported input: CSV, TSV, XLSX')
    folder=workspace(prefix='ns_cleaning_')
    try:
        source=folder/('source'+suffix)
        with source.open('wb') as out:shutil.copyfileobj(file.file,out,length=1024*1024)
        settings=json.loads(config)
        if mode=='master_compare':
            if master is None:raise ValueError('Master file is required')
            master_suffix=Path(master.filename or '').suffix.lower()
            if master_suffix not in FORMATS:raise ValueError('Unsupported master format')
            master_path=folder/('master'+master_suffix)
            with master_path.open('wb') as out:shutil.copyfileobj(master.file,out,length=1024*1024)
            settings['master_path']=str(master_path)
        archive,stats=process_cleaning(source,suffix,folder/'outputs',mode,settings,fmt)
        cleanup_expired_jobs()
        job=uuid.uuid4().hex
        with JOB_LOCK:
            PROCESS_JOBS[job]=archive
            PROCESS_TIMES[job]=time.time()
        return {'job_id':job,'stats':stats,'download_url':'/api/cleaning/download/'+job}
    except (ValueError,KeyError,TypeError,json.JSONDecodeError) as e:
        shutil.rmtree(folder,ignore_errors=True);raise HTTPException(400,str(e))
    except Exception:
        shutil.rmtree(folder,ignore_errors=True);raise
    finally:
        file.file.close()
        if master:master.file.close()

@app.get('/api/cleaning/download/{job}')
def cleaning_download(job:str):
    cleanup_expired_jobs()
    with JOB_LOCK:path=PROCESS_JOBS.get(job)
    if path is None or not path.exists():raise HTTPException(404,'Output not found')
    return FileResponse(path,filename=path.name,media_type='application/zip')

@app.get('/processing-console',include_in_schema=False)
def processing_console():
    return FileResponse(ROOT/'frontend'/'processing-console.html',media_type='text/html')

@app.delete('/api/jobs/{job}')
def delete_output(job:str):
    """Delete an exported job and its temporary files after the user downloads it."""
    with JOB_LOCK:
        paths=JOBS.pop(job,None)
        JOB_TIMES.pop(job,None)
        if paths is None:
            path=PROCESS_JOBS.pop(job,None)
            PROCESS_TIMES.pop(job,None)
            paths=[path] if path else None
    if paths is None:raise HTTPException(404,'Job not found')
    for path in paths:
        path=Path(path)
        shutil.rmtree(path.parent.parent if path.parent.name=='outputs' else path.parent,ignore_errors=True)
    return {'status':'deleted'}


# Append-only merge: use the first file header, skip headers in subsequent files.
# Rows are appended by position; no header-name comparison or column mapping.
import csv as _merge_csv
from backend.modules.chunks import PartWriter as _MergeWriter
MERGE_JOBS={}
MERGE_TIMES={}

@app.post('/api/merge/analyze')
def merge_analyze(files:list[UploadFile]=File(...)):
    if len(files)<1:raise HTTPException(400,'Upload at least one file')
    details=[];reference=None
    try:
        for upload in files:
            suffix=Path(upload.filename or '').suffix.lower()
            if suffix not in FORMATS:raise HTTPException(400,'Supported input: CSV, TSV, XLSX')
            temp=workspace(prefix='ns_merge_analyze_')
            try:
                source=temp/('source'+suffix)
                with source.open('wb') as output:shutil.copyfileobj(upload.file,output,length=1024*1024)
                it=iter_records(source,suffix)
                try:header=[str(x) for x in next(it)]
                except StopIteration:raise HTTPException(400,f'{upload.filename}: empty file')
                if reference is None:reference=header
                rows=0; blanks=0; col_blanks=[]; preview=[]
                for row in it:
                    rows+=1
                    if len(preview)<10:preview.append([str(v) if v is not None else '' for v in row])
                    for j,v in enumerate(row):
                        if j>=len(col_blanks):col_blanks.extend([0]*(j+1-len(col_blanks)))
                        if not str(v if v is not None else '').strip():
                            blanks+=1;col_blanks[j]+=1
                details.append({'filename':upload.filename,'rows':rows,'blanks':blanks,'column_blanks':col_blanks,'preview':preview,'header':header})
            finally:shutil.rmtree(temp,ignore_errors=True)
        return {'files':details,'total_rows':sum(x['rows'] for x in details),'columns':len(reference),'header':reference}
    except (ValueError,UnicodeError) as e:raise HTTPException(400,str(e))
    finally:
        for upload in files:upload.file.close()

@app.post('/api/merge/process')
def merge_process(files:list[UploadFile]=File(...),fmt:str=Form('csv')):
    if len(files)<2:raise HTTPException(400,'Upload at least two files')
    if fmt not in ('csv','xlsx'):raise HTTPException(400,'Invalid export format')
    folder=workspace(prefix='ns_merge_')
    writer=None
    try:
        sources=[];reference=None;counts=[];total=0
        # Each input is copied to disk once. For CSV output, parse each input
        # only once instead of counting and then re-reading every row.
        if fmt=='csv':
            output=folder/'merged_data.csv'
            for i,upload in enumerate(files):
                suffix=Path(upload.filename or '').suffix.lower()
                if suffix not in FORMATS:raise ValueError(f'{upload.filename}: unsupported input format')
                source=folder/(f'input_{i}'+suffix)
                with source.open('wb') as out:shutil.copyfileobj(upload.file,out,length=4*1024*1024)
                it=iter_records(source,suffix)
                try:header=[str(x) for x in next(it)]
                except StopIteration:raise ValueError(f'{upload.filename}: empty file')
                if reference is None:
                    reference=header
                    writer=_MergeWriter(output,'csv',reference)
                rows=0
                for row in it:
                    writer.add(row)
                    rows+=1
                total+=rows
                counts.append({'filename':upload.filename,'rows':rows})
                source.unlink(missing_ok=True)
            writer.close();writer=None
            actual_fmt='csv'
        else:
            # XLSX needs an upfront row count to enforce its sheet limit;
            # preserve the existing automatic CSV fallback and original order.
            for i,upload in enumerate(files):
                suffix=Path(upload.filename or '').suffix.lower()
                if suffix not in FORMATS:raise ValueError(f'{upload.filename}: unsupported input format')
                source=folder/(f'input_{i}'+suffix)
                with source.open('wb') as out:shutil.copyfileobj(upload.file,out,length=4*1024*1024)
                it=iter_records(source,suffix)
                try:header=[str(x) for x in next(it)]
                except StopIteration:raise ValueError(f'{upload.filename}: empty file')
                if reference is None:reference=header
                rows=sum(1 for _ in it);total+=rows
                counts.append({'filename':upload.filename,'rows':rows})
                sources.append((source,suffix))
            actual_fmt='csv' if total>1048575 else 'xlsx'
            output=folder/('merged_data.'+actual_fmt)
            writer=_MergeWriter(output,actual_fmt,reference)
            for source,suffix in sources:
                it=iter_records(source,suffix);next(it)
                for row in it:writer.add(row)
                source.unlink(missing_ok=True)
            writer.close();writer=None
        cleanup_expired_jobs()
        job=uuid.uuid4().hex
        with JOB_LOCK:
            MERGE_JOBS[job]=output
            MERGE_TIMES[job]=time.time()
        return {'job_id':job,'total_rows':total,'files':counts,'output_format':actual_fmt,'switched_to_csv':actual_fmt!=fmt,'download_url':'/api/merge/download/'+job}
    except (ValueError,UnicodeError,TypeError) as e:
        shutil.rmtree(folder,ignore_errors=True);raise HTTPException(400,str(e))
    except Exception:
        shutil.rmtree(folder,ignore_errors=True);raise
    finally:
        if writer:
            try:writer.close()
            except Exception:pass
        for upload in files:upload.file.close()

@app.get('/api/merge/job/{job}/summary')
def merge_job_summary(job:str):
    with JOB_LOCK: source=MERGE_JOBS.get(job)
    if not source or not source.exists():raise HTTPException(404,'Merge session expired')
    it=iter_records(source,source.suffix)
    header=next(it,[])
    counts=[0]*len(header);rows=0
    for row in it:
        rows+=1
        for i in range(len(header)):
            if i>=len(row) or not str(row[i] if row[i] is not None else '').strip():counts[i]+=1
    return {'header':header,'rows':rows,'blank_counts':counts}

@app.post('/api/merge/job/{job}/clean')
def merge_job_clean(job:str,mode:str=Form(...),columns:str=Form(...),fmt:str=Form('csv')):
    with JOB_LOCK: source=MERGE_JOBS.get(job)
    if not source or not source.exists():raise HTTPException(404,'Merge session expired')
    if mode not in ('duplicates','blanks'):raise HTTPException(400,'Invalid cleaning mode')
    if fmt not in ('csv','xlsx'):raise HTTPException(400,'Invalid format')
    try: indices=json.loads(columns)
    except Exception:raise HTTPException(400,'Invalid columns')
    iterator=iter_records(source,source.suffix)
    header=next(iterator,[])
    if not isinstance(indices,list) or not indices or any(type(i)!=int or i<0 or i>=len(header) for i in indices):
        raise HTTPException(400,'Select valid columns')
    # Disk-backed SQLite index avoids browser-side data duplication for large inputs.
    import sqlite3
    folder=workspace(prefix='ns_merge_clean_')
    db=None;writer=None
    try:
        db=sqlite3.connect(str(folder/'seen.sqlite')) if mode=='duplicates' else None
        if db:db.execute('CREATE TABLE seen (key TEXT PRIMARY KEY)')
        # Excel is limited to 1,048,576 rows including the header.
        output_fmt='csv' if fmt=='xlsx' and source.stat().st_size>0 and merge_job_summary(job)['rows']>1048575 else fmt
        output=folder/('merged_'+mode+'.'+output_fmt)
        writer=_MergeWriter(output,output_fmt,header)
        total=removed=0
        for row in iterator:
            total+=1
            if mode=='blanks':drop=any(i>=len(row) or not str(row[i] if row[i] is not None else '').strip() for i in indices)
            else:
                key=json.dumps([str(row[i]) if i<len(row) and row[i] is not None else '' for i in indices],ensure_ascii=False)
                drop=db.execute('INSERT OR IGNORE INTO seen (key) VALUES (?)',(key,)).rowcount==0
            if drop:removed+=1
            else:writer.add(row)
            if total % 10000 == 0:conn.commit()
        writer.close();writer=None
        if db:db.commit();db.close();db=None
        clean_job=uuid.uuid4().hex
        with JOB_LOCK:
            MERGE_JOBS[clean_job]=output;MERGE_TIMES[clean_job]=time.time()
        return {'input_rows':total,'removed_rows':removed,'output_rows':total-removed,'download_url':'/api/merge/download/'+clean_job,'clean_job_id':clean_job,'format':output_fmt}
    except Exception:
        shutil.rmtree(folder,ignore_errors=True)
        raise
    finally:
        if writer:writer.close()
        if db:db.close()

@app.get('/api/merge/download/{job}')
def merge_download(job:str):
    with JOB_LOCK:output=MERGE_JOBS.get(job)
    if output is None or not output.exists():raise HTTPException(404,'Merge output not found')
    return FileResponse(output,filename=output.name,media_type='application/octet-stream')


# Offline UI bridge: Excel reading and all browser export packages use local Python.
from fastapi import Request
from fastapi.responses import Response
from backend.modules.processing import domain as _domain
import csv, io, zipfile

@app.post('/api/ui/read')
def ui_read(file:UploadFile=File(...)):
    suffix=Path(file.filename or '').suffix.lower()
    if suffix not in FORMATS:raise HTTPException(400,'Unsupported file type')
    temp=workspace(prefix='ns_ui_read_')
    try:
        src=temp/('input'+suffix)
        with src.open('wb') as out:shutil.copyfileobj(file.file,out,length=1024*1024)
        iterator=iter_records(src,suffix)
        return {'matrix':[list(row) for row in iterator]}
    except (ValueError,UnicodeError) as e:raise HTTPException(400,str(e))
    finally:
        file.file.close();shutil.rmtree(temp,ignore_errors=True)

@app.post('/api/ui/export')
async def ui_export(request:Request):
    data=await request.json()
    fmt=data.get('fmt','csv')
    if fmt not in ('csv','tsv','xlsx'):raise HTTPException(400,'Invalid output format')
    header=data.get('header',[])
    groups=data.get('groups',[])
    if not isinstance(header,list) or not isinstance(groups,list) or not groups:
        raise HTTPException(400,'Missing header or output groups')
    def make_file(rows):
        if fmt=='xlsx':
            from openpyxl import Workbook
            wb=Workbook(write_only=True);ws=wb.create_sheet('Data')
            ws.append(header)
            for row in rows:ws.append([str(x) if x is not None else '' for x in row])
            f=io.BytesIO();wb.save(f);return f.getvalue()
        out=io.StringIO(newline='')
        w=csv.writer(out,delimiter='\t' if fmt=='tsv' else ',')
        w.writerow(header);w.writerows(rows)
        return ('\ufeff'+out.getvalue()).encode('utf-8')
    name=safe_name(str(data.get('name','EasyFlow')))
    if len(groups)==1:
        group=groups[0];payload=make_file(group['rows'])
        return Response(payload,media_type='application/octet-stream',headers={'Content-Disposition':f'attachment; filename="{name}.{fmt}"'})
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,allowZip64=True) as z:
        for i,group in enumerate(groups):
            gname=safe_name(str(group.get('name','part_'+str(i+1))))
            z.writestr(f'{gname}.{fmt}',make_file(group['rows']))
    return Response(buffer.getvalue(),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="{name}.zip"'})

# Feature 3: disk-backed exact-match deduplication.
@app.post('/api/duplicates/process')
def duplicates_process(mode:str=Form(...),fresh:UploadFile=File(...),master:UploadFile|None=File(None),
                       columns:str=Form('[]'),fmt:str=Form('csv')):
    import sqlite3
    if mode not in ('single','master'):raise HTTPException(400,'Invalid duplicate mode')
    if fmt not in ('csv','xlsx'):raise HTTPException(400,'Invalid export format')
    if mode=='master' and master is None:raise HTTPException(400,'Master file required')
    try:pairs=json.loads(columns)
    except Exception:raise HTTPException(400,'Invalid matching columns')
    if not isinstance(pairs,list) or not pairs:raise HTTPException(400,'Select matching columns')
    folder=workspace(prefix='ns_duplicates_')
    conn=None;writer=None
    try:
        inputs={}
        for name,upload in [('fresh',fresh),('master',master)]:
            if upload is None:continue
            suffix=Path(upload.filename or '').suffix.lower()
            if suffix not in FORMATS:raise ValueError('CSV, TSV and XLSX only')
            target=folder/(name+suffix)
            with target.open('wb') as out:shutil.copyfileobj(upload.file,out,length=4*1024*1024)
            it=iter_records(target,suffix)
            header=next(it,None)
            if header is None:raise ValueError('Empty file')
            inputs[name]=(target,suffix,header)
        fsrc,fsuffix,fheader=inputs['fresh']
        if mode=='single':
            if any(type(i)!=int or i<0 or i>=len(fheader) for i in pairs):raise ValueError('Invalid column selection')
            fresh_cols=pairs;master_cols=pairs
        else:
            msrc,msuffix,mheader=inputs['master']
            if any(not isinstance(pair,list) or len(pair)!=2 or any(type(v)!=int for v in pair) or pair[0]<0 or pair[0]>=len(mheader) or pair[1]<0 or pair[1]>=len(fheader) for pair in pairs):
                raise ValueError('Invalid column mapping')
            master_cols=[x[0] for x in pairs];fresh_cols=[x[1] for x in pairs]
        conn=sqlite3.connect(str(folder/'keys.sqlite'))
        conn.execute('PRAGMA cache_size=-8192')
        conn.execute('PRAGMA temp_store=FILE')
        conn.execute('PRAGMA synchronous=NORMAL')
        conn.execute('CREATE TABLE seen (key TEXT PRIMARY KEY)')
        def key(row,cols):return json.dumps([str(row[i]) if i<len(row) and row[i] is not None else '' for i in cols],ensure_ascii=False,separators=(',',':'))
        master_rows=0
        if mode=='master':
            for row in iter_records(msrc,msuffix):
                if master_rows==0:master_rows+=1;continue
                conn.execute('INSERT OR IGNORE INTO seen VALUES (?)',(key(row,master_cols),))
                master_rows+=1
            master_rows-=1
            conn.commit()
        # Excel format cannot hold more than 1,048,575 data rows.
        output_format=fmt
        if fmt=='xlsx':
            total_count=sum(1 for _ in iter_records(fsrc,fsuffix))-1
            if total_count>1048575:output_format='csv'
        output=folder/('cleaned_fresh.'+output_format if mode=='master' else 'deduplicated_file.'+output_format)
        writer=_MergeWriter(output,output_format,fheader)
        total=removed=0
        it=iter_records(fsrc,fsuffix);next(it)
        for row in it:
            total+=1
            k=key(row,fresh_cols)
            if mode=='single':
                drop=conn.execute('INSERT OR IGNORE INTO seen VALUES (?)',(k,)).rowcount==0
            else:
                drop=conn.execute('SELECT 1 FROM seen WHERE key=?',(k,)).fetchone() is not None
            if drop:removed+=1
            else:writer.add(row)
            if total % 10000 == 0:conn.commit()
        writer.close();writer=None;conn.close();conn=None
        job=uuid.uuid4().hex
        with JOB_LOCK:MERGE_JOBS[job]=output;MERGE_TIMES[job]=time.time()
        return {'input_rows':total,'removed_rows':removed,'output_rows':total-removed,'master_rows':master_rows,
                'format':output_format,'download_url':'/api/merge/download/'+job}
    except (ValueError,TypeError,KeyError) as exc:
        shutil.rmtree(folder,ignore_errors=True)
        raise HTTPException(400,str(exc))
    except Exception:
        shutil.rmtree(folder,ignore_errors=True)
        raise
    finally:
        if writer:writer.close()
        if conn:conn.close()
        fresh.file.close()
        if master:master.file.close()


# Phase 2: persistent, server-side file references for multi-stage cleaning.
# Upload once; subsequent operations stream directly from the registered source.
import zipfile as _phase2_zipfile
from fastapi import Query as _phase2_Query
from fastapi.responses import StreamingResponse

PHASE2_FILES={}
PHASE2_LOCK=threading.RLock()

def phase2_resolve(ref):
    with PHASE2_LOCK:
        entry=PHASE2_FILES.get(ref)
    if entry is None:raise HTTPException(404,'File reference expired or unknown')
    if time.time()-entry['created']>JOB_TTL_SECONDS:
        with PHASE2_LOCK:PHASE2_FILES.pop(ref,None)
        raise HTTPException(410,'File reference expired')
    path=Path(entry['path'])
    if not path.is_file():raise HTTPException(404,'Source file no longer exists')
    return entry

@app.post('/api/fast/upload')
def phase2_upload(file:UploadFile=File(...)):
    suffix=Path(file.filename or '').suffix.lower()
    if suffix not in FORMATS:raise HTTPException(400,'Supported input: CSV, TSV, XLSX')
    folder=workspace(prefix='ns_fast_')
    try:
        source=folder/('input'+suffix)
        with source.open('wb') as output:
            shutil.copyfileobj(file.file,output,length=1024*1024)
        ref=uuid.uuid4().hex
        with PHASE2_LOCK:
            PHASE2_FILES[ref]={'path':str(source),'name':Path(file.filename or 'input').name,
                               'created':time.time(),'folder':str(folder)}
        return {'file_ref':ref,'filename':Path(file.filename or 'input').name,
                'bytes':source.stat().st_size}
    except Exception:
        shutil.rmtree(folder,ignore_errors=True)
        raise
    finally:file.file.close()

@app.post('/api/fast/process')
def phase2_process(file_ref:str=Form(...),mode:str=Form(...),config:str=Form('{}'),
                   fmt:str=Form('csv'),master_ref:str|None=Form(None)):
    entry=phase2_resolve(file_ref)
    try:settings=json.loads(config)
    except json.JSONDecodeError:raise HTTPException(400,'Invalid JSON config')
    if mode=='master_compare':
        if not master_ref:raise HTTPException(400,'master_ref required')
        settings['master_path']=phase2_resolve(master_ref)['path']
    folder=workspace(prefix='ns_fast_result_')
    try:
        source=Path(entry['path'])
        archive,stats=process_cleaning(source,source.suffix.lower(),folder/'outputs',mode,settings,fmt)
        # Register a processed file for next feature, avoiding download and re-upload.
        candidates=[]
        with _phase2_zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                suffix=Path(info.filename).suffix.lower()
                if suffix in FORMATS and not info.is_dir():
                    candidates.append(info)
            if len(candidates)==1:
                info=candidates[0]
                # Prevent archive path traversal and accidental zip bombs.
                if info.file_size>int(os.environ.get('NS_FAST_MAX_EXTRACT_GB','20'))*1024**3:
                    raise ValueError('Intermediate file exceeds configured extraction limit')
                output=folder/('result'+Path(info.filename).suffix.lower())
                with z.open(info) as inp,output.open('wb') as out:
                    shutil.copyfileobj(inp,out,length=1024*1024)
                next_ref=uuid.uuid4().hex
                with PHASE2_LOCK:
                    PHASE2_FILES[next_ref]={'path':str(output),'name':Path(info.filename).name,
                                           'created':time.time(),'folder':str(folder)}
            else:next_ref=None
        job=uuid.uuid4().hex
        with JOB_LOCK:
            PROCESS_JOBS[job]=archive
            PROCESS_TIMES[job]=time.time()
        return {'job_id':job,'file_ref':next_ref,'stats':stats,
                'download_url':'/api/cleaning/download/'+job}
    except (ValueError,KeyError,TypeError) as exc:
        shutil.rmtree(folder,ignore_errors=True)
        raise HTTPException(400,str(exc))
    except Exception:
        shutil.rmtree(folder,ignore_errors=True)
        raise

@app.get('/api/fast/files/{file_ref}')
def phase2_file_info(file_ref:str):
    entry=phase2_resolve(file_ref)
    return {'file_ref':file_ref,'filename':entry['name'],'bytes':Path(entry['path']).stat().st_size}

@app.delete('/api/fast/files/{file_ref}')
def phase2_delete(file_ref:str):
    with PHASE2_LOCK:entry=PHASE2_FILES.pop(file_ref,None)
    if not entry:raise HTTPException(404,'Unknown reference')
    # Do not delete shared folders here: output archives can remain downloadable.
    return {'deleted':True}

@app.get('/api/fast/preview/{file_ref}')
def phase2_preview(file_ref:str,limit:int=10):
    """Only sample rows are transferred to the browser, not the full dataset."""
    entry=phase2_resolve(file_ref)
    iterator=iter_records(Path(entry['path']),Path(entry['path']).suffix.lower())
    try:
        header=next(iterator)
        from itertools import islice
        rows=list(islice(iterator,min(100,max(1,limit))))
    except StopIteration:
        header=[];rows=[]
    return {'filename':entry['name'],'header':header,'rows':rows}

@app.get('/api/fast/download/{file_ref}')
def phase2_download(file_ref:str):
    entry=phase2_resolve(file_ref)
    return FileResponse(entry['path'],filename=entry['name'],
                        media_type='application/octet-stream')

@app.get('/fast-workflow',include_in_schema=False)
def phase2_workflow_page():
    return FileResponse(ROOT/'frontend'/'fast-workflow.html',media_type='text/html')

@app.post('/api/fast/chunks')
def phase2_chunks(file_ref:str=Form(...),mode:str=Form('simple'),
                  size:int=Form(5000),fmt:str=Form('csv'),groups:str=Form('[]')):
    """Reuse uploaded source without another browser upload."""
    entry=phase2_resolve(file_ref)
    try:parsed=json.loads(groups)
    except json.JSONDecodeError:raise HTTPException(400,'Invalid chunk groups')
    work=workspace(prefix='ns_fast_chunks_')
    try:
        source=Path(entry['path'])
        results,rows=build(source,source.suffix.lower(),fmt,mode,size,parsed,
                           work,safe_name(Path(entry['name']).stem))
        job=uuid.uuid4().hex
        with JOB_LOCK:
            JOBS[job]=[Path(r['path']) for r in results]
            JOB_TIMES[job]=time.time()
        return {'job_id':job,'rows':rows,
                'outputs':[{'filename':r['filename'],'parts':r['parts'],
                            'rows':r['rows'],
                            'url':f'/api/chunks/download/{job}/{i}'}
                           for i,r in enumerate(results)]}
    except (ValueError,KeyError,TypeError) as e:
        shutil.rmtree(work,ignore_errors=True)
        raise HTTPException(400,str(e))
    except Exception:
        shutil.rmtree(work,ignore_errors=True)
        raise

@app.post('/api/fast/merge')
def phase2_merge(file_refs:str=Form(...),fmt:str=Form('csv')):
    """Merge registered files without reuploading their bytes from the browser."""
    try:refs=json.loads(file_refs)
    except json.JSONDecodeError:raise HTTPException(400,'file_refs must be a JSON array')
    if not isinstance(refs,list) or not 2<=len(refs)<=100:
        raise HTTPException(400,'Choose 2 to 100 registered files')
    if fmt not in ('csv','tsv','xlsx'):raise HTTPException(400,'Invalid output format')
    from backend.modules.chunks import PartWriter
    work=workspace(prefix='ns_fast_merge_')
    try:
        entries=[phase2_resolve(str(ref)) for ref in refs]
        source_iterators=[iter_records(Path(e['path']),Path(e['path']).suffix.lower()) for e in entries]
        headers=[]
        for iterator in source_iterators:
            try:headers.append([str(c) for c in next(iterator)])
            except StopIteration:raise ValueError('Cannot merge empty file')
        if any(h!=headers[0] for h in headers[1:]):
            raise ValueError('Merge requires identical headers and column order')
        output=work/('merged.'+fmt)
        writer=PartWriter(output,fmt,headers[0])
        count=0
        try:
            for iterator in source_iterators:
                for row in iterator:
                    if fmt=='xlsx' and count>=1048575:
                        raise ValueError('XLSX limit: 1,048,575 data rows')
                    writer.add(row);count+=1
        finally:writer.close()
        ref=uuid.uuid4().hex
        with PHASE2_LOCK:
            PHASE2_FILES[ref]={'path':str(output),'name':output.name,
                               'created':time.time(),'folder':str(work)}
        return {'file_ref':ref,'rows':count,'columns':len(headers[0]),
                'download_url':'/api/fast/download/'+ref}
    except (ValueError,KeyError,TypeError) as e:
        shutil.rmtree(work,ignore_errors=True)
        raise HTTPException(400,str(e))
    except Exception:
        shutil.rmtree(work,ignore_errors=True)
        raise

# Info Finder Phase 3: opt-in public search pilot; email finding intentionally excluded.
from pydantic import BaseModel, Field
from backend.modules.info_research import research_rows
class InfoResearchRequest(BaseModel):
    rows: list[list] = Field(max_length=25)
    mappings: dict[str,int]
    fields: list[str] = Field(max_length=3)

@app.get('/api/info-finder/research/status')
def info_research_status():
    return {'configured':True,'pilot_max_rows':25,'supported_fields':['Company Website','Company LinkedIn','Company Description'],'mode':'official_public_company_pages_no_api'}

@app.post('/api/info-finder/research')
def info_research(request:InfoResearchRequest):
    try:return research_rows(request.rows,request.mappings,request.fields)
    except ValueError as exc:raise HTTPException(400,str(exc))

@app.on_event('startup')
def recover_expired_workspaces():
    sweep_expired()

# Large Data Mode: opt-in asynchronous processing API. Existing routes stay compatible.
from backend.core.job_manager import JobManager
MANAGED_JOBS=JobManager()

@app.post('/api/large-data/cleaning/start')
def large_data_cleaning_start(file:UploadFile=File(...),mode:str=Form(...),config:str=Form('{}'),fmt:str=Form('csv'),master:UploadFile|None=File(None)):
    suffix=Path(file.filename or '').suffix.lower()
    if suffix not in FORMATS:raise HTTPException(400,'Supported input: CSV, TSV, XLSX')
    if fmt not in ('csv','tsv','xlsx'):raise HTTPException(400,'Invalid output format')
    if mode not in ('duplicates','master_compare','blanks','sales_domains','job_titles','sales_raw'):
        raise HTTPException(400,'Unsupported mode')
    try:
        settings=json.loads(config)
        if not isinstance(settings,dict):raise ValueError('Config must be an object')
    except (ValueError,TypeError) as exc:raise HTTPException(400,str(exc))
    folder=workspace(prefix='large_upload_')
    try:
        source=folder/('source'+suffix)
        with source.open('wb') as output:shutil.copyfileobj(file.file,output,length=1024*1024)
        master_path=None
        if mode=='master_compare':
            if master is None:raise ValueError('Master file required')
            ext=Path(master.filename or '').suffix.lower()
            if ext not in FORMATS:raise ValueError('Unsupported master format')
            master_path=folder/('master'+ext)
            with master_path.open('wb') as output:shutil.copyfileobj(master.file,output,length=1024*1024)
        job=MANAGED_JOBS.submit(source,suffix,mode,settings,fmt,master_path)
        return {'job_id':job,'status_url':'/api/large-data/jobs/'+job,'download_url':'/api/large-data/jobs/'+job+'/download'}
    except ValueError as exc:raise HTTPException(400,str(exc))
    finally:
        file.file.close()
        if master:master.file.close()
        shutil.rmtree(folder,ignore_errors=True)

@app.get('/api/large-data/jobs/{job}')
def large_data_job_status(job:str):
    try:return MANAGED_JOBS.status(job)
    except KeyError:raise HTTPException(404,'Job not found')

@app.post('/api/large-data/jobs/{job}/cancel')
def large_data_job_cancel(job:str):
    try:return MANAGED_JOBS.cancel(job)
    except KeyError:raise HTTPException(404,'Job not found')

@app.get('/api/large-data/jobs/{job}/download')
def large_data_job_download(job:str):
    try:path=MANAGED_JOBS.output(job)
    except KeyError:raise HTTPException(404,'Job not found')
    except (ValueError,FileNotFoundError):raise HTTPException(409,'Output unavailable')
    return FileResponse(path,filename=path.name,media_type='application/zip')
