import os,sys
from pathlib import Path
ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[2]))
HOST = os.environ.get('NS_HOST','127.0.0.1')
PORT = int(os.environ.get('NS_PORT','8000'))
