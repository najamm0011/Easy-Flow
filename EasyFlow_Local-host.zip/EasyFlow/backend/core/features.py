"""Feature manifest reader. Read-only; no processing or UI behavior changes."""
import json
from functools import lru_cache
from pathlib import Path
from backend.core.config import ROOT

ALLOWED_STATUSES = frozenset({"active", "ui_only", "planned", "disabled"})

@lru_cache(maxsize=1)
def feature_manifest():
    path = ROOT / "config" / "features.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != 1:
        raise ValueError("Unsupported feature manifest version")
    for key, entry in payload["features"].items():
        if entry["status"] not in ALLOWED_STATUSES or not isinstance(entry["dashboard"], bool):
            raise ValueError(f"Invalid feature configuration: {key}")
    return payload

def public_features():
    return {key: {"status": entry["status"], "dashboard": entry["dashboard"]}
            for key, entry in feature_manifest()["features"].items()}
