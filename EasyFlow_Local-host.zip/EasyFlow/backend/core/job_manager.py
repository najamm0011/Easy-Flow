"""Bounded, cancellable, disk-backed background cleaning jobs.

State is process-local; unfinished jobs are marked abandoned after restart.
Only manager-created directories are deleted. Outputs expire after TTL.
"""
import json
import os
import shutil
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from .large_data import TEMP, check_storage
from backend.modules.processing import process

FINAL={'completed','cancelled','failed','interrupted'}
class JobManager:
    def __init__(self, root=None, workers=None, ttl=86400):
        self.root=Path(root or TEMP/'managed')
        self.root.mkdir(parents=True,exist_ok=True)
        self.pool=ThreadPoolExecutor(max_workers=max(1,min(int(workers or os.getenv('EASYFLOW_WORKERS','2')),4)))
        self.ttl=ttl
        self.lock=threading.RLock()
        self.jobs={}
        self.events={}
        self.recover()
    def _state_path(self,job):return self.root/job/'state.json'
    def _save(self,job):
        state=self.jobs[job].copy()
        path=self._state_path(job)
        temp=path.with_suffix('.tmp')
        temp.write_text(json.dumps(state),encoding='utf-8')
        os.replace(temp,path)
    def update(self,job,**changes):
        with self.lock:
            self.jobs[job].update(changes,updated_at=time.time())
            self._save(job)
    def submit(self,source,suffix,mode,config,fmt='csv',master=None):
        source=Path(source)
        total=source.stat().st_size+(Path(master).stat().st_size if master else 0)
        check_storage(total,self.root)
        job=uuid.uuid4().hex
        folder=self.root/job
        folder.mkdir()
        target=folder/('input'+suffix)
        shutil.move(str(source),target)
        settings=dict(config)
        if master:
            mp=Path(master);dest=folder/('master'+mp.suffix)
            shutil.move(str(mp),dest);settings['master_path']=str(dest)
        now=time.time()
        with self.lock:
            self.jobs[job]=dict(id=job,status='queued',rows_scanned=0,created_at=now,updated_at=now,error=None,download=None,stats=None)
            self.events[job]=threading.Event()
            self._save(job)
        self.pool.submit(self._run,job,target,suffix,mode,settings,fmt)
        return job
    def _run(self,job,source,suffix,mode,config,fmt):
        event=self.events[job]
        if event.is_set():self.update(job,status='cancelled');return
        self.update(job,status='running')
        try:
            archive,stats=process(source,suffix,self.root/job/'output',mode,config,fmt,cancel_event=event,progress=lambda n:self.update(job,rows_scanned=n))
            if event.is_set():raise InterruptedError('Processing cancelled')
            self.update(job,status='completed',rows_scanned=stats.get('input_rows',0),stats=stats,download=archive.name)
            # Intermediate inputs and indexes no longer needed after output completes.
            source.unlink(missing_ok=True)
            # Archive is self-contained: discard intermediate CSV/XLSX and SQLite files.
            for intermediate in (self.root/job/'output').iterdir():
                if intermediate != archive and intermediate.is_file() and not intermediate.is_symlink():
                    intermediate.unlink(missing_ok=True)
            for file in (self.root/job).glob('master.*'):file.unlink(missing_ok=True)
        except InterruptedError:
            self.update(job,status='cancelled')
            shutil.rmtree(self.root/job/'output',ignore_errors=True)
        except Exception as exc:
            self.update(job,status='failed',error=str(exc)[:500])
            shutil.rmtree(self.root/job/'output',ignore_errors=True)
        finally:
            self.events.pop(job,None)
    def status(self,job):
        with self.lock:
            if job not in self.jobs:raise KeyError(job)
            return self.jobs[job].copy()
    def cancel(self,job):
        with self.lock:
            state=self.status(job)
            if state['status'] in FINAL:return state
            self.events[job].set()
            return self.status(job)
    def output(self,job):
        state=self.status(job)
        if state['status']!='completed':raise ValueError('Output is not ready')
        path=self.root/job/'output'/state['download']
        if not path.is_file():raise FileNotFoundError(path)
        return path
    def recover(self):
        now=time.time()
        for folder in self.root.iterdir():
            if folder.is_symlink() or not folder.is_dir():continue
            statefile=folder/'state.json'
            try:state=json.loads(statefile.read_text(encoding='utf-8'))
            except (OSError,ValueError):continue
            if state.get('id')!=folder.name:continue
            if state.get('status') not in FINAL:
                state.update(status='interrupted',error='Application stopped before processing finished',updated_at=now)
                statefile.write_text(json.dumps(state),encoding='utf-8')
                shutil.rmtree(folder/'output',ignore_errors=True)
            if now-state.get('updated_at',now)>self.ttl:
                shutil.rmtree(folder,ignore_errors=True)
            else:self.jobs[folder.name]=state
    def cleanup(self):
        now=time.time();deleted=[]
        with self.lock:
            for job,state in list(self.jobs.items()):
                if state['status'] in FINAL and now-state['updated_at']>self.ttl:
                    shutil.rmtree(self.root/job,ignore_errors=True)
                    del self.jobs[job];deleted.append(job)
        return deleted
