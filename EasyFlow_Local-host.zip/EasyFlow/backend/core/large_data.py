"""Large-data-only resource and temporary workspace management.

A conservative foundation: streaming remains in existing feature engines. Never
remove user files or unexpired server outputs; only own managed workspaces.
"""
import os
import shutil
import tempfile
import time
from pathlib import Path

ROOT = Path(os.environ.get('EASYFLOW_WORK_ROOT', Path(tempfile.gettempdir()) / 'EasyFlow'))
TEMP = ROOT / 'Temp'
OUTPUTS = ROOT / 'Outputs'
LOGS = ROOT / 'Logs'
RETENTION_SECONDS = max(3600, int(os.environ.get('EASYFLOW_RETENTION_HOURS', '24')) * 3600)


def resources(path=None):
    """Best-effort machine capacity; does not claim dedicated RAM ownership."""
    target = Path(path or ROOT)
    target.mkdir(parents=True, exist_ok=True)
    disk = shutil.disk_usage(target)
    result = {'disk_free_bytes': disk.free, 'disk_total_bytes': disk.total,
              'cpu_count': os.cpu_count() or 1, 'mode': 'large_data'}
    try:
        import psutil
        result['available_ram_bytes'] = psutil.virtual_memory().available
    except ImportError:
        result['available_ram_bytes'] = None
    return result


def check_storage(input_bytes=0, path=None):
    """Conservative preflight, re-check space during writes in feature engines."""
    stats = resources(path)
    # Reserve at least 256 MiB for OS/application; reserve input size for
    # intermediate/output work (estimate, not a guarantee).
    reserve = max(256 * 1024**2, int(input_bytes * 1.5))
    if stats['disk_free_bytes'] < reserve:
        raise ValueError('Insufficient temporary storage for processing. Free disk space and retry.')
    return stats


def workspace(prefix='job_'):
    check_storage()
    TEMP.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix=prefix, dir=TEMP))


def sweep_expired(active_paths=(), now=None):
    """Remove only aged EasyFlow-owned temp/output job folders.

    Active folders are protected even when old. Symlinks are never followed.
    """
    now = time.time() if now is None else now
    protected = {Path(p).resolve() for p in active_paths}
    removed = []
    for base in (TEMP, OUTPUTS):
        if not base.exists():
            continue
        for item in base.iterdir():
            if item.is_symlink() or not item.is_dir():
                continue
            resolved = item.resolve()
            if any(p == resolved or resolved in p.parents for p in protected):
                continue
            try:
                if now - item.stat().st_mtime >= RETENTION_SECONDS:
                    shutil.rmtree(item)
                    removed.append(str(item))
            except (OSError, FileNotFoundError):
                pass
    return removed
