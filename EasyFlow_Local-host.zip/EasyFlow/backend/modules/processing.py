"""Disk-backed common cleaning engine. CSV/TSV/XLSX input; CSV/TSV/XLSX output.
No application-level MB upload/download cap. Physical storage and format limits apply.
"""
import csv, json, re, sqlite3, zipfile, os, time
from pathlib import Path
from urllib.parse import urlparse
from functools import lru_cache
from .chunks import iter_records, PartWriter, safe_name

CATS = [('Owners & Founders', ['owner', 'business owner', 'company owner', 'co-owner', 'co owner', 'founder', 'co-founder', 'co founder', 'owner & founder', 'founder & ceo', 'ceo & founder', 'founder & president', 'president & founder', 'founding partner', 'proprietor', 'sole proprietor', 'principal owner', 'business founder', 'co-founder & ceo', 'founder & managing director', 'owner & president', 'owner & ceo', 'founder & director', 'owner & director', 'founding ceo', 'founding director', 'managing owner', 'co-owner & founder']), ('CEOs & Chief Executives', ['ceo', 'chief executive officer', 'chief executive', 'co-ceo', 'co ceo', 'group ceo', 'global ceo', 'regional ceo', 'interim ceo', 'acting ceo', 'deputy ceo', 'executive ceo', 'president & ceo', 'ceo & president', 'ceo & managing director', 'managing director & ceo', 'managing director & chief executive officer', 'chief executive & managing director']), ('Presidents', ['president', 'company president', 'executive president', 'group president', 'global president', 'regional president', 'division president', 'business unit president', 'country president', 'president & managing director', 'president & director', 'president of sales', 'president of operations', 'president of marketing', 'senior president', 'co-president', 'co president', 'acting president', 'interim president']), ('Vice Presidents', ['vice president', 'vp', 'evp', 'executive vice president', 'svp', 'senior vice president', 'avp', 'associate vice president', 'group vice president', 'global vice president', 'regional vice president', 'divisional vice president', 'division vice president', 'corporate vice president', 'vice president of sales', 'vp of sales', 'vp sales', 'vice president of marketing', 'vp of marketing', 'vice president of operations', 'vp of operations', 'vp of engineering', 'vp of technology', 'vp of finance', 'vp of business development', 'vp of product', 'vp of it', 'vp of hr', 'vp of customer success', 'vp of revenue', 'vp of growth', 'vp of strategy', 'vp of procurement', 'vp of supply chain', 'vp of people', 'vp of partnerships', 'vp of digital transformation', 'senior vp', 'executive vp', 'assistant vice president', 'first vice president', 'vice president & general manager']), ('C-Level Executives', ['coo', 'cfo', 'cto', 'cio', 'cmo', 'cro', 'chro', 'cpo', 'ciso', 'cso', 'cdo', 'cco', 'clo', 'cao', 'cbo', 'cdao', 'cgo', 'cwo', 'chief operating officer', 'chief financial officer', 'chief technology officer', 'chief technical officer', 'chief information officer', 'chief marketing officer', 'chief revenue officer', 'chief human resources officer', 'chief people officer', 'chief product officer', 'chief information security officer', 'chief security officer', 'chief strategy officer', 'chief sales officer', 'chief commercial officer', 'chief customer officer', 'chief communications officer', 'chief legal officer', 'chief administrative officer', 'chief accounting officer', 'chief data officer', 'chief digital officer', 'chief digital and information officer', 'chief analytics officer', 'chief business officer', 'chief growth officer', 'chief brand officer', 'chief procurement officer', 'chief supply chain officer', 'chief innovation officer', 'chief transformation officer', 'chief sustainability officer', 'chief experience officer', 'chief risk officer', 'chief compliance officer', 'chief investment officer', 'chief medical officer', 'chief scientific officer', 'chief creative officer', 'chief design officer', 'chief learning officer', 'chief talent officer', 'chief diversity officer', 'chief operating and financial officer', 'chief financial and operating officer']), ('Partners', ['partner', 'managing partner', 'senior partner', 'general partner', 'executive partner', 'equity partner', 'operating partner', 'principal partner', 'co-managing partner', 'co managing partner', 'joint managing partner', 'business partner', 'firm partner', 'managing director & partner', 'partner & director', 'partner & ceo', 'partner & president', 'partner & founder']), ('Heads of Departments', ['head of sales', 'head of marketing', 'head of operations', 'head of it', 'head of engineering', 'head of product', 'head of finance', 'head of hr', 'head of human resources', 'head of people', 'head of growth', 'head of business development', 'head of customer success', 'head of procurement', 'head of digital transformation', 'head of technology', 'head of revenue', 'head of strategy', 'head of partnerships', 'head of legal', 'head of compliance', 'head of risk', 'head of data', 'head of analytics', 'head of security', 'head of design', 'head of customer experience', 'head of supply chain', 'head of manufacturing', 'head of research', 'head of research and development', 'head of r&d', 'head of department', 'department head', 'country head', 'global head', 'business unit head', 'division head', 'regional head', 'practice head', 'functional head', 'commercial head', 'sales head', 'marketing head', 'operations head', 'engineering head', 'technology head', 'product head', 'finance head', 'hr head', 'growth head', 'revenue head', 'it head', 'departmental head']), ('Directors', ['director', 'executive director', 'senior director', 'regional director', 'global director', 'corporate director', 'managing director', 'group director', 'divisional director', 'division director', 'country director', 'business unit director', 'practice director', 'sales director', 'marketing director', 'operations director', 'it director', 'engineering director', 'finance director', 'business development director', 'technology director', 'product director', 'hr director', 'human resources director', 'revenue director', 'growth director', 'strategy director', 'procurement director', 'supply chain director', 'customer success director', 'customer experience director', 'commercial director', 'digital director', 'data director', 'analytics director', 'legal director', 'compliance director', 'risk director', 'security director', 'research director', 'r&d director', 'director of sales', 'director of marketing', 'director of operations', 'director of it', 'director of engineering', 'director of finance', 'director of business development', 'director of technology', 'director of product', 'director of hr', 'director of revenue', 'director of growth', 'director of strategy', 'director of procurement', 'director of customer success', 'director of customer experience', 'director of supply chain', 'director of legal', 'director of compliance', 'director of data', 'director of analytics', 'director of digital transformation', 'director of partnerships', 'director of people', 'director of manufacturing', 'director of research', 'director of research and development', 'director of information technology', 'director of human resources', 'director of corporate development', 'director of communications', 'director of customer service', 'director of quality', 'director of quality assurance', 'director of administration', 'director of facilities', 'director of logistics', 'director of projects', 'director of program management', 'director of business operations', 'director of global sales', 'director of regional sales', 'director of enterprise sales', 'director of strategic accounts', 'director of account management', 'director of client services', 'director of professional services', 'director of software engineering', 'director of information security', 'director of cybersecurity', 'director of infrastructure', 'director of cloud engineering', 'director of ai', 'director of machine learning', 'director of innovation', 'director of transformation', 'director of sustainability', 'director of talent acquisition', 'director of talent management', 'director of learning and development', 'director of employee experience', 'director of people operations', 'director of financial planning and analysis', 'director of accounting', 'director of treasury', 'director of tax', 'director of investor relations', 'director of mergers and acquisitions', 'director of partnerships and alliances', 'director of channel sales', 'director of demand generation', 'director of brand marketing', 'director of product marketing', 'director of performance marketing', 'director of digital marketing', 'director of content marketing', 'director of field marketing', 'director of growth marketing', 'director of marketing operations', 'director of sales operations', 'director of revenue operations', 'director of customer operations', 'director of business intelligence', 'director of data science', 'director of data engineering', 'director of product management', 'director of product development', 'director of ux', 'director of user experience', 'director of design', 'director of creative', 'director of engineering operations', 'director of technical operations', 'director of network operations', 'director of security operations', 'director of manufacturing operations', 'director of plant operations', 'director of warehouse operations', 'director of supply chain operations', 'director of procurement operations', 'director of healthcare operations', 'director of clinical operations', 'director of medical operations', 'director of retail operations', 'director of store operations', 'director of franchise operations', 'director of regional operations', 'director of international operations', 'director of global operations', 'director of corporate operations', 'director of people and culture', 'director of human capital', 'director of organizational development', 'director of corporate strategy', 'director of strategic planning', 'director of corporate finance', 'director of financial operations', 'director of internal audit', 'director of governance', 'director of regulatory affairs', 'director of public affairs', 'director of government relations', 'director of community relations', 'director of external affairs', 'director of communications and pr', 'director of public relations', 'director of client success', 'director of client experience', 'director of customer support', 'director of service delivery', 'director of delivery', 'director of implementation', 'director of solutions engineering', 'director of solutions architecture', 'director of enterprise architecture', 'director of systems engineering', 'director of software development', 'director of application development', 'director of platform engineering', 'director of devops', 'director of site reliability engineering', 'director of information systems', 'director of technology operations', 'director of technical support', 'director of technical services', 'director of cyber security', 'director of privacy', 'director of data privacy', 'director of information governance', 'director of quality control', 'director of quality management', 'director of process improvement', 'director of continuous improvement', 'director of operational excellence', 'director of program delivery', 'director of project delivery', 'director of portfolio management', 'director of pmo', 'director of construction', 'director of real estate', 'director of property management', 'director of asset management', 'director of facilities management', 'director of maintenance', 'director of field operations', 'director of field service', 'director of service operations', 'director of service management', 'director of customer relations', 'director of customer engagement', 'director of customer retention', 'director of customer acquisition', 'director of sales enablement', 'director of sales development', 'director of business development and partnerships'])]

def normalized(s):return re.sub(r"[^a-z0-9 ]+", " ",str(s or "").lower().replace("&"," and ")).strip()
CAT_MAP={normalized(t):cat for cat,titles in CATS for t in titles}

def categorize_title(title):
    t=normalized(title)
    if t in CAT_MAP:return CAT_MAP[t]
    # Controlled role patterns: exact role, optionally with department, seniority, region.
    # Never classify unrelated manager/analyst/coordinator titles by substring.
    if re.search(r"\b(?:owner|co owner|founder|co founder|proprietor)\b",t):return "Owners & Founders"
    if re.search(r"\b(?:ceo|co ceo|chief executive officer|chief executive)\b",t):return "CEOs & Chief Executives"
    if re.search(r"\bpresident\b",t) and not re.search(r"\b(?:vice|assistant vice|senior vice|executive vice|associate vice) president\b",t):return "Presidents"
    if re.search(r"\b(?:vice president|vp|svp|evp|avp|senior vp|executive vp|associate vp)\b",t):return "Vice Presidents"
    if re.search(r"\b(?:chief (?:[a-z]+ ){0,5}officer|coo|cfo|cto|cio|cmo|cro|chro|cpo|ciso|cso|cdo|cco|clo|cao|cbo|cdao|cgo|cwo)\b",t):return "C-Level Executives"
    if re.search(r"\bpartner\b",t):return "Partners"
    if re.search(r"\bhead of\b|\b(?:department|sales|marketing|operations|engineering|finance|technology|product|hr|it|revenue|growth|regional|global|country|division|practice|business unit) head\b",t):return "Heads of Departments"
    if re.search(r"\bdirector\b",t) and not re.search(r"\b(?:assistant|deputy|associate) director\b",t):return "Directors"
    return None

def blank(v):return not str(v if v is not None else '').strip()
def header_index(header,choice):
    if isinstance(choice,int):
        if 0<=choice<len(header):return choice
    if isinstance(choice,str):
        for i,h in enumerate(header):
            if str(h).casefold()==choice.casefold():return i
    raise ValueError('Column not found: '+str(choice))
def col_indices(header,choices):
    if not choices:raise ValueError('Select at least one matching column')
    return [header_index(header,c) for c in choices]
def key(row,indices):return json.dumps([str(row[i] if i<len(row) else '').strip().casefold() for i in indices],ensure_ascii=False)
def domain(value):
    v=str(value or '').strip().lower()
    if not v:return '__blank__'
    if v.count('@')!=1:return '__invalid__'
    local,host=v.rsplit('@',1)
    if not local or '.' not in host or host.startswith('.') or host.endswith('.') or ' ' in host:return '__invalid__'
    return host

@lru_cache(maxsize=32768)
def _link_type_cached(v):
    return _link_type_uncached(v)

def link_type(value):
    return _link_type_cached(str(value or "").strip())

def _link_type_uncached(value):
    v=str(value or '').strip()
    if not v:return None
    p=urlparse(v if '://' in v else 'https://'+v)
    host=(p.hostname or '').lower().removeprefix('www.')
    if host in ('linkedin.com','m.linkedin.com'):
        if p.path.lower().startswith(('/in/','/pub/')):return 'personal_linkedin'
        if p.path.lower().startswith(('/company/','/school/','/showcase/')):return 'company_linkedin'
        return None
    if host in ('facebook.com','m.facebook.com','fb.com'):return 'facebook'
    if '.' in host and re.fullmatch(r'[a-z0-9.-]+',host):return 'company_website'
    return None

def split_name(value):
    parts=str(value or '').strip().split()
    return (parts[0] if parts else '', ' '.join(parts[1:]))

def mapped_row(row,header,mapping,with_links=False,compiled_mapping=None):
    # Resolve headers once per file in the processing loop, not for every record.
    # Keep this function's original public calling convention intact.
    if compiled_mapping is None:
        compiled_mapping=[(target,header_index(header,source)) for target,source in mapping.items()
                          if source is not None and source!='']
    mapped={target:(row[idx] if idx<len(row) else '') for target,idx in compiled_mapping}
    if 'full_name' in mapped:
        first,last=split_name(mapped.pop('full_name'))
        mapped={'first_name':first,'last_name':last,**mapped}
    if with_links:
        fields=['company_website','company_linkedin','personal_linkedin','facebook']
        original={f:str(mapped.get(f,'') or '').strip() for f in fields}
        target={f:v for f,v in original.items() if v and link_type(v)==f}
        conflicts=[]
        for field,value in original.items():
            kind=link_type(value)
            if not value or kind is None or kind==field:continue
            if kind in target and target[kind]!=value:
                conflicts.append(field+' -> '+kind)
                target[field]=value
            else:target[kind]=value
        for field in fields:mapped[field]=target.get(field,'')
        mapped['link_review']='; '.join(conflicts)
    return mapped

class Writer:
    def __init__(self,folder,stem,fmt,header):
        self.fmt=fmt;self.header=header;self.folder=folder;self.stem=stem;self.count=0;self.part=0;self.writer=None;self.paths=[]
    def write(self,row):
        if self.writer is None or (self.fmt=='xlsx' and self.count>=1048575):
            self.close_part();self.part+=1;self.count=0
            path=self.folder/(safe_name(self.stem)+(('_part'+str(self.part)) if self.part>1 else '')+'.'+self.fmt)
            self.paths.append(path);self.writer=PartWriter(path,self.fmt,self.header)
        self.writer.add(row);self.count+=1
    def close_part(self):
        if self.writer:self.writer.close();self.writer=None
    def close(self):
        self.close_part()

def process(source,suffix,folder,mode,config,fmt='csv',cancel_event=None,progress=None):
    if fmt not in ('csv','tsv','xlsx'):raise ValueError('Output must be csv, tsv or xlsx')
    started=time.perf_counter()
    def monitored_rows(path, ext):
        for number, row in enumerate(iter_records(path, ext)):
            if number % 1024 == 0:
                if cancel_event is not None and cancel_event.is_set():
                    raise InterruptedError('Processing cancelled')
                if progress is not None:
                    progress(number)
            yield row
    iterator=monitored_rows(source,suffix)
    try:header=list(next(iterator))
    except StopIteration:raise ValueError('File is empty')
    header=[str(h) for h in header]
    stats={'input_rows':0,'output_rows':0,'removed_rows':0,'conflicts':0}
    phase_start=time.perf_counter()
    def diagnostics():
        stats['processing_seconds']=round(time.perf_counter()-phase_start,4)
        stats['total_seconds']=round(time.perf_counter()-started,4)
    folder.mkdir(parents=True,exist_ok=True)
    writers={};db=None
    def write(group,out_header,row):
        if group not in writers:writers[group]=Writer(folder,group,fmt,out_header)
        writers[group].write(row);stats['output_rows']+=1
    try:
        if (mode=='blanks' and suffix.lower()=='.csv' and fmt=='csv'
                and 1024*1024<=source.stat().st_size<=int(os.environ.get('NS_POLARS_MAX_MB','64'))*1024*1024
                and os.environ.get('EASYFLOW_ALLOW_IN_MEMORY','0')=='1'):
            try:
                import polars as pl
            except ImportError:
                pl=None
            if pl is not None:
                idx=col_indices(header,config.get('columns'))
                # Read as strings to protect leading zeros, identifiers and dates.
                # Polars nulls and whitespace-only values count as blank.
                try:
                    frame=pl.read_csv(source,infer_schema_length=0,try_parse_dates=False,
                                      truncate_ragged_lines=False)
                    if list(frame.columns)!=header:
                        raise ValueError('Header normalization mismatch; use streaming fallback')
                    predicate=None
                    for i in idx:
                        col=pl.col(header[i])
                        condition=col.is_null() | (col.str.strip_chars()=='')
                        predicate=condition if predicate is None else (predicate|condition)
                    cleaned=frame.filter(~predicate)
                    output=folder/'cleaned.csv'
                    cleaned.write_csv(output,include_bom=True)
                    stats['input_rows']=frame.height
                    stats['output_rows']=cleaned.height
                    stats['removed_rows']=frame.height-cleaned.height
                    diagnostics()
                    archive=folder/'EasyFlow_blanks.zip'
                    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,
                                         compresslevel=int(os.environ.get('NS_ZIP_LEVEL','1')),allowZip64=True) as z:
                        z.write(output,arcname='cleaned.csv')
                        z.writestr('processing_summary.json',json.dumps(stats,indent=2))
                    return archive,stats
                except (ValueError,TypeError,pl.exceptions.PolarsError):
                    # Irregular input must be processed by original streaming engine.
                    pass
        if mode in ('duplicates','master_compare'):
            idx=col_indices(header,config.get('columns'))
            master=None
            master_idx=None
            if mode=='master_compare':
                master=Path(config['master_path'])
                master_suffix=master.suffix.lower()
                mi=monitored_rows(master,master_suffix)
                mh=next(mi)
                master_idx=col_indices(mh,config.get('master_columns',config['columns']))
                if len(master_idx)!=len(idx):
                    raise ValueError('Master and fresh comparison columns must match in count')
            total_bytes=source.stat().st_size+(master.stat().st_size if master else 0)
            engine=os.environ.get('NS_DEDUPE_ENGINE','auto').lower()
            if engine not in ('auto','set','sqlite'):
                raise ValueError('NS_DEDUPE_ENGINE must be auto, set or sqlite')
            # A Python set is faster for ordinary sized inputs; keep conservative
            # memory budgeting. Disk-backed SQLite remains the large-file fallback.
            max_set_bytes=int(os.environ.get('NS_DEDUPE_SET_MAX_MB','64'))*1024*1024
            try:
                import psutil
                max_set_bytes=min(max_set_bytes,max(0,psutil.virtual_memory().available//10))
            except ImportError:
                pass
            # Large Data Mode only: disk-backed index is the default regardless of file size.
            use_set=(engine=='set')
            stats['dedupe_engine']='set' if use_set else 'sqlite'
            if use_set:
                seen=set()
                if master is not None:
                    for row in mi:
                        seen.add(key(row,master_idx))
                for row in iterator:
                    stats['input_rows']+=1
                    k=key(row,idx)
                    if k in seen:
                        stats['removed_rows']+=1
                    else:
                        seen.add(k)
                        write('cleaned',header,row)
            else:
                # SQLite on disk for unbounded input; in-memory for explicitly
                # forced SQLite on small datasets.
                sqlite_memory_limit=int(os.environ.get('NS_DEDUPE_MEMORY_INPUT_MB','160'))*1024*1024
                in_memory=(os.environ.get('EASYFLOW_ALLOW_IN_MEMORY','0')=='1' and total_bytes<=sqlite_memory_limit)
                try:
                    import psutil
                    in_memory=in_memory and total_bytes*8<=psutil.virtual_memory().available
                except ImportError:
                    pass
                db=sqlite3.connect(':memory:' if in_memory else str(folder/'dedupe.sqlite'))
                if not in_memory:
                    db.execute('PRAGMA journal_mode=MEMORY')
                    db.execute('PRAGMA synchronous=NORMAL')
                    db.execute('PRAGMA cache_size=-8192')  # 8 MiB bounded SQLite page cache
                    db.execute('PRAGMA temp_store=FILE')
                db.execute('CREATE TABLE seen (k TEXT PRIMARY KEY)')
                if master is not None:
                    db.executemany('INSERT OR IGNORE INTO seen VALUES (?)',
                                   ((key(row,master_idx),) for row in mi))
                for row in iterator:
                    stats['input_rows']+=1
                    k=key(row,idx)
                    cur=db.execute('INSERT OR IGNORE INTO seen VALUES (?)',(k,))
                    if cur.rowcount:write('cleaned',header,row)
                    else:stats['removed_rows']+=1
                    if stats['input_rows'] % 10000 == 0: db.commit()
        elif mode=='blanks':
            idx=col_indices(header,config.get('columns'))
            for row in iterator:
                stats['input_rows']+=1
                if any(blank(row[i] if i<len(row) else '') for i in idx):stats['removed_rows']+=1
                else:write('cleaned',header,row)
        elif mode=='sales_domains':
            idx=header_index(header,config['email_column']);selected=set(config.get('selected_domains',[]))
            if not selected:raise ValueError('Select at least one domain')
            for row in iterator:
                stats['input_rows']+=1
                if domain(row[idx] if idx<len(row) else '') in selected:write('selected_domains',header,row)
                else:stats['removed_rows']+=1
        elif mode=='job_titles':
            idx=header_index(header,config['job_column']);selected=set(config.get('selected_categories',[]));titles=set(config.get('selected_titles',[]))
            if not selected and not titles:raise ValueError('Select at least one category or title')
            for row in iterator:
                stats['input_rows']+=1
                title=str(row[idx] if idx<len(row) else '').strip();category=categorize_title(title)
                if category in selected:write(category,header,row)
                elif category is None and title in titles:write('Title_'+title,header,row)
                else:stats['removed_rows']+=1
        elif mode in ('sales_raw','apollo_raw','link_swapper'):
            mapping=config.get('mapping',{})
            if not mapping:raise ValueError('Field mapping required')
            outfields=[f for f in mapping if f!='full_name']
            if 'full_name' in mapping:outfields=['first_name','last_name']+outfields
            if mode in ('apollo_raw','link_swapper'):
                for f in ('company_website','company_linkedin','personal_linkedin','facebook'):
                    if f not in outfields:outfields.append(f)
                outfields.append('link_review')
            label={'first_name':'First Name','last_name':'Last Name','job_title':'Job Title','company_name':'Company Name','company_website':'Company Website','company_linkedin':'Company LinkedIn','personal_linkedin':'Personal LinkedIn','facebook':'Facebook','email':'Email','location':'Location','link_review':'Link Review'}
            outheader=[label.get(f,f.replace('_',' ').title()) for f in outfields]
            compiled_mapping=[(target,header_index(header,source)) for target,source in mapping.items()
                              if source is not None and source!='']
            with_links=mode in ('apollo_raw','link_swapper')
            for row in iterator:
                stats['input_rows']+=1
                m=mapped_row(row,header,mapping,with_links,compiled_mapping)
                if m.get('link_review'):stats['conflicts']+=1
                write('cleaned',outheader,[m.get(f,'') for f in outfields])
        else:raise ValueError('Unknown processing mode')
    finally:
        if db:
            db.commit()
            db.close()
        for writer in writers.values():writer.close_part()
    if not writers:
        fallback_header=header if mode not in ('sales_raw','apollo_raw','link_swapper') else outheader
        empty=Writer(folder,'cleaned',fmt,fallback_header)
        empty.write(['']*len(fallback_header))
        empty.close_part()
        # Replace placeholder with header-only output for zero matches.
        if fmt in ('csv','tsv'):
            with empty.paths[0].open('w',newline='',encoding='utf-8-sig') as f:
                csv.writer(f,delimiter='\t' if fmt=='tsv' else ',').writerow(fallback_header)
        writers['cleaned']=empty
    diagnostics()
    # A ZIP avoids fragile browser-side large-blob generation and supports ZIP64.
    archive=folder/('EasyFlow_'+safe_name(mode)+'.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=int(os.environ.get('NS_ZIP_LEVEL','1')),allowZip64=True) as z:
        for writer in writers.values():
            for path in writer.paths:z.write(path,arcname=path.name)
        z.writestr('processing_summary.json',json.dumps(stats,indent=2))
    return archive,stats
