"""Disk-backed chunk processing: CSV/TSV streaming and XLSX read-only iteration."""
import csv, io, math, os, re, tempfile, zipfile
from pathlib import Path
from openpyxl import load_workbook, Workbook

FORMATS={'.csv', '.tsv', '.xlsx'}

def safe_name(name):
    return (re.sub(r'[^A-Za-z0-9._-]+','_',name).strip('._') or 'data')[:85]

def iter_records(source, suffix):
    if suffix in ('.csv','.tsv'):
        with source.open('r',encoding='utf-8-sig',newline='') as f:
            reader=csv.reader(f,delimiter='\t' if suffix=='.tsv' else ',')
            try: header=next(reader)
            except StopIteration: raise ValueError('File is empty')
            yield header
            yield from reader
    else:
        wb=load_workbook(source,read_only=True,data_only=True)
        try:
            ws=wb.active
            for row in ws.iter_rows(values_only=True):
                yield ['' if v is None else v for v in row]
        finally:wb.close()

def count_rows(source,suffix):
    count=0
    for _ in iter_records(source,suffix):count+=1
    if not count:raise ValueError('File is empty')
    return count-1

class PartWriter:
    def __init__(self,path,fmt,header):
        self.path=path;self.fmt=fmt;self.n=0
        if fmt=='xlsx':
            self.wb=Workbook(write_only=True);self.ws=self.wb.create_sheet('Data');self.ws.append(header)
        else:
            self.fp=path.open('w',newline='',encoding='utf-8-sig')
            self.writer=csv.writer(self.fp,delimiter='\t' if fmt=='tsv' else ',');self.writer.writerow(header)
    def add(self,row):
        if self.fmt=='xlsx':self.ws.append(list(row))
        else:self.writer.writerow(row)
        self.n+=1
    def close(self):
        if self.fmt=='xlsx':self.wb.save(self.path)
        else:self.fp.close()

def build(source,suffix,fmt,mode,size,groups,outdir,base):
    if fmt not in ('csv','tsv','xlsx'):raise ValueError('Invalid output format')
    if suffix not in FORMATS:raise ValueError('Unsupported file type')
    if mode=='simple' and size<1:raise ValueError('Chunk size must be positive')
    if fmt=='xlsx' and size>1048575:raise ValueError('Excel chunk size must not exceed 1,048,575 data rows')
    outdir.mkdir(parents=True,exist_ok=True)
    if mode=='simple':
        specs=[('simple',None,size)]
    elif mode=='percentage':
        if not groups or len(groups)!=3:raise ValueError('Exactly 3 percentage groups are required')
        specs=[]
        for i,g in enumerate(groups):
            pct=float(g['percentage']);chunk=int(g['size'])
            if not math.isfinite(pct) or pct<=0 or chunk<1:raise ValueError('Invalid percentage or size')
            if fmt=='xlsx' and chunk>1048575:raise ValueError('Excel chunk size too large')
            specs.append((f'{i+1}_{pct:g}_percent',pct,chunk))
        if abs(sum(s[1] for s in specs)-100)>0.000001:raise ValueError('Percentages must total 100')
    else:raise ValueError('Invalid mode')
    total=count_rows(source,suffix) if mode=='percentage' else None
    boundaries=[]
    if mode=='percentage':
        used=0
        for i,(_,pct,_) in enumerate(specs):
            end=total if i==len(specs)-1 else used+int(total*pct/100)
            boundaries.append((used,end));used=end
    outputs=[];processed=0
    it=iter_records(source,suffix);header=next(it)
    for group_index,(group_name,_,chunk_size) in enumerate(specs):
        group_end=boundaries[group_index][1] if mode=='percentage' else None
        archive=outdir/(safe_name(base)+'_'+safe_name(group_name)+'_chunks.zip')
        part=0;writer=None;part_path=None
        with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
            def finish():
                nonlocal writer,part_path
                if writer is not None:
                    writer.close();z.write(part_path,arcname=part_path.name);part_path.unlink();writer=None
            while True:
                if group_end is not None and processed>=group_end:break
                try:row=next(it)
                except StopIteration:break
                if writer is None or writer.n>=chunk_size:
                    finish();part+=1
                    part_path=outdir/(safe_name(base)+'_'+safe_name(group_name)+f'_part_{part:04d}.'+fmt)
                    writer=PartWriter(part_path,fmt,header)
                writer.add(row);processed+=1
            if part==0:
                part=1;part_path=outdir/(safe_name(base)+'_'+safe_name(group_name)+'_part_0001.'+fmt)
                writer=PartWriter(part_path,fmt,header)
            finish()
        outputs.append({'filename':archive.name,'parts':part,'rows':(group_end-boundaries[group_index][0]) if mode=='percentage' else processed,'path':str(archive)})
    return outputs,processed
