"""Streaming, disk-backed file overview with batched SQLite writes."""
import hashlib
import json
import sqlite3
import tempfile
import time
from pathlib import Path
from .chunks import iter_records, FORMATS

BATCH_SIZE = 2000

def analyze(path, suffix, progress, cancelled=None):
    if suffix not in FORMATS:
        raise ValueError('Supported: CSV, TSV, XLSX')
    started = time.monotonic()
    iterator = iter_records(path, suffix)
    try:
        header = [str(x or '') for x in next(iterator)]
    except StopIteration:
        raise ValueError('File is empty')
    n = len(header)
    if n == 0:
        raise ValueError('No columns detected')
    blanks = [0] * n
    preview = []
    total = blank_rows = duplicates = 0
    timings = {'read_and_hash': 0.0, 'sqlite_writes': 0.0}
    with tempfile.TemporaryDirectory(prefix='ns_overview_') as tmp:
        conn = sqlite3.connect(Path(tmp) / 'overview_keys.sqlite')
        try:
            conn.execute('PRAGMA journal_mode=OFF')
            conn.execute('PRAGMA synchronous=OFF')
            conn.execute('PRAGMA temp_store=MEMORY')
            conn.execute('CREATE TABLE seen (fingerprint BLOB PRIMARY KEY) WITHOUT ROWID')
            conn.execute('CREATE TABLE distinct_values (col INTEGER NOT NULL, fingerprint BLOB NOT NULL, PRIMARY KEY(col,fingerprint)) WITHOUT ROWID')
            row_keys = []
            value_keys = []

            def flush():
                nonlocal duplicates
                if not row_keys:
                    return
                t = time.perf_counter()
                before = conn.total_changes
                conn.executemany('INSERT OR IGNORE INTO seen VALUES (?)', row_keys)
                inserted = conn.total_changes - before
                duplicates += len(row_keys) - inserted
                conn.executemany('INSERT OR IGNORE INTO distinct_values VALUES (?,?)', value_keys)
                conn.commit()
                timings['sqlite_writes'] += time.perf_counter() - t
                row_keys.clear()
                value_keys.clear()

            for row in iterator:
                if cancelled is not None and cancelled.is_set():
                    raise InterruptedError('Analysis cancelled')
                t = time.perf_counter()
                values = [str(x if x is not None else '') for x in list(row)[:n]]
                values += [''] * (n - len(values))
                if len(preview) < 50:
                    preview.append(values)
                missing = False
                for i, value in enumerate(values):
                    if not value.strip():
                        blanks[i] += 1
                        missing = True
                    else:
                        value_keys.append((i, hashlib.sha256(value.encode('utf-8')).digest()))
                if missing:
                    blank_rows += 1
                key = hashlib.sha256(json.dumps(values, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).digest()
                row_keys.append((key,))
                total += 1
                timings['read_and_hash'] += time.perf_counter() - t
                if len(row_keys) >= BATCH_SIZE:
                    flush()
                    progress({'phase': 'analyzing', 'rows_scanned': total, 'message': f'Analyzed {total:,} records; counting blanks and duplicates'})
            flush()
            unique = [0] * n
            for col, count in conn.execute('SELECT col, COUNT(*) FROM distinct_values GROUP BY col'):
                unique[col] = count
        finally:
            conn.close()
    return {
        'filename': path.name, 'rows': total, 'columns': n, 'headers': header,
        'preview': preview, 'blank_cells': sum(blanks), 'blank_rows': blank_rows,
        'blank_by_column': blanks, 'unique_by_column': unique,
        'filled_by_column': [total - b for b in blanks], 'duplicate_rows': duplicates,
        'seconds': round(time.monotonic() - started, 2),
        'duplicate_definition': 'Exact full-row matches, first occurrence retained',
    }
