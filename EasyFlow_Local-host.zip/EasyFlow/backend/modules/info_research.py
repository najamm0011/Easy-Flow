"""Phase 3 public company-site research (no search-provider API).

Fetches only a user-supplied, publicly reachable company domain and its own
public pages. Does not crawl search-engine result pages or gated profiles.
"""
import ipaddress
import json
import re
import socket
from html.parser import HTMLParser
from urllib.parse import urlparse, urljoin
from urllib.request import Request, build_opener, HTTPRedirectHandler

MAX_BYTES = 600_000
MAX_ROWS = 25

class PageParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.links=[]; self.description=''; self.jsonld=[]; self._script=False; self._buffer=''
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='a' and a.get('href'): self.links.append(a['href'])
        if tag=='meta' and (a.get('name','').lower()=='description' or a.get('property','').lower()=='og:description') and not self.description: self.description=a.get('content','').strip()
        if tag=='script' and a.get('type','').lower()=='application/ld+json':self._script=True;self._buffer=''
    def handle_data(self,data):
        if self._script:self._buffer+=data[:40000]
    def handle_endtag(self,tag):
        if tag=='script' and self._script:self.jsonld.append(self._buffer);self._script=False

def valid_public_host(hostname):
    if not hostname or hostname=='localhost' or hostname.endswith(('.local','.internal','.test','.invalid')):return False
    try:
        addresses=socket.getaddrinfo(hostname,443,type=socket.SOCK_STREAM)
        return bool(addresses) and all(ipaddress.ip_address(item[4][0]).is_global for item in addresses)
    except (OSError,ValueError):return False

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

OPENER=build_opener(NoRedirect)

def get_page(url):
    p=urlparse(url)
    if p.scheme!='https' or p.username or p.password or p.port not in (None,443) or not valid_public_host(p.hostname):
        raise ValueError('Unsafe or inaccessible public HTTPS host')
    req=Request(url,headers={'User-Agent':'EasyFlowPublicResearch/1.0 (company public pages)','Accept':'text/html'})
    with OPENER.open(req,timeout=8) as response:
        if 'text/html' not in response.headers.get('Content-Type','').lower():raise ValueError('Not an HTML page')
        data=response.read(MAX_BYTES+1)
        if len(data)>MAX_BYTES:raise ValueError('Page too large')
        charset=response.headers.get_content_charset() or 'utf-8'
        return data.decode(charset,errors='replace')

def domain_from_cell(value):
    value=str(value or '').strip()
    if not value:return ''
    p=urlparse(value if '://' in value else 'https://'+value)
    host=(p.hostname or '').lower().removeprefix('www.')
    if not host or '.' not in host or p.scheme not in ('http','https') or p.username or p.password:return ''
    return host

def same_site(url,domain):
    host=(urlparse(url).hostname or '').lower()
    return host==domain or host=='www.'+domain

def public_company_link(url):
    p=urlparse(url)
    if p.scheme!='https' or (p.hostname or '').lower() not in ('linkedin.com','www.linkedin.com'):return ''
    if re.fullmatch(r'/company/[A-Za-z0-9_.%-]+/?',p.path):return 'https://www.linkedin.com'+p.path.rstrip('/')
    return ''

def inspect_site(domain):
    base='https://'+domain+'/'
    homepage=PageParser();homepage.feed(get_page(base))
    pages=[(base,homepage)]
    for link in homepage.links:
        url=urljoin(base,link)
        path=urlparse(url).path.lower().rstrip('/')
        if same_site(url,domain) and path in ('/about','/about-us','/company','/contact','/contact-us') and urlparse(url).scheme=='https':
            try:
                parser=PageParser();parser.feed(get_page(url));pages.append((url,parser))
            except (ValueError,OSError,TimeoutError,UnicodeError):pass
            if len(pages)>=3:break
    linkedin=set()
    for page_url,page in pages:
        for link in page.links:
            candidate=public_company_link(urljoin(page_url,link))
            if candidate:linkedin.add((candidate,page_url))
        for raw in page.jsonld:
            try:obj=json.loads(raw)
            except (ValueError,TypeError):continue
            def walk(node):
                if isinstance(node,dict):
                    for k,v in node.items():
                        if k=='sameAs':
                            for item in v if isinstance(v,list) else [v]:
                                if isinstance(item,str):
                                    candidate=public_company_link(item)
                                    if candidate:linkedin.add((candidate,page_url))
                        elif isinstance(v,(dict,list)):walk(v)
                elif isinstance(node,list):
                    for v in node:walk(v)
            walk(obj)
    return {'linkedin':linkedin,'description':homepage.description,'source':base}

def research_rows(rows,mappings,fields,limit=MAX_ROWS):
    if len(rows)>limit:raise ValueError(f'Public-source pilot supports up to {limit} rows per run')
    if any(field not in {'Company Website','Company LinkedIn','Company Description'} for field in fields):
        raise ValueError('Pilot supports Website, Company LinkedIn and Company Description only')
    company_col=mappings.get('Company Name')
    if not isinstance(company_col,int) or company_col<0:raise ValueError('Map Company Name before starting research')
    result=[list(r) for r in rows];report=[];cache={};filled=0
    for i,row in enumerate(result):
        name=str(row[company_col] if company_col<len(row) else '').strip()
        website_col=mappings.get('Company Website')
        domain=domain_from_cell(row[website_col]) if isinstance(website_col,int) and website_col<len(row) else ''
        for field in fields:
            col=mappings.get(field)
            if not isinstance(col,int) or col<0:continue
            while len(row)<=col:row.append('')
            if str(row[col] or '').strip():continue
            entry={'row':i+2,'field':field}
            if not name:
                entry.update(status='unmatched',reason='Company name missing')
            elif not domain:
                entry.update(status='unmatched',reason='No existing company domain; public website cannot be reliably discovered without a search index')
            elif field=='Company Website':
                entry.update(status='unmatched',reason='Website column is blank; no independent verified company domain')
            else:
                if domain not in cache:
                    try:cache[domain]=inspect_site(domain)
                    except Exception as exc:cache[domain]={'error':str(exc)[:150]}
                site=cache[domain]
                if 'error' in site:
                    entry.update(status='error',reason=site['error'])
                elif field=='Company LinkedIn':
                    links=site['linkedin'];unique={v for v,s in links}
                    if len(unique)==1:
                        value=next(iter(unique));source=next(s for v,s in links if v==value)
                        row[col]=value;filled+=1;entry.update(status='filled',candidate=value,source=source,reason='Linked from official company website')
                    elif unique:entry.update(status='review_required',reason='Multiple LinkedIn company profiles on website',source=site['source'])
                    else:entry.update(status='unmatched',reason='No company LinkedIn link on public website',source=site['source'])
                else:
                    desc=site['description']
                    if desc and len(desc)<=350:
                        # Description is published by the domain supplied in the input.
                        row[col]=desc;filled+=1;entry.update(status='filled',candidate=desc,source=site['source'])
                    else:entry.update(status='unmatched',reason='No concise public description',source=site['source'])
            report.append(entry)
    return {'rows':result,'report':report,'searched':len(cache),'auto_filled':filled,'note':'Official-domain public-page pilot. No search API, no email research; unsupported fields remain blank.'}
