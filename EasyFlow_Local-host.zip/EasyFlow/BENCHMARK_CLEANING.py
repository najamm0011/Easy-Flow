"""Benchmark real cleaning operations. Synthetic data generation excluded from timings."""
import argparse,csv,os,tempfile,time,zipfile
from pathlib import Path
from backend.modules.processing import process

MODES=('duplicates','master_compare','blanks','apollo_raw')
def run(rows=100000,modes=MODES):
    if not 1<=rows<=2000000:raise ValueError('Rows must be 1..2,000,000')
    with tempfile.TemporaryDirectory(prefix='ns_clean_bench_') as td:
        base=Path(td); source=base/'fresh.csv'; master=base/'master.csv'
        headers=['First Name','Last Name','Company Name','Email','Company Website','Job Title','Full Name']
        with source.open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f);w.writerow(headers)
            for i in range(rows):
                k=i%20000
                w.writerow([f'First{k}',f'Last{k}',f'Company{k%1000}',f'p{k}@example.com', '' if i%13==0 else f'company{k%1000}.com','CEO',f'First{k} Last{k}'])
        with master.open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f);w.writerow(headers)
            for k in range(5000):w.writerow([f'First{k}',f'Last{k}',f'Company{k%1000}',f'p{k}@example.com',f'company{k%1000}.com','CEO',f'First{k} Last{k}'])
        configs={
            'duplicates':{'columns':['Email']},
            'master_compare':{'master_path':str(master),'columns':['Email'],'master_columns':['Email']},
            'blanks':{'columns':['Company Website']},
            'apollo_raw':{'mapping':{'full_name':'Full Name','job_title':'Job Title','company_name':'Company Name','company_website':'Company Website'}}}
        print('Benchmark: Actual Cleaning Modules | Profiling: OFF')
        print('Input rows:',rows,'Input MB:',round(source.stat().st_size/1048576,2))
        for mode in modes:
            start=time.perf_counter()
            archive,stats=process(source,'.csv',base/('out_'+mode),mode,configs[mode],fmt='csv')
            seconds=time.perf_counter()-start
            if stats['input_rows']!=rows:raise AssertionError((mode,stats))
            if stats['output_rows']+stats['removed_rows']!=rows:raise AssertionError((mode,stats))
            with zipfile.ZipFile(archive) as z:
                if z.testzip() is not None:raise AssertionError('Corrupt export: '+mode)
            print(f'{mode}: Seconds={seconds:.2f} Rows/sec={rows/max(seconds,1e-9):.0f} Output={stats["output_rows"]} Removed={stats["removed_rows"]} ZIP_MB={archive.stat().st_size/1048576:.2f}')
        try:
            import psutil
            print('RSS at end MB (not peak):',round(psutil.Process(os.getpid()).memory_info().rss/1048576,2))
        except ImportError:print('RSS: unavailable (optional psutil not installed)')
        print('Note: timings include process+ZIP export, exclude input generation; not a browser benchmark.')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--rows',type=int,default=100000)
    parser.add_argument('--modes',nargs='+',choices=MODES,default=list(MODES))
    args=parser.parse_args()
    run(args.rows,args.modes)
