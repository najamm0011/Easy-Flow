EasyFlow Phase 5 — workspace cancellation and size-policy improvements

- No application-defined MB/GB upload cap added; FastAPI uploads spool to disk.
- Chunks Studio output uses disk-based ZIP64 archives and FileResponse (no arbitrary KB download limit).
- Back to Dashboard clears selected files, universal overview, progress UI, preview data, in-memory studio state and generated download links.
- Active overview upload is aborted in the browser; active overview analysis receives a cooperative cancellation event and cleans temporary files.
- Chunks Studio request is aborted on navigation. Note: aborting an HTTP request does NOT guarantee the already-started synchronous server processing stops; server-side chunk cancellation remains a future improvement.
- IMPORTANT: Duplicate, Blank, Job Title, Sales and Apollo exports still use browser-side Blob/JSZip/XLSX paths. They have no configured small KB cap in this project, but large file export is NOT guaranteed until those modules are migrated to the streaming backend.
- No guarantee of unlimited sizes: free disk, memory, OS, file formats and Excel limits apply.
- Restart server after installing this ZIP.
